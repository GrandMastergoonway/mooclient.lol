﻿namespace WindowsFormsApp2
{
	// Token: 0x02000002 RID: 2
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000008 RID: 8 RVA: 0x000021BC File Offset: 0x000003BC
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000021F4 File Offset: 0x000003F4
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::WindowsFormsApp2.Form1));
			this.label1 = new global::System.Windows.Forms.Label();
			this.InjectBTN = new global::System.Windows.Forms.Button();
			this.button1 = new global::System.Windows.Forms.Button();
			this.label23 = new global::System.Windows.Forms.Label();
			this.label24 = new global::System.Windows.Forms.Label();
			this.label20 = new global::System.Windows.Forms.Label();
			this.guna2BorderlessForm1 = new global::Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
			this.guna2DragControl1 = new global::Guna.UI2.WinForms.Guna2DragControl(this.components);
			this.guna2Separator1 = new global::Guna.UI2.WinForms.Guna2Separator();
			this.guna2Separator2 = new global::Guna.UI2.WinForms.Guna2Separator();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 7.8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.Location = new global::System.Drawing.Point(245, 74);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(70, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Calamity X";
			this.InjectBTN.BackColor = global::System.Drawing.Color.Black;
			this.InjectBTN.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("InjectBTN.BackgroundImage");
			this.InjectBTN.ForeColor = global::System.Drawing.Color.Wheat;
			this.InjectBTN.Location = new global::System.Drawing.Point(218, 147);
			this.InjectBTN.Name = "InjectBTN";
			this.InjectBTN.Size = new global::System.Drawing.Size(132, 43);
			this.InjectBTN.TabIndex = 1;
			this.InjectBTN.Text = "Inject";
			this.InjectBTN.UseVisualStyleBackColor = false;
			this.InjectBTN.Click += new global::System.EventHandler(this.InjectBTN_Click);
			this.button1.BackColor = global::System.Drawing.Color.FromArgb(25, 25, 25);
			this.button1.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("button1.BackgroundImage");
			this.button1.ForeColor = global::System.Drawing.Color.White;
			this.button1.Location = new global::System.Drawing.Point(218, 219);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(132, 43);
			this.button1.TabIndex = 2;
			this.button1.Text = "Uninject";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.label23.AutoSize = true;
			this.label23.BackColor = global::System.Drawing.Color.Transparent;
			this.label23.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 10.2f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label23.Location = new global::System.Drawing.Point(196, 109);
			this.label23.Name = "label23";
			this.label23.Size = new global::System.Drawing.Size(178, 20);
			this.label23.TabIndex = 24;
			this.label23.Text = "#1 Menu in Gorilla Tag";
			this.label23.Click += new global::System.EventHandler(this.label23_Click);
			this.label24.AutoSize = true;
			this.label24.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label24.Location = new global::System.Drawing.Point(161, 294);
			this.label24.Name = "label24";
			this.label24.Size = new global::System.Drawing.Size(256, 18);
			this.label24.TabIndex = 25;
			this.label24.Text = "Current Status: Fully Undetected!";
			this.label20.AutoSize = true;
			this.label20.BackColor = global::System.Drawing.Color.Transparent;
			this.label20.Font = new global::System.Drawing.Font("Comic Sans MS", 10.2f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label20.Location = new global::System.Drawing.Point(573, 8);
			this.label20.Name = "label20";
			this.label20.Size = new global::System.Drawing.Size(20, 24);
			this.label20.TabIndex = 26;
			this.label20.Text = "x";
			this.label20.Click += new global::System.EventHandler(this.label20_Click);
			this.guna2BorderlessForm1.ContainerControl = this;
			this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
			this.guna2BorderlessForm1.TransparentWhileDrag = true;
			this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
			this.guna2DragControl1.UseTransparentDrag = true;
			this.guna2Separator1.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Separator1.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("guna2Separator1.BackgroundImage");
			this.guna2Separator1.Location = new global::System.Drawing.Point(-2, -3);
			this.guna2Separator1.Name = "guna2Separator1";
			this.guna2Separator1.Size = new global::System.Drawing.Size(614, 10);
			this.guna2Separator1.TabIndex = 27;
			this.guna2Separator2.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Separator2.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("guna2Separator2.BackgroundImage");
			this.guna2Separator2.Location = new global::System.Drawing.Point(-2, 347);
			this.guna2Separator2.Name = "guna2Separator2";
			this.guna2Separator2.Size = new global::System.Drawing.Size(614, 10);
			this.guna2Separator2.TabIndex = 28;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(8f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(27, 27, 27);
			this.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("$this.BackgroundImage");
			base.ClientSize = new global::System.Drawing.Size(601, 354);
			base.Controls.Add(this.guna2Separator2);
			base.Controls.Add(this.guna2Separator1);
			base.Controls.Add(this.label20);
			base.Controls.Add(this.label24);
			base.Controls.Add(this.label23);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.InjectBTN);
			base.Controls.Add(this.label1);
			this.ForeColor = global::System.Drawing.SystemColors.ControlLight;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.Name = "Form1";
			this.Text = "Form1";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000001 RID: 1
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000002 RID: 2
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000003 RID: 3
		private global::System.Windows.Forms.Button InjectBTN;

		// Token: 0x04000004 RID: 4
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000005 RID: 5
		private global::System.Windows.Forms.Label label23;

		// Token: 0x04000006 RID: 6
		private global::System.Windows.Forms.Label label24;

		// Token: 0x04000007 RID: 7
		private global::System.Windows.Forms.Label label20;

		// Token: 0x04000008 RID: 8
		private global::Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x04000009 RID: 9
		private global::Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;

		// Token: 0x0400000A RID: 10
		private global::Guna.UI2.WinForms.Guna2Separator guna2Separator2;

		// Token: 0x0400000B RID: 11
		private global::Guna.UI2.WinForms.Guna2Separator guna2Separator1;
	}
}
