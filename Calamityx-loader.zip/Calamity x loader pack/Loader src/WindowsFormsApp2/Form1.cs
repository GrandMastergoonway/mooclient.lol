﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Security.Principal;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using WindowsFormsApp2.Properties;

namespace WindowsFormsApp2
{
	// Token: 0x02000002 RID: 2
	public partial class Form1 : Form
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000002 RID: 2 RVA: 0x00002068 File Offset: 0x00000268
		private static bool IsAdministrator()
		{
			WindowsIdentity identity = WindowsIdentity.GetCurrent();
			WindowsPrincipal principal = new WindowsPrincipal(identity);
			return principal.IsInRole(WindowsBuiltInRole.Administrator);
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002092 File Offset: 0x00000292
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00002098 File Offset: 0x00000298
		private void button1_Click(object sender, EventArgs e)
		{
			bool flag = Form1.IsAdministrator();
			if (flag)
			{
				try
				{
					string dllPath = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\BepInEx\\plugins\\CalamityX.dll";
					bool flag2 = File.Exists(dllPath);
					if (flag2)
					{
						File.SetAttributes(dllPath, FileAttributes.Normal);
						File.Delete(dllPath);
						MessageBox.Show("Uninjected Calamity X.!");
					}
					else
					{
						MessageBox.Show("DLL not found. No action taken.");
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("An error occurred: " + ex.Message);
				}
			}
			else
			{
				MessageBox.Show("Run as admin!");
			}
		}

        // Token: 0x06000005 RID: 5 RVA: 0x00002130 File Offset: 0x00000330
        private void InjectBTN_Click(object sender, EventArgs e)
        {
            bool flag = Form1.IsAdministrator();
            if (flag)
            {
                try
                {
                    string dllPath = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\BepInEx\\plugins\\CalamityX.dll";
                    byte[] dllBytes = Resources.CalamityX;
                    File.WriteAllBytes(dllPath, dllBytes);

                    // Get the current attributes of the file
                    FileAttributes attributes = File.GetAttributes(dllPath);

                    // Remove the Hidden attribute if it is set
                    if ((attributes & FileAttributes.) == FileAttributes.Hidden)
                    {
                        attributes &= ~FileAttributes.Normal;
                    }

                    // Set the new attributes to the file, ensuring it's not hidden
                    File.SetAttributes(dllPath, attributes | FileAttributes.ReadOnly | FileAttributes.System);

                    MessageBox.Show("Injected Calamity X. Good!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Run as admin!");
            }
        }


        // Token: 0x06000006 RID: 6 RVA: 0x000021B0 File Offset: 0x000003B0
        private void label20_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000021B9 File Offset: 0x000003B9
		private void label23_Click(object sender, EventArgs e)
		{
		}
	}
}
