using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using PasswordProtector;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Mods;
using UnityEngine;
using UnityEngine.UI;

namespace GUI11;

[BepInPlugin("com.dd.gorillatag.FAGG", "fdfsfsefsef", "1.0.0")]
public class Plugin : BaseUnityPlugin
{
	public class DesignLibrary : MonoBehaviour
	{
		public static Texture2D button = new Texture2D(1, 1);

		public static Texture2D buttonhovered = new Texture2D(1, 1);

		public static Texture2D buttonactive = new Texture2D(1, 1);

		public static Texture2D textarea = new Texture2D(1, 1);

		public static Texture2D textareahovered = new Texture2D(1, 1);

		public static Texture2D textareaactive = new Texture2D(1, 1);

		public static Texture2D label = new Texture2D(1, 1);

		public static Texture2D textField = new Texture2D(1, 1);

		public static Texture2D toggle = new Texture2D(1, 1);

		public static Texture2D scrollView = new Texture2D(1, 1);

		public static Texture2D dropdown = new Texture2D(1, 1);

		public static Texture2D slider = new Texture2D(1, 1);

		public static Texture2D progressBar = new Texture2D(1, 1);

		public static Texture2D box = new Texture2D(1, 1);

		public static Color windowbackground = Color.black;

		public static Color textcolor = Color.white;

		public static Color activeTextColor = Color.green;
	}

	private float timer = 3600f;

	public static Font consolas = Font.CreateDynamicFontFromOSFont("Consolas", 13);

	public static Texture2D button = new Texture2D(1, 1);

	public static float pp;

	public static int num = 1;

	public static string filename = "REDEUMLogs" + num + ".txt";

	public static Vector2[] scroll = (Vector2[])(object)new Vector2[100];

	public static Rect Window = new Rect(0f, 30f, 415f, 360f);

	private static string srtttt = "".ToUpper();

	public const int MaxLogs = 20;

	public static List<string> logs = new List<string>();

	private bool socails;

	private bool cunner2;

	private bool cunner3;

	public string sexxer = "Box Esp";

	public string sexxer2 = "Tracers";

	public string sexxer3 = "Esp";

	private bool Visual;

	private bool rigcum;

	public static float deltaTime;

	public static float HandTap;

	public static float BoardSelectCooldown;

	public Rect windowRect = new Rect(20f, 20f, 450f, 316f);

	public static string namechange;

	public bool movementtab;

	private bool cunner;

	private bool info;

	public bool freecamtoggle;

	private static Vector2 scrollPosition;

	public static float FCMovmentSpeed = 1f;

	public static float FCJumpSpeed = 1f;

	public static float FcRotation = 1f;

	public static string MotdChanger;

	public static float Up = 0.075f;

	private bool RESETRIG;

	public string labelText = "";

	public GUIStyle labelStyle;

	private float down = 0.075f;

	public bool ModsTab;

	public bool CrashAll;

	public bool waterminigun;

	public bool Fishminigun;

	public bool snowminigunrashAll;

	private bool soundspammer1;

	private bool soundspammer2;

	private bool soundspammer3;

	private bool RigMOVEEE;

	private bool lagall;

	public static string RoomJOINER = "Iron Testing Room";

	private bool lagallV2;

	private bool spammers;

	public static Rect[] balls = (Rect[])(object)new Rect[50];

	public static Texture2D snowTexure;

	private bool freecamtoggle2;

	public static string Codetojoin;

	public bool changerstab;

	public bool cupidsex;

	private bool SEX;

	private string stringthing;

	private bool visual;

	private bool sexwithkfj;

	private bool BOONEER;

	private bool bigtits;

	private bool SELFSEX;

	private bool Rejoin;

	private bool chams;

	private bool disconnect;

	private bool wasd;

	private bool esp = false;

	private bool Room;

	private bool panic;

	private bool onn = true;

	private bool master2 = false;

	private bool master3 = false;

	private bool master4 = false;

	private bool master5 = false;

	private bool enable;

	private bool afk = false;

	private bool Bubble;

	public static bool head;

	private bool lobbyjoin;

	private bool splash = false;

	public static bool fpc = false;

	private bool antimodcheck = false;

	private bool havedonestuff = false;

	private bool nameset;

	private static Harmony instance;

	public static bool hasbeenenabled = false;

	private static GradientColorKey[] colorKeysPlatformMonke = (GradientColorKey[])(object)new GradientColorKey[4];

	public static int pastquality = QualitySettings.GetQualityLevel();

	public static bool IsPatched { get; private set; }

	private void Start()
	{
	}

	internal static void ApplyHarmonyPatches()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		if (!IsPatched)
		{
			if (instance == null)
			{
				instance = new Harmony("com.f.f.f");
			}
			instance.PatchAll(Assembly.GetExecutingAssembly());
			IsPatched = true;
		}
	}

	internal static void RemoveHarmonyPatches()
	{
		if (instance != null && IsPatched)
		{
			instance.UnpatchSelf();
			IsPatched = false;
		}
	}

	private void OnEnable()
	{
		ApplyHarmonyPatches();
	}

	private void OnDisable()
	{
		RemoveHarmonyPatches();
	}

	private void OnGameInitialized(object sender, EventArgs e)
	{
	}

	private void OnGUI()
	{
		//IL_1248: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Expected O, but got Unknown
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_065f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0706: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_076b: Unknown result type (might be due to invalid IL or missing references)
		//IL_079e: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0874: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_057a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b54: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e43: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a97: Unknown result type (might be due to invalid IL or missing references)
		//IL_111b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ffd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1002: Unknown result type (might be due to invalid IL or missing references)
		//IL_1007: Unknown result type (might be due to invalid IL or missing references)
		//IL_119d: Unknown result type (might be due to invalid IL or missing references)
		//IL_11de: Unknown result type (might be due to invalid IL or missing references)
		//IL_1040: Unknown result type (might be due to invalid IL or missing references)
		if (!PasswordProtector.Main.MenuUnlocked)
		{
			return;
		}
		if (onn)
		{
			ButtonInfo[][] buttons = Buttons.buttons;
			foreach (ButtonInfo[] array in buttons)
			{
				ButtonInfo[] array2 = array;
				foreach (ButtonInfo buttonInfo in array2)
				{
					if (buttonInfo.enabled)
					{
						if (labelText == null)
						{
							labelText += buttonInfo.buttonText;
						}
						else
						{
							labelText = labelText + "\n" + buttonInfo.buttonText;
						}
					}
					GUI.color = Color.red;
					GUI.backgroundColor = Color.red;
				}
			}
			labelStyle = new GUIStyle();
			labelStyle.alignment = (TextAnchor)2;
			labelStyle.fontSize = 18;
			float num = 500f;
			float num2 = 999f;
			float num3 = (float)Screen.width - num - 10f;
			float num4 = 5f;
			GUILayout.Space(5f);
			string[] source = labelText.Split('\n');
			string[] value = source.OrderBy((string line) => 0f - labelStyle.CalcSize(new GUIContent(line)).x).ToArray();
			string text = string.Join("\n", value);
			labelText = text;
			GUI.Label(new Rect(num3, num4, num, num2), labelText, labelStyle);
			labelText = null;
			GUI.color = Color.red;
			GUI.Box(new Rect(15f, 15f, 450f, 316f), "RedRum Client");
			GUI.Box(new Rect(15f, 15f, 97f, 316f), "");
			GUI.color = Color.red;
			GUI.color = Color.red;
			if (GUI.Button(new Rect(19f, 34f, 83f, 25f), "Room"))
			{
				movementtab = false;
				socails = false;
				changerstab = false;
				info = false;
				RigMOVEEE = false;
				ModsTab = false;
				Visual = false;
				Room = !Room;
				spammers = false;
			}
			if (Room)
			{
				srtttt = GUILayout.TextArea(srtttt, Array.Empty<GUILayoutOption>());
				if (GUILayout.Button("Join room", Array.Empty<GUILayoutOption>()))
				{
					((PhotonNetworkController)PhotonNetworkController.Instance).AttemptToJoinSpecificRoom(srtttt.ToUpper(), (JoinType)0);
				}
				if (GUI.Button(new Rect(118f, 94f, 322f, 25f), "Disconnect"))
				{
					PhotonNetwork.Disconnect();
				}
				if (GUI.Button(new Rect(118f, 124f, 322f, 25f), "Join Random"))
				{
					PhotonNetwork.JoinRandomRoom();
				}
				if (GUI.Button(new Rect(118f, 154f, 322f, 25f), "Quit"))
				{
					Application.Quit();
				}
				if (!GUI.Button(new Rect(118f, 184f, 322f, 25f), "Join Test Room"))
				{
				}
			}
			if (GUI.Button(new Rect(19f, 64f, 83f, 25f), "Changers"))
			{
				movementtab = false;
				Room = false;
				ModsTab = false;
				Visual = false;
				changerstab = !changerstab;
				socails = false;
				RigMOVEEE = false;
				info = false;
				spammers = false;
			}
			if (changerstab)
			{
				namechange = GUI.TextArea(new Rect(118f, 34f, 322f, 25f), namechange);
				if (GUI.Button(new Rect(118f, 64f, 322f, 25f), "Change Name"))
				{
					PhotonNetwork.NickName = namechange;
					((Object)GorillaGameManager.instance).name = namechange;
					((GorillaComputer)GorillaComputer.instance).currentName = namechange;
				}
				MotdChanger = GUI.TextArea(new Rect(118f, 94f, 322f, 25f), MotdChanger);
				if (GUI.Button(new Rect(118f, 124f, 322f, 25f), "Change Motd Name"))
				{
					GameObject.Find("UI/motd").GetComponent<Text>().text = MotdChanger;
				}
				OverPowered.NameChangingString = GUI.TextArea(new Rect(118f, 174f, 322f, 25f), OverPowered.NameChangingString);
				if (GUI.Button(new Rect(118f, 188f, 322f, 25f), "Change Name All") && StupidTemplate.Menu.Main.GetIndex("Name Change[Custom Gui]").enabled && OverPowered.NameChangerString == null)
				{
					GUI.Box(new Rect(118f, 178f, 322f, 25f), "Assign Name Changing Name");
					if (GUI.Button(new Rect(118f, 180f, 322f, 25f), "Submit"))
					{
						OverPowered.NameChangeAll();
						OverPowered.NameChangerString = OverPowered.NameChangingString;
					}
				}
			}
			if (GUI.Button(new Rect(19f, 94f, 83f, 25f), "Movement"))
			{
				changerstab = false;
				Room = false;
				ModsTab = false;
				info = false;
				socails = false;
				RigMOVEEE = false;
				spammers = false;
				Visual = false;
				movementtab = !movementtab;
			}
			if (movementtab)
			{
				freecamtoggle = GUI.Toggle(new Rect(118f, 34f, 322f, 25f), freecamtoggle, "FreeCam");
				if (freecamtoggle)
				{
					wasdd();
				}
				GUI.Label(new Rect(118f, 64f, 322f, 25f), "FreeCam Movment Speed = " + FCMovmentSpeed);
				FCMovmentSpeed = GUI.HorizontalSlider(new Rect(118f, 84f, 322f, 25f), FCMovmentSpeed, -3f, 50f);
				GUI.Label(new Rect(118f, 114f, 322f, 25f), "FreeCam Rotation Speed = " + FcRotation);
				FcRotation = GUI.HorizontalSlider(new Rect(118f, 144f, 322f, 25f), FcRotation, -3f, 5f);
				GUI.Label(new Rect(118f, 174f, 322f, 25f), "FreeCam Jump Speed = " + FCJumpSpeed);
				FCJumpSpeed = GUI.HorizontalSlider(new Rect(118f, 204f, 322f, 25f), FCJumpSpeed, -3f, 50f);
				GUI.Label(new Rect(118f, 234f, 999f, 65f), "The Negetive Numbers Makes You Go The Oppisite Way");
			}
			if (GUI.Button(new Rect(19f, 124f, 83f, 25f), "PlayerList"))
			{
				changerstab = false;
				Room = false;
				movementtab = false;
				info = false;
				ModsTab = !ModsTab;
				socails = false;
				spammers = false;
				Visual = false;
				RigMOVEEE = false;
			}
			if (ModsTab)
			{
				GUI.Label(new Rect(118f, 64f, 322f, 25f), "FreeCam Movment Speed = " + FCMovmentSpeed);
				Player[] playerList = PhotonNetwork.PlayerList;
				foreach (Player val in playerList)
				{
					GUILayout.Label(val.NickName.ToUpper(), Array.Empty<GUILayoutOption>());
				}
			}
			if (GUI.Button(new Rect(19f, 154f, 83f, 25f), "WIP"))
			{
				changerstab = false;
				Visual = false;
				Room = false;
				movementtab = false;
				ModsTab = false;
				info = false;
				socails = false;
				RigMOVEEE = false;
				spammers = !spammers;
			}
			if (spammers)
			{
				waterminigun = GUI.Toggle(new Rect(118f, 34f, 322f, 25f), waterminigun, "Crash All [<color=red>W?</color>]");
				if (waterminigun)
				{
				}
				Fishminigun = GUI.Toggle(new Rect(118f, 64f, 322f, 25f), Fishminigun, "");
				if (Fishminigun)
				{
				}
				snowminigunrashAll = GUI.Toggle(new Rect(118f, 94f, 322f, 25f), snowminigunrashAll, "");
				if (snowminigunrashAll)
				{
				}
				snowminigunrashAll = GUI.Toggle(new Rect(118f, 134f, 322f, 25f), snowminigunrashAll, "");
				if (snowminigunrashAll)
				{
				}
				snowminigunrashAll = GUI.Toggle(new Rect(118f, 164f, 322f, 25f), snowminigunrashAll, "");
				if (snowminigunrashAll)
				{
				}
				snowminigunrashAll = GUI.Toggle(new Rect(118f, 194f, 322f, 25f), snowminigunrashAll, "");
				if (!snowminigunrashAll)
				{
				}
			}
			if (GUI.Button(new Rect(19f, 184f, 83f, 25f), "SOON"))
			{
				changerstab = false;
				Visual = false;
				Room = false;
				movementtab = false;
				socails = false;
				ModsTab = false;
				spammers = false;
				info = false;
				RigMOVEEE = !RigMOVEEE;
			}
			if (RigMOVEEE)
			{
			}
			if (GUI.Button(new Rect(19f, 214f, 83f, 25f), "Info"))
			{
				changerstab = false;
				Room = false;
				movementtab = false;
				socails = false;
				ModsTab = false;
				spammers = false;
				Visual = false;
				RigMOVEEE = false;
				info = !info;
			}
			if (info)
			{
				GUI.Label(new Rect(118f, 24f, 322f, 25f), "Player Info");
				GUI.Label(new Rect(118f, 44f, 322f, 25f), "----------------------------------------------");
				GUI.Label(new Rect(118f, 64f, 322f, 25f), "Name : " + PhotonNetwork.NickName);
				GUI.Label(new Rect(118f, 84f, 322f, 25f), "In Room : " + PhotonNetwork.InRoom);
				GUI.Label(new Rect(118f, 104f, 322f, 25f), "Master : " + PhotonNetwork.IsMasterClient);
				GUI.Label(new Rect(118f, 124f, 322f, 25f), "Fps : " + 10f / Time.deltaTime);
				GUI.Label(new Rect(118f, 144f, 322f, 25f), "----------------------------------------------");
				GUI.Label(new Rect(118f, 164f, 322f, 25f), "Server Info");
				GUI.Label(new Rect(118f, 184f, 322f, 25f), "Server Adress : " + PhotonNetwork.ServerAddress);
				GUI.Label(new Rect(118f, 204f, 322f, 25f), "Game Version : " + PhotonNetwork.GameVersion);
				GUI.Label(new Rect(118f, 224f, 322f, 25f), "Player's in lobbys : " + PhotonNetwork.CountOfPlayersInRooms);
				GUI.Label(new Rect(118f, 244f, 322f, 25f), "Offline Mode : " + PhotonNetwork.OfflineMode);
				GUI.Label(new Rect(118f, 264f, 322f, 25f), "Server Full : " + ((GorillaComputer)GorillaComputer.instance).roomFull);
				GUI.Label(new Rect(118f, 284f, 322f, 25f), "Server Code : " + (object)PhotonNetwork.CurrentRoom);
				GUI.Label(new Rect(118f, 304f, 322f, 25f), "----------------------------------------------");
			}
			if (GUI.Button(new Rect(19f, 244f, 83f, 25f), "Console WIP"))
			{
				changerstab = false;
				Room = false;
				movementtab = false;
				ModsTab = false;
				spammers = false;
				socails = false;
				info = false;
				RigMOVEEE = false;
				Visual = !Visual;
			}
			if (Visual)
			{
				cunner = GUI.Toggle(new Rect(118f, 34f, 322f, 25f), cunner, sexxer);
				if (cunner)
				{
					GUI.skin.scrollView.normal.background = DesignLibrary.scrollView;
					GUI.skin.scrollView.hover.background = DesignLibrary.scrollView;
					GUI.skin.scrollView.active.background = DesignLibrary.scrollView;
					scroll[6] = GUI.BeginScrollView(new Rect(10f, 80f, ((Rect)(ref Window)).width - 20f, 200f), scroll[6], new Rect(0f, 0f, ((Rect)(ref Window)).width - 40f, (float)(20 * (logs.Count + 1))));
					for (int l = 0; l < logs.Count; l++)
					{
						string text2 = logs[l];
						GUI.Label(new Rect(0f, (float)(20 * l), ((Rect)(ref Window)).width - 40f, 20f), text2);
					}
					GUI.EndScrollView();
					GUILayout.Space(220f);
					if (GUILayout.Button("Save Logs", Array.Empty<GUILayoutOption>()))
					{
						while (File.Exists(filename))
						{
							Plugin.num++;
							filename = "RedRumLogs" + Plugin.num + ".txt";
						}
						File.WriteAllLines(filename, logs.ToArray());
					}
					if (GUILayout.Button("Clear Logs", Array.Empty<GUILayoutOption>()))
					{
						logs.Clear();
					}
				}
			}
			if (GUI.Button(new Rect(19f, 274f, 83f, 25f), "Socials"))
			{
				changerstab = false;
				Room = false;
				movementtab = false;
				ModsTab = false;
				spammers = false;
				info = false;
				RigMOVEEE = false;
				Visual = false;
				socails = !socails;
			}
			if (socails)
			{
				if (GUI.Button(new Rect(118f, 34f, 322f, 25f), "Join Discord"))
				{
					Console.WriteLine("Joined Iron.cc Discord");
					Process.Start("https://discord.gg/vjCH5kXYcs");
				}
				if (GUI.Button(new Rect(118f, 64f, 322f, 25f), "Malichis Youtube"))
				{
					Console.WriteLine("Opened Malachis Youtube");
					Process.Start("https://www.youtube.com/@Malachi_the_modder");
				}
			}
		}
		string text3 = "AntiBan disabled";
		try
		{
			if (OverPowered.IsModded())
			{
				text3 = "AntiBan Enabled";
			}
		}
		catch
		{
		}
		GUI.Label(new Rect(10f, (float)(Screen.height - 35), (float)Screen.width, 40f), text3);
		GUI.DragWindow();
	}

	private void DrawSliderWithValue(ref float value, string text, float leftval, float rightval)
	{
		GUILayout.Label(text + value.ToString("F2"), Array.Empty<GUILayoutOption>());
		value = GUILayout.HorizontalSlider(value, leftval, rightval, Array.Empty<GUILayoutOption>());
	}

	private void HandleLog(string logString, string stackTrace, LogType type)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Expected I4, but got Unknown
		string message = "[REDEUM] " + logString;
		switch ((int)type)
		{
		case 3:
			message = "<color=white>[REDEUM] [Log] " + logString + "</color>";
			break;
		case 4:
			message = "<color=red>[REDEUM] [Exception] " + logString + "</color>";
			break;
		case 0:
			message = "<color=red>[IRREDEUMON] [Error] " + logString + "</color>";
			break;
		case 2:
			message = "<color=yellow>[REDEUM] [Warning] " + logString + "</color>";
			break;
		}
		LogToConsole(message);
	}

	private static void LogToConsole(string message)
	{
		logs.Add(message);
		if (logs.Count > 20)
		{
			logs.RemoveAt(0);
		}
	}

	public void GuiMain(int windowID)
	{
		GUI.DragWindow();
		GUI.DragWindow();
	}

	public void Rigup()
	{
		if (Input.GetKeyDown((KeyCode)107))
		{
			GorillaTagger.Instance.offlineVRRig.headBodyOffset.x += Up;
		}
	}

	public void Rigdown()
	{
		GorillaTagger.Instance.offlineVRRig.headBodyOffset.x -= down;
	}

	private void Update()
	{
		if (Input.GetKeyDown((KeyCode)277))
		{
			onn = !onn;
		}
		timer -= Time.deltaTime;
		if (timer <= 0f)
		{
			Application.Quit();
			Console.Beep();
		}
		GUI.DragWindow();
	}

	public static void wasdd()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		if (UnityInput.Current.GetKey((KeyCode)119))
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * FCMovmentSpeed;
		}
		if (UnityInput.Current.GetKey((KeyCode)115))
		{
			Transform transform2 = ((Component)Player.Instance).transform;
			transform2.position += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)100))
		{
			Transform transform3 = ((Component)Player.Instance).transform;
			transform3.position += ((Component)Player.Instance.headCollider).transform.right * Time.deltaTime * FCMovmentSpeed;
		}
		if (UnityInput.Current.GetKey((KeyCode)97))
		{
			Transform transform4 = ((Component)Player.Instance).transform;
			transform4.position += ((Component)Player.Instance.headCollider).transform.right * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)113))
		{
			((Component)Player.Instance).transform.Rotate(0f, 0f - FcRotation, 0f);
		}
		if (UnityInput.Current.GetKey((KeyCode)101))
		{
			((Component)Player.Instance).transform.Rotate(0f, FcRotation, 0f);
		}
		if (UnityInput.Current.GetKey((KeyCode)306))
		{
			Transform transform5 = ((Component)Player.Instance).transform;
			transform5.position += ((Component)Player.Instance.headCollider).transform.up * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)32))
		{
			Transform transform6 = ((Component)Player.Instance).transform;
			transform6.position += ((Component)Player.Instance.headCollider).transform.up * Time.deltaTime * FCJumpSpeed;
		}
		((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
	}

	public static void keymovement()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		((Component)GorillaTagger.Instance.leftHandTransform).transform.position = GameObject.Find("head").gameObject.transform.position;
		((Component)GorillaTagger.Instance.rightHandTransform).transform.position = GameObject.Find("head").gameObject.transform.position;
		if (UnityInput.Current.GetKey((KeyCode)119))
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * FCMovmentSpeed;
		}
		if (UnityInput.Current.GetKey((KeyCode)115))
		{
			Transform transform2 = ((Component)Player.Instance).transform;
			transform2.position += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)100))
		{
			Transform transform3 = ((Component)Player.Instance).transform;
			transform3.position += ((Component)Player.Instance.headCollider).transform.right * Time.deltaTime * FCMovmentSpeed;
		}
		if (UnityInput.Current.GetKey((KeyCode)97))
		{
			Transform transform4 = ((Component)Player.Instance).transform;
			transform4.position += ((Component)Player.Instance.headCollider).transform.right * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)113))
		{
			((Component)Player.Instance).transform.Rotate(0f, -1f, 0f);
		}
		if (UnityInput.Current.GetKey((KeyCode)101))
		{
			((Component)Player.Instance).transform.Rotate(0f, 1f, 0f);
		}
		if (UnityInput.Current.GetKey((KeyCode)306))
		{
			Transform transform5 = ((Component)Player.Instance).transform;
			transform5.position += ((Component)Player.Instance.headCollider).transform.up * Time.deltaTime * (0f - FCMovmentSpeed);
		}
		if (UnityInput.Current.GetKey((KeyCode)32))
		{
			Transform transform6 = ((Component)Player.Instance).transform;
			transform6.position += ((Component)Player.Instance.headCollider).transform.up * Time.deltaTime * FCMovmentSpeed;
		}
		((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
	}
}
