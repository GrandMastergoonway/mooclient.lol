using GorillaLocomotion;
using HarmonyLib;
using StupidTemplate.Menu;
using UnityEngine;

namespace Iron.Patches;

[HarmonyPatch(typeof(Player))]
[HarmonyPatch(/*Could not decode attribute arguments.*/)]
internal class TeleportPatch
{
	public static bool doTeleport;

	public static Vector3 telePos;

	public static bool Prefix(Player __instance, ref Vector3 ___lastPosition, ref Vector3 ___lastHeadPosition, ref Vector3 ___lastLeftHandPosition, ref Vector3 ___lastRightHandPosition, ref Vector3[] ___velocityHistory, ref Vector3 ___currentVelocity)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (doTeleport)
		{
			((Component)((Component)Player.Instance).GetComponent<Rigidbody>()).transform.position = Main.World2Player(telePos);
			___lastPosition = telePos;
			___lastHeadPosition = ((Component)Player.Instance.headCollider).transform.position;
			___lastLeftHandPosition = telePos;
			___lastRightHandPosition = telePos;
			___velocityHistory = (Vector3[])(object)new Vector3[Player.Instance.velocityHistorySize];
			___currentVelocity = ((Component)Player.Instance).GetComponent<Rigidbody>().velocity;
			doTeleport = false;
			return true;
		}
		return true;
	}
}
