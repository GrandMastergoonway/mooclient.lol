using System;
using BepInEx;
using GorillaLocomotion;
using UnityEngine;
using UnityEngine.XR;

namespace Iron_BackGround;

internal class Nigger
{
	public class GunLibData
	{
		public VRRig lockedPlayer { get; set; }

		public bool isShooting { get; set; }

		public bool isLocked { get; set; }

		public Vector3 hitPosition { get; set; }

		public bool isTriggered { get; set; }

		public GunLibData(bool stateTriggered, bool triggy, bool foundPlayer, VRRig player = null, Vector3 hitpos = default(Vector3))
		{
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			lockedPlayer = player;
			isShooting = stateTriggered;
			isLocked = foundPlayer;
			hitPosition = hitpos;
			isTriggered = triggy;
		}
	}

	private static GameObject pointer;

	private static LineRenderer lr;

	private static GunLibData data = new GunLibData(stateTriggered: false, triggy: false, foundPlayer: false);

	public static void GunCleanUp()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)pointer == (Object)null) && !((Object)(object)lr == (Object)null))
		{
			Object.Destroy((Object)(object)pointer);
			pointer = null;
			Object.Destroy((Object)(object)((Component)lr).gameObject);
			lr = null;
			data = new GunLibData(stateTriggered: false, triggy: false, foundPlayer: false);
		}
	}

	public static GunLibData ShootLock()
	{
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_0587: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0417: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_0437: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0861: Unknown result type (might be due to invalid IL or missing references)
		//IL_0881: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0902: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Expected O, but got Unknown
		//IL_0944: Unknown result type (might be due to invalid IL or missing references)
		//IL_0954: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_0621: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0711: Unknown result type (might be due to invalid IL or missing references)
		//IL_0728: Unknown result type (might be due to invalid IL or missing references)
		//IL_0689: Unknown result type (might be due to invalid IL or missing references)
		//IL_0690: Expected O, but got Unknown
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_064f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0809: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c6: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			RaycastHit val2 = default(RaycastHit);
			if (XRSettings.isDeviceActive)
			{
				data.isShooting = ((ControllerInputPoller)ControllerInputPoller.instance).rightGrab;
				data.isTriggered = ((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f;
				if (data.isShooting)
				{
					Renderer val = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
					if ((Object)(object)data.lockedPlayer == (Object)null && !data.isLocked)
					{
						if (Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, ref val2) && (Object)(object)pointer == (Object)null)
						{
							pointer = GameObject.CreatePrimitive((PrimitiveType)0);
							Object.Destroy((Object)(object)pointer.GetComponent<Rigidbody>());
							Object.Destroy((Object)(object)pointer.GetComponent<SphereCollider>());
							pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
							val = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
							val.material.color = Color.red;
							val.material.shader = Shader.Find("GUI/Text Shader");
						}
						if ((Object)(object)lr == (Object)null)
						{
							GameObject val3 = new GameObject("line");
							lr = val3.AddComponent<LineRenderer>();
							lr.endWidth = 0.01f;
							lr.startWidth = 0.01f;
							((Renderer)lr).material.shader = Shader.Find("GUI/Text Shader");
						}
						lr.SetPosition(0, Player.Instance.rightControllerTransform.position);
						lr.SetPosition(1, ((RaycastHit)(ref val2)).point);
						data.hitPosition = ((RaycastHit)(ref val2)).point;
						pointer.transform.position = ((RaycastHit)(ref val2)).point;
						VRRig componentInParent = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>();
						if ((Object)(object)componentInParent != (Object)null)
						{
							if (data.isTriggered)
							{
								data.lockedPlayer = componentInParent;
								data.isLocked = true;
								lr.startColor = Color.blue;
								lr.endColor = Color.blue;
								val.material.color = Color.blue;
							}
							else
							{
								data.isLocked = false;
								lr.startColor = Color.green;
								lr.endColor = Color.green;
								val.material.color = Color.green;
								GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
							}
						}
						else
						{
							data.isLocked = false;
							lr.startColor = Color.red;
							lr.endColor = Color.red;
							val.material.color = Color.red;
						}
					}
					if (data.isTriggered && (Object)(object)data.lockedPlayer != (Object)null)
					{
						data.isLocked = true;
						lr.SetPosition(0, Player.Instance.rightControllerTransform.position);
						lr.SetPosition(1, ((Component)data.lockedPlayer).transform.position);
						data.hitPosition = ((Component)data.lockedPlayer).transform.position;
						pointer.transform.position = ((Component)data.lockedPlayer).transform.position;
						lr.startColor = Color.blue;
						lr.endColor = Color.blue;
						val.material.color = Color.blue;
					}
					else if ((Object)(object)data.lockedPlayer != (Object)null)
					{
						data.isLocked = false;
						data.lockedPlayer = null;
						lr.startColor = Color.red;
						lr.endColor = Color.red;
						val.material.color = Color.red;
					}
				}
				else
				{
					GunCleanUp();
				}
				return data;
			}
			data.isShooting = UnityInput.Current.GetMouseButton(1);
			data.isTriggered = UnityInput.Current.GetMouseButton(0);
			if (data.isShooting)
			{
				Renderer val4 = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
				if ((Object)(object)data.lockedPlayer == (Object)null && !data.isLocked)
				{
					Ray val5 = (((Object)(object)GameObject.Find("Shoulder Camera").GetComponent<Camera>() != (Object)null) ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
					if (Physics.Raycast(((Ray)(ref val5)).origin, ((Ray)(ref val5)).direction, ref val2) && (Object)(object)pointer == (Object)null)
					{
						pointer = GameObject.CreatePrimitive((PrimitiveType)0);
						Object.Destroy((Object)(object)pointer.GetComponent<Rigidbody>());
						Object.Destroy((Object)(object)pointer.GetComponent<SphereCollider>());
						pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
						val4 = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
						val4.material.color = Color.red;
						val4.material.shader = Shader.Find("GUI/Text Shader");
					}
					if ((Object)(object)lr == (Object)null)
					{
						GameObject val6 = new GameObject("line");
						lr = val6.AddComponent<LineRenderer>();
						lr.endWidth = 0.01f;
						lr.startWidth = 0.01f;
						((Renderer)lr).material.shader = Shader.Find("GUI/Text Shader");
					}
					lr.SetPosition(0, ((Component)Player.Instance.headCollider).transform.position);
					lr.SetPosition(1, ((RaycastHit)(ref val2)).point);
					data.hitPosition = ((RaycastHit)(ref val2)).point;
					pointer.transform.position = ((RaycastHit)(ref val2)).point;
					VRRig componentInParent2 = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>();
					if ((Object)(object)componentInParent2 != (Object)null && (Object)(object)data.lockedPlayer == (Object)null)
					{
						if (data.isTriggered)
						{
							data.lockedPlayer = componentInParent2;
							data.isLocked = true;
						}
						else
						{
							data.isLocked = false;
							lr.startColor = Color.green;
							lr.endColor = Color.green;
							val4.material.color = Color.green;
						}
					}
					else
					{
						data.isLocked = false;
						lr.startColor = Color.red;
						lr.endColor = Color.red;
						val4.material.color = Color.red;
					}
				}
				if ((Object)(object)val4 != (Object)null)
				{
					if (data.isTriggered && (Object)(object)data.lockedPlayer != (Object)null)
					{
						lr.SetPosition(0, Player.Instance.rightControllerTransform.position);
						lr.SetPosition(1, ((Component)data.lockedPlayer).transform.position);
						data.hitPosition = ((Component)data.lockedPlayer).transform.position;
						pointer.transform.position = ((Component)data.lockedPlayer).transform.position;
						data.isLocked = true;
						lr.startColor = Color.blue;
						lr.endColor = Color.blue;
						val4.material.color = Color.blue;
					}
					else if ((Object)(object)data.lockedPlayer != (Object)null)
					{
						data.isLocked = false;
						data.lockedPlayer = null;
						lr.startColor = Color.red;
						lr.endColor = Color.red;
						val4.material.color = Color.red;
					}
				}
			}
			else
			{
				GunCleanUp();
			}
			return data;
		}
		catch (Exception ex)
		{
			Debug.Log((object)ex.ToString());
			return null;
		}
	}

	public static GunLibData Shoot()
	{
		//IL_03e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Expected O, but got Unknown
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_0552: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d1: Expected O, but got Unknown
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_064b: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d8: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			if (XRSettings.isDeviceActive)
			{
				data.isShooting = ((ControllerInputPoller)ControllerInputPoller.instance).rightGrab;
				data.isTriggered = ((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f;
				if (data.isShooting)
				{
					Renderer val = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
					RaycastHit val2 = default(RaycastHit);
					if (Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, ref val2) && (Object)(object)pointer == (Object)null)
					{
						pointer = GameObject.CreatePrimitive((PrimitiveType)0);
						Object.Destroy((Object)(object)pointer.GetComponent<Rigidbody>());
						Object.Destroy((Object)(object)pointer.GetComponent<SphereCollider>());
						pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
						val = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
						val.material.color = Color.red;
						val.material.shader = Shader.Find("GUI/Text Shader");
					}
					if ((Object)(object)lr == (Object)null)
					{
						GameObject val3 = new GameObject("line");
						lr = val3.AddComponent<LineRenderer>();
						lr.endWidth = 0.01f;
						lr.startWidth = 0.01f;
						((Renderer)lr).material.shader = Shader.Find("GUI/Text Shader");
					}
					lr.SetPosition(0, Player.Instance.rightControllerTransform.position);
					lr.SetPosition(1, ((RaycastHit)(ref val2)).point);
					data.hitPosition = ((RaycastHit)(ref val2)).point;
					pointer.transform.position = ((RaycastHit)(ref val2)).point;
					VRRig componentInParent = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>();
					if ((Object)(object)componentInParent != (Object)null)
					{
						if (data.isTriggered)
						{
							data.lockedPlayer = componentInParent;
							data.isLocked = true;
							val.material.color = Color.gray;
							lr.startColor = Color.gray;
							lr.endColor = Color.gray;
						}
						else
						{
							lr.startColor = Color.black;
							lr.endColor = Color.black;
							val.material.color = Color.black;
							data.isLocked = false;
							GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 3f, GorillaTagger.Instance.tagHapticDuration / 2f);
						}
					}
					else
					{
						lr.startColor = Color.red;
						lr.endColor = Color.red;
						val.material.color = Color.red;
						data.isLocked = false;
					}
				}
				else
				{
					GunCleanUp();
				}
				return data;
			}
			data.isShooting = true;
			data.isTriggered = UnityInput.Current.GetMouseButton(0);
			Renderer val4 = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
			Ray val5 = (((Object)(object)GameObject.Find("Shoulder Camera").GetComponent<Camera>() != (Object)null) ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
			RaycastHit val6 = default(RaycastHit);
			if (Physics.Raycast(((Ray)(ref val5)).origin, ((Ray)(ref val5)).direction, ref val6) && (Object)(object)pointer == (Object)null)
			{
				pointer = GameObject.CreatePrimitive((PrimitiveType)0);
				Object.Destroy((Object)(object)pointer.GetComponent<Rigidbody>());
				Object.Destroy((Object)(object)pointer.GetComponent<SphereCollider>());
				pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				val4 = (((Object)(object)pointer != (Object)null) ? pointer.GetComponent<Renderer>() : null);
				val4.material.color = Color.red;
				val4.material.shader = Shader.Find("GUI/Text Shader");
			}
			if ((Object)(object)lr == (Object)null)
			{
				GameObject val7 = new GameObject("line");
				lr = val7.AddComponent<LineRenderer>();
				lr.endWidth = 0.01f;
				lr.startWidth = 0.01f;
				((Renderer)lr).material.shader = Shader.Find("GUI/Text Shader");
			}
			lr.SetPosition(0, ((Component)Player.Instance.headCollider).transform.position);
			lr.SetPosition(1, ((RaycastHit)(ref val6)).point);
			data.hitPosition = ((RaycastHit)(ref val6)).point;
			pointer.transform.position = ((RaycastHit)(ref val6)).point;
			VRRig componentInParent2 = ((Component)((RaycastHit)(ref val6)).collider).GetComponentInParent<VRRig>();
			if ((Object)(object)componentInParent2 != (Object)null)
			{
				if (data.isTriggered)
				{
					data.isLocked = true;
					lr.startColor = Color.gray;
					lr.endColor = Color.gray;
					val4.material.color = Color.gray;
				}
				else
				{
					data.isLocked = false;
					lr.startColor = Color.black;
					lr.endColor = Color.black;
					val4.material.color = Color.black;
				}
			}
			else
			{
				data.isLocked = false;
				lr.startColor = Color.red;
				lr.endColor = Color.red;
				val4.material.color = Color.red;
			}
			return data;
		}
		catch (Exception ex)
		{
			Debug.Log((object)ex.ToString());
			return null;
		}
	}
}
