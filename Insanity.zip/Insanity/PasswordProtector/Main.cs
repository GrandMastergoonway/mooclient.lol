using System;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using BepInEx;
using Photon.Pun;
using StupidTemplate.Notifications;
using UnityEngine;

namespace PasswordProtector;

[BepInPlugin("org.skellon.skellonmenu.passwordprotector", "PasswordProtector", "1.0.0")]
internal class Main : BaseUnityPlugin
{
	private static Rect windowRect = new Rect(467f, 738f, 215f, 97f);

	public static bool MenuUnlocked = false;

	private static bool Destroyed = false;

	private static bool GeneratedPassword = false;

	private static string GivenPassword = "[KEY HERE]";

	private static string Password = "";

	private void OnGUI()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		float num = (float)Time.frameCount / 180f % 1f;
		Color val = Color.HSVToRGB(num, 1f, 1f);
		GUI.backgroundColor = Color.red;
		if (!MenuUnlocked && !Destroyed)
		{
			windowRect = GUILayout.Window(849839398, windowRect, new WindowFunction(ProtectGUI), "RedRum Client Loader Protector", Array.Empty<GUILayoutOption>());
		}
		else
		{
			windowRect = new Rect(467f, 738f, 215f, 97f);
		}
	}

	private void Update()
	{
		if (!Destroyed && !MenuUnlocked && UnityInput.Current.GetKey((KeyCode)13))
		{
			if (!GeneratedPassword)
			{
				GivenPassword = "Generate The Key First!";
			}
			else
			{
				CheckPassword(Password);
			}
		}
	}

	private void ProtectGUI(int windowID)
	{
		GUILayout.BeginVertical(Array.Empty<GUILayoutOption>());
		GUILayout.Label("Key Here :", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(200f) });
		GivenPassword = GUILayout.TextField(GivenPassword, (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(225f),
			GUILayout.Height(47f)
		});
		if (GUILayout.Button("Generate Key", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(175f),
			GUILayout.Height(32f)
		}))
		{
			if (!GeneratedPassword)
			{
				GeneratePassword();
			}
			else
			{
				GivenPassword = "Key Already Generated!";
			}
		}
		if (GUILayout.Button("Submit Key", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(175f),
			GUILayout.Height(32f)
		}))
		{
			if (!GeneratedPassword)
			{
				GivenPassword = "Generate The key First!";
			}
			else
			{
				CheckPassword(Password);
			}
		}
		GUILayout.EndVertical();
	}

	private char GetLetter()
	{
		string text = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&";
		Random random = new Random();
		int index = random.Next(0, text.Length);
		return text[index];
	}

	private async void GeneratePassword()
	{
		try
		{
			string Value1 = GetLetter().ToString();
			string Value2 = GetLetter().ToString();
			string Value3 = GetLetter().ToString();
			string Value4 = GetLetter().ToString();
			string Value5 = GetLetter().ToString();
			string Value6 = GetLetter().ToString();
			string Value7 = GetLetter().ToString();
			string Value8 = GetLetter().ToString();
			string Value9 = GetLetter().ToString();
			string Value10 = GetLetter().ToString();
			Password += Value1;
			Password += Value2;
			Password += Value3;
			Password += Value4;
			Password += Value5;
			Password += Value6;
			Password += Value7;
			Password += Value8;
			Password += Value9;
			Password += Value10;
			SendMessageToWebhook("Generated Key ```" + Password + "``` For User [" + PhotonNetwork.LocalPlayer.NickName.ToLower() + "]", "https://discord.com/api/webhooks/1253564614852083722/ZZDkd-cRjfYfWK859TXcwraQzPX9oVr0qnnQZJIVCS-rfjyETQHBrgvHUMKQDuTelb0Y");
			GeneratedPassword = true;
			GivenPassword = "Generated Key!";
		}
		catch
		{
			GivenPassword = "ERROR GENERATING KEY!";
			await Task.Delay(1000);
			GivenPassword = "Retrying...";
			GeneratePassword();
		}
	}

	private async void CheckPassword(string password)
	{
		try
		{
			if (GivenPassword == password)
			{
				GivenPassword = "Unlocking Menu....";
				await Task.Delay(1250);
				MenuUnlocked = true;
				SendMessageToWebhook("Player [" + PhotonNetwork.LocalPlayer.NickName.ToLower().ToString() + "] Unlocked [RedRum Cleint]", "https://discord.com/api/webhooks/1253564614852083722/ZZDkd-cRjfYfWK859TXcwraQzPX9oVr0qnnQZJIVCS-rfjyETQHBrgvHUMKQDuTelb0Y");
			}
			else
			{
				GivenPassword = "Wrong Key!";
				await Task.Delay(750);
				ErrorMessage();
			}
		}
		catch
		{
			CheckPassword(password);
		}
	}

	public static void SendMessageToWebhook(string message, string webhook)
	{
		try
		{
			WebClient webClient = new WebClient();
			webClient.Headers.Add("Content-Type", "application/json");
			string s = "{\"content\": \"" + message + "\"}";
			webClient.UploadData(webhook, Encoding.UTF8.GetBytes(s));
		}
		catch
		{
			MenuUnlocked = false;
			NotifiLib.SendNotification("Error with Protector, Menu Locked.");
		}
	}

	private async void ErrorMessage()
	{
		try
		{
			SendMessageToWebhook("Player [" + PhotonNetwork.LocalPlayer.NickName.ToLower() + "] Failed To Unlock!", "https://discord.com/api/webhooks/1253564614852083722/ZZDkd-cRjfYfWK859TXcwraQzPX9oVr0qnnQZJIVCS-rfjyETQHBrgvHUMKQDuTelb0Y");
			await Task.Delay(1500);
		}
		catch
		{
			ErrorMessage();
		}
	}
}
