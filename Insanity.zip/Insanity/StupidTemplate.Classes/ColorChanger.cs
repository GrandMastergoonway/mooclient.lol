using UnityEngine;

namespace StupidTemplate.Classes;

public class ColorChanger : TimedBehaviour
{
	public Renderer renderer;

	public ExtGradient colorInfo;

	public override void Start()
	{
		base.Start();
		renderer = ((Component)this).GetComponent<Renderer>();
		Update();
	}

	public override void Update()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (colorInfo == null)
		{
			return;
		}
		if (!colorInfo.copyRigColors)
		{
			Color color = new Gradient
			{
				colorKeys = colorInfo.colors
			}.Evaluate(Time.time / 2f % 1f);
			if (colorInfo.isRainbow)
			{
				float num = (float)Time.frameCount / 180f % 1f;
				color = Color.HSVToRGB(num, 1f, 1f);
			}
			renderer.material.color = color;
		}
		else
		{
			renderer.material = ((Renderer)GorillaTagger.Instance.offlineVRRig.mainSkin).material;
		}
	}
}
