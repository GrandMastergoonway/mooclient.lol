using UnityEngine;

namespace StupidTemplate.Classes;

public class ExtGradient
{
	public GradientColorKey[] colors = (GradientColorKey[])(object)new GradientColorKey[3]
	{
		new GradientColorKey(Color.gray, 0f),
		new GradientColorKey(Color.gray, 0.5f),
		new GradientColorKey(Color.gray, 1f)
	};

	public bool isRainbow = false;

	public bool copyRigColors = false;
}
