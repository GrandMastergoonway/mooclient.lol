using BepInEx;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace StupidTemplate.Classes;

internal class RigManager : BaseUnityPlugin
{
	public static PhotonView GetViewFromPlayer(Player p)
	{
		return RigToView(GorillaGameManager.instance.FindPlayerVRRig(p));
	}

	public static PhotonView RigToView(VRRig p)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		return (PhotonView)Traverse.Create((object)p).Field("photonView").GetValue();
	}

	public static VRRig GetVRRigFromPlayer(Player p)
	{
		return GorillaGameManager.instance.FindPlayerVRRig(p);
	}

	public static VRRig GetRandomVRRig(bool includeSelf)
	{
		VRRig val = ((GorillaParent)GorillaParent.instance).vrrigs[Random.Range(0, ((GorillaParent)GorillaParent.instance).vrrigs.Count - 1)];
		if (includeSelf)
		{
			return val;
		}
		if ((Object)(object)val != (Object)(object)GorillaTagger.Instance.offlineVRRig)
		{
			return val;
		}
		return GetRandomVRRig(includeSelf);
	}

	public static VRRig GetRigFromPlayer(Player p)
	{
		return GorillaGameManager.instance.FindPlayerVRRig(p);
	}

	public static Player GetPlayerFromRig(VRRig rig)
	{
		return rig2view(rig).Owner;
	}

	public static PhotonView rig2view(VRRig p)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		return (PhotonView)Traverse.Create((object)p).Field("photonView").GetValue();
	}

	public static VRRig GetClosestVRRig()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		float num = float.MaxValue;
		VRRig result = null;
		foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			if (Vector3.Distance(((Component)GorillaTagger.Instance.bodyCollider).transform.position, ((Component)vrrig).transform.position) < num)
			{
				num = Vector3.Distance(((Component)GorillaTagger.Instance.bodyCollider).transform.position, ((Component)vrrig).transform.position);
				result = vrrig;
			}
		}
		return result;
	}

	public static PhotonView GetPhotonViewFromVRRig(VRRig p)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		return (PhotonView)Traverse.Create((object)p).Field("photonView").GetValue();
	}

	public static Player GetRandomPlayer(bool includeSelf)
	{
		if (includeSelf)
		{
			return PhotonNetwork.PlayerList[Random.Range(0, PhotonNetwork.PlayerList.Length - 1)];
		}
		return PhotonNetwork.PlayerListOthers[Random.Range(0, PhotonNetwork.PlayerListOthers.Length - 1)];
	}

	public static Player GetPlayerFromVRRig(VRRig p)
	{
		return GetPhotonViewFromVRRig(p).Owner;
	}

	public static Player GetPlayerFromID(string id)
	{
		Player result = null;
		Player[] playerList = PhotonNetwork.PlayerList;
		foreach (Player val in playerList)
		{
			if (val.UserId == id)
			{
				result = val;
				break;
			}
		}
		return result;
	}
}
