using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Mods;

namespace StupidTemplate.Menu;

internal class Buttons
{
	public static ButtonInfo[][] buttons = new ButtonInfo[8][]
	{
		new ButtonInfo[6]
		{
			new ButtonInfo
			{
				buttonText = "Config",
				method = delegate
				{
					SettingsMods.EnterSettings();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Overpowered",
				method = delegate
				{
					SettingsMods.Overpowered();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Movement",
				method = delegate
				{
					SettingsMods.Movement();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Spams",
				method = delegate
				{
					SettingsMods.Spams();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Advantages",
				method = delegate
				{
					SettingsMods.Advantages();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Environment",
				method = delegate
				{
					SettingsMods.Environment();
				},
				isTogglable = false,
				toolTip = "Opens the main settings page for the menu."
			}
		},
		new ButtonInfo[11]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = "Returns to the main page of the menu."
			},
			new ButtonInfo
			{
				buttonText = "Menu",
				method = delegate
				{
					OverPowered.HuntGamemode();
				},
				isTogglable = false,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "AntiReport",
				method = delegate
				{
					Saftey.AntiReportv2();
				},
				enabled = true,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Change Fly Speed",
				method = delegate
				{
					Movement.ChangeFlySpeed();
				},
				enabled = false,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ChangeFontType",
				method = delegate
				{
					OverPowered.ChangeFontType();
				},
				enabled = false,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ChangeButtonSound",
				method = delegate
				{
					OverPowered.ChangeButtonSound();
				},
				enabled = false,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Right Hand",
				enableMethod = delegate
				{
					SettingsMods.RightHand();
				},
				disableMethod = delegate
				{
					SettingsMods.LeftHand();
				},
				toolTip = "Puts the menu on your right hand."
			},
			new ButtonInfo
			{
				buttonText = "Notifications",
				enableMethod = delegate
				{
					SettingsMods.EnableNotifications();
				},
				disableMethod = delegate
				{
					SettingsMods.DisableNotifications();
				},
				enabled = !Settings.disableNotifications,
				toolTip = "Toggles the notifications."
			},
			new ButtonInfo
			{
				buttonText = "FPS Counter",
				enableMethod = delegate
				{
					SettingsMods.EnableFPSCounter();
				},
				disableMethod = delegate
				{
					SettingsMods.DisableFPSCounter();
				},
				enabled = Settings.fpsCounter,
				toolTip = "Toggles the FPS counter."
			},
			new ButtonInfo
			{
				buttonText = "Distance ESP",
				method = delegate
				{
					OverPowered.CasualDistanceESP();
				},
				enabled = true,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Menu Outline",
				method = delegate
				{
					SettingsMods.EnableMenuOutline();
				},
				enabled = true,
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			}
		},
		new ButtonInfo[24]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = "Returns to the main page of the menu."
			},
			new ButtonInfo
			{
				buttonText = "AntiBan",
				method = delegate
				{
					OverPowered.Antiban();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SetMaster",
				method = delegate
				{
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
				},
				isTogglable = false,
				toolTip = ""
			},
			new ButtonInfo
			{
				buttonText = "Nuke Server",
				method = delegate
				{
					OverPowered.CrashAll2();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Nuke Gun",
				method = delegate
				{
					OverPowered.CrashGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "NukeOnTouch",
				method = delegate
				{
					OverPowered.CrashOnTouch();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LagAll",
				method = delegate
				{
					OverPowered.LagAll2();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LagGun",
				method = delegate
				{
					OverPowered.LagGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Destroy Movement",
				method = delegate
				{
					OverPowered.DestroyMovement();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "FreezeAll",
				method = delegate
				{
					OverPowered.FreezeAll();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "FloatGun[Buggy]",
				method = delegate
				{
					OverPowered.FloatGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "FreezeGun[Buggy] Monsters",
				method = delegate
				{
					OverPowered.FreezeGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Namechangeall",
				method = delegate
				{
					OverPowered.Namechangeall();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "HuntGamemode",
				method = delegate
				{
					OverPowered.HuntGamemode();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "InfectionGamemode",
				method = delegate
				{
					OverPowered.InfectionGamemode();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "BattleGamemode",
				method = delegate
				{
					OverPowered.BattleGamemode();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CasualGamemode",
				method = delegate
				{
					OverPowered.CasualGamemode();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Spaz Gamemodes",
				method = delegate
				{
					OverPowered.SpazManemodes();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Party Kick Too Redrum.Client",
				method = delegate
				{
					OverPowered.KickAllInParty();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TapAllBells",
				method = delegate
				{
					OverPowered.TapAllBells();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TapAllCrystals",
				method = delegate
				{
					OverPowered.TapAllCrystals();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ActivateAllDoors",
				method = delegate
				{
					OverPowered.ActivateAllDoors();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Name Change[Custom Gui]",
				method = delegate
				{
					OverPowered.NameChangeAll();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Break Your Movement",
				method = delegate
				{
					OverPowered.Breakurmovement();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			}
		},
		new ButtonInfo[51]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = "Returns to the main page of the menu."
			},
			new ButtonInfo
			{
				buttonText = "PlatformGun",
				method = delegate
				{
					Movement.PlatformGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Frozone",
				method = delegate
				{
					Movement.Frozone();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "PlatformSpam",
				method = delegate
				{
					Movement.PlatformSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Fly",
				method = delegate
				{
					Movement.Fly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TriggerFly",
				method = delegate
				{
					Movement.TriggerFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "NoclipFly",
				method = delegate
				{
					Movement.NoclipFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "JoystickFly",
				method = delegate
				{
					Movement.JoystickFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "BarkFly",
				method = delegate
				{
					Movement.BarkFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "HandFly",
				method = delegate
				{
					Movement.HandFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SlingshotFly",
				method = delegate
				{
					Movement.SlingshotFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ZeroGravitySlingshotFly",
				method = delegate
				{
					Movement.ZeroGravitySlingshotFly();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Spider Nigga",
				method = delegate
				{
					Movement.SpiderMan();
				},
				disableMethod = delegate
				{
					Movement.DisableSpiderMan();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Black Man",
				method = delegate
				{
					Movement.GrapplingHooks();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Force Tag Freeze",
				method = delegate
				{
					Movement.ForceTagFreeze();
				},
				disableMethod = delegate
				{
					Movement.NoTagFreeze();
				},
				toolTip = "Forces tag freeze on your character."
			},
			new ButtonInfo
			{
				buttonText = "No Tag Freeze",
				method = delegate
				{
					Movement.NoTagFreeze();
				},
				toolTip = "Disables tag freeze on your character."
			},
			new ButtonInfo
			{
				buttonText = "Low Gravity",
				method = delegate
				{
					Movement.LowGravity();
				},
				toolTip = "Makes gravity lower on your character."
			},
			new ButtonInfo
			{
				buttonText = "Zero Gravity",
				method = delegate
				{
					Movement.ZeroGravity();
				},
				toolTip = "Disables gravity on your character."
			},
			new ButtonInfo
			{
				buttonText = "High Gravity",
				method = delegate
				{
					Movement.HighGravity();
				},
				toolTip = "Makes gravity higher on your character."
			},
			new ButtonInfo
			{
				buttonText = "Reverse Gravity",
				method = delegate
				{
					Movement.ReverseGravity();
				},
				disableMethod = delegate
				{
					Movement.UnflipCharacter();
				},
				toolTip = "Reverses gravity on your character."
			},
			new ButtonInfo
			{
				buttonText = "TeleportToRandom",
				method = delegate
				{
					Movement.TeleportToRandom();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TeleportGun",
				method = delegate
				{
					Movement.TeleportGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Airstrike",
				method = delegate
				{
					Movement.Airstrike();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "RigGun",
				method = delegate
				{
					Movement.RigGun1();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Who Ever Moves First is Gay",
				method = delegate
				{
					Movement.Ghost();
				},
				disableMethod = delegate
				{
					Movement.EnableRig();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Gone Like Your Dad",
				method = delegate
				{
					Movement.Invisible();
				},
				disableMethod = delegate
				{
					Movement.DisableInvisible();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "GrabRig",
				method = delegate
				{
					Movement.GrabRig();
				},
				disableMethod = delegate
				{
					Movement.DisableSpazRig();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Spaz",
				method = delegate
				{
					Movement.SpazRig();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SpazHead",
				method = delegate
				{
					Movement.SpazHead();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Spaz Hands",
				method = delegate
				{
					Movement.SpazHands();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Open Oculus Menu",
				method = delegate
				{
					Movement.FakeOculusMenu();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Power Off Headset",
				method = delegate
				{
					Movement.FakePowerOff();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SizeChanger",
				method = delegate
				{
					Movement.SizeChanger();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "PunchMod",
				method = delegate
				{
					Movement.PunchMod();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SolidPlayers",
				method = delegate
				{
					Movement.SolidPlayers();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ThrowControllers",
				method = delegate
				{
					Movement.ThrowControllers();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "IronMan",
				method = delegate
				{
					Movement.IronMan();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Beyblade",
				method = delegate
				{
					Movement.Beyblade();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Helicopter",
				method = delegate
				{
					Movement.Helicopter();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "StareAtGun[This has the best gunlib]",
				method = delegate
				{
					Movement.StareAtGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "StareAtNearby",
				method = delegate
				{
					Movement.StareAtNearby();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "FollowPlayerGun",
				method = delegate
				{
					Movement.FollowPlayerGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "OrbitPlayerGun",
				method = delegate
				{
					Movement.OrbitPlayerGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CopyMovementGun",
				method = delegate
				{
					Movement.CopyMovementGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "PiggybackGun",
				method = delegate
				{
					Movement.PiggybackGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "JumpscareGun",
				method = delegate
				{
					Movement.JumpscareGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Fuck Gun",
				method = delegate
				{
					Movement.IntercourseGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "WaterSplashHands",
				method = delegate
				{
					Movement.WaterSplashHands();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LoudMicrophone",
				method = delegate
				{
					Movement.LoudMicrophone();
				},
				disableMethod = delegate
				{
					Movement.NotLoudMicrophone();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LowQualityMicrophone",
				method = delegate
				{
					Movement.LowQualityMicrophone();
				},
				disableMethod = delegate
				{
					Movement.ReloadMicrophone();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Inf ShinyRocks",
				method = delegate
				{
					Spams.InfShinyRocks();
				},
				disableMethod = delegate
				{
					Movement.ReloadMicrophone();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			}
		},
		new ButtonInfo[33]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = ""
			},
			new ButtonInfo
			{
				buttonText = "CatSoundSpam",
				method = delegate
				{
					Spams.CatSoundSpam();
				},
				isTogglable = true,
				toolTip = ""
			},
			new ButtonInfo
			{
				buttonText = "BassSoundSpam",
				method = delegate
				{
					Spams.BassSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "BeeSoundSpam",
				method = delegate
				{
					Spams.BeeSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CrystalSoundSpam",
				method = delegate
				{
					Spams.CrystalSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "BigCrystalSoundSpam",
				method = delegate
				{
					Spams.BigCrystalSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "DingSoundSpam",
				method = delegate
				{
					Spams.DingSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "EarrapeSoundSpam",
				method = delegate
				{
					Spams.EarrapeSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "FrogSoundSpam",
				method = delegate
				{
					Spams.FrogSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MetalSoundSpam",
				method = delegate
				{
					Spams.MetalSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "PanSoundSpam",
				method = delegate
				{
					Spams.PanSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "RandomSoundSpam",
				method = delegate
				{
					Spams.RandomSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SirenSoundSpam",
				method = delegate
				{
					Spams.SirenSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SqueakSoundSpam",
				method = delegate
				{
					Spams.SqueakSoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TurkeySoundSpam",
				method = delegate
				{
					Spams.TurkeySoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ProjSpammer",
				method = delegate
				{
					Spams.ProjectileSpammer();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "ProjHalo",
				method = delegate
				{
					Spams.ProjHalo();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SnowSpam",
				method = delegate
				{
					Spams.SnowSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "WaterSpam",
				method = delegate
				{
					Spams.waterballoonspam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CaneSpam",
				method = delegate
				{
					Spams.CaneSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "RollSpam",
				method = delegate
				{
					Spams.RollSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "WaterSpam",
				method = delegate
				{
					Spams.RoundSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LavaSpam",
				method = delegate
				{
					Spams.LavaSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "GaySpam",
				method = delegate
				{
					Spams.GaySpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CupidSpam",
				method = delegate
				{
					Spams.CupidSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "LeafSpam",
				method = delegate
				{
					Spams.LeafSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "SpiderSpam",
				method = delegate
				{
					Spams.SpiderSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "DevilSpam",
				method = delegate
				{
					Spams.DevilSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "DragonArrow",
				method = delegate
				{
					Spams.DragonArrow();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "DragonSpam",
				method = delegate
				{
					Spams.DragonSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MoltenSpam",
				method = delegate
				{
					Spams.MoltenSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "CoalSpam",
				method = delegate
				{
					Spams.CoalSpam();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Make Spams Miniguns",
				method = delegate
				{
					Spams.MiniGun();
				},
				disableMethod = delegate
				{
					Spams.reset();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			}
		},
		new ButtonInfo[11]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = "Returns to the main page of the menu."
			},
			new ButtonInfo
			{
				buttonText = "TagGun",
				method = delegate
				{
					Advantages.TagGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TagAll",
				method = delegate
				{
					Advantages.TagAll();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MatAll",
				method = delegate
				{
					Advantages.MatAll();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MatGun",
				method = delegate
				{
					Advantages.MatGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MatSelf",
				method = delegate
				{
					Advantages.MatSelf();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "UntagSelf",
				method = delegate
				{
					Advantages.UntagSelf();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "UntagAll",
				method = delegate
				{
					Advantages.UntagAll();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "UntagGun",
				method = delegate
				{
					Advantages.UntagGun();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "NoTagOnJoin",
				method = delegate
				{
					Advantages.NoTagOnJoin();
				},
				disableMethod = delegate
				{
					Advantages.TagOnJoin();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "TagAura",
				method = delegate
				{
					Advantages.TagAura();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			}
		},
		new ButtonInfo[35]
		{
			new ButtonInfo
			{
				buttonText = "Return to Main",
				method = delegate
				{
					Global.ReturnHome();
				},
				isTogglable = false,
				toolTip = "Returns to the main page of the menu."
			},
			new ButtonInfo
			{
				buttonText = "Rain",
				method = delegate
				{
					Environment.Rain();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Stop Rain",
				method = delegate
				{
					Environment.NoRain();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Fullbright",
				method = delegate
				{
					Environment.Fullbright();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Shade",
				method = delegate
				{
					Environment.Fullshade();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "NightTime",
				method = delegate
				{
					Environment.NightTime();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "EveningTime",
				method = delegate
				{
					Environment.EveningTime();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "MorningTime",
				method = delegate
				{
					Environment.MorningTime();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "DayTime",
				method = delegate
				{
					Environment.DayTime();
				},
				isTogglable = true,
				toolTip = "Opens the settings for the menu."
			},
			new ButtonInfo
			{
				buttonText = "Bug Gun",
				method = delegate
				{
					Environment.BugGun();
				},
				toolTip = "Moves the bug to wherever your hand desires."
			},
			new ButtonInfo
			{
				buttonText = "Bat Gun",
				method = delegate
				{
					Environment.BatGun();
				},
				toolTip = "Moves the bat to wherever your hand desires."
			},
			new ButtonInfo
			{
				buttonText = "Beach Ball Gun",
				method = delegate
				{
					Environment.BeachBallGun();
				},
				toolTip = "Moves the beach ball to wherever your hand desires."
			},
			new ButtonInfo
			{
				buttonText = "No Respawn Bug",
				enableMethod = delegate
				{
					Environment.NoRespawnBug();
				},
				disableMethod = delegate
				{
					Environment.PleaseRespawnBug();
				},
				toolTip = "Doesn't respawn the bug if it goes too far outside the bounds of forest."
			},
			new ButtonInfo
			{
				buttonText = "No Respawn Bat",
				enableMethod = delegate
				{
					Environment.NoRespawnBat();
				},
				disableMethod = delegate
				{
					Environment.PleaseRespawnBat();
				},
				toolTip = "Doesn't respawn the bat if it goes too far outside the bounds of caves."
			},
			new ButtonInfo
			{
				buttonText = "Grab Bug <color=grey>[</color><color=green>G</color><color=grey>]</color>",
				method = delegate
				{
					Environment.GrabBug();
				},
				toolTip = "Forces the bug into your hand when holding <color=green>grip</color>."
			},
			new ButtonInfo
			{
				buttonText = "Grab Bat <color=grey>[</color><color=green>G</color><color=grey>]</color>",
				method = delegate
				{
					Environment.GrabBat();
				},
				toolTip = "Forces the bat into your hand when holding <color=green>grip</color>."
			},
			new ButtonInfo
			{
				buttonText = "Grab Beach Ball <color=grey>[</color><color=green>G</color><color=grey>]</color>",
				method = delegate
				{
					Environment.GrabBeachBall();
				},
				toolTip = "Forces the beach ball into your hand when holding <color=green>grip</color>."
			},
			new ButtonInfo
			{
				buttonText = "Destroy Bug",
				method = delegate
				{
					Environment.DestroyBug();
				},
				isTogglable = false,
				toolTip = "Sends the bug to hell."
			},
			new ButtonInfo
			{
				buttonText = "Destroy Bat",
				method = delegate
				{
					Environment.DestroyBat();
				},
				isTogglable = false,
				toolTip = "Sends the bat to hell."
			},
			new ButtonInfo
			{
				buttonText = "Destroy Beach Ball",
				method = delegate
				{
					Environment.DestroyBeachBall();
				},
				isTogglable = false,
				toolTip = "Sends the beach ball to hell."
			},
			new ButtonInfo
			{
				buttonText = "Spaz Bug",
				method = delegate
				{
					Environment.SpazBug();
				},
				toolTip = "Gives the bug a seizure."
			},
			new ButtonInfo
			{
				buttonText = "Spaz Bat",
				method = delegate
				{
					Environment.SpazBat();
				},
				toolTip = "Gives the bat a seizure."
			},
			new ButtonInfo
			{
				buttonText = "Spaz Beach Ball",
				method = delegate
				{
					Environment.SpazBeachBall();
				},
				toolTip = "Gives the beach ball a seizure."
			},
			new ButtonInfo
			{
				buttonText = "Orbit Bug",
				method = delegate
				{
					Environment.BugHalo();
				},
				toolTip = "Orbits the bug around you."
			},
			new ButtonInfo
			{
				buttonText = "Orbit Bat",
				method = delegate
				{
					Environment.BatHalo();
				},
				toolTip = "Orbits the bat around you."
			},
			new ButtonInfo
			{
				buttonText = "Orbit Beach Ball",
				method = delegate
				{
					Environment.BeachBallHalo();
				},
				toolTip = "Orbits the beach ball around you."
			},
			new ButtonInfo
			{
				buttonText = "Ride Bug",
				method = delegate
				{
					Environment.RideBug();
				},
				toolTip = "Repeatedly teleports you on top of the bug."
			},
			new ButtonInfo
			{
				buttonText = "Ride Bat",
				method = delegate
				{
					Environment.RideBat();
				},
				toolTip = "Repeatedly teleports you on top of the bat."
			},
			new ButtonInfo
			{
				buttonText = "Ride Beach Ball",
				method = delegate
				{
					Environment.RideBeachBall();
				},
				toolTip = "Repeatedly teleports you on top of the beach ball."
			},
			new ButtonInfo
			{
				buttonText = "Break Bug",
				enableMethod = delegate
				{
					Environment.BreakBug();
				},
				disableMethod = delegate
				{
					Environment.FixBug();
				},
				toolTip = "Makes the bug ungrabbable."
			},
			new ButtonInfo
			{
				buttonText = "Break Bat",
				enableMethod = delegate
				{
					Environment.BreakBat();
				},
				disableMethod = delegate
				{
					Environment.FixBat();
				},
				toolTip = "Makes the bat ungrabbable."
			},
			new ButtonInfo
			{
				buttonText = "Slow Monsters",
				enableMethod = delegate
				{
					Environment.SlowMonsters();
				},
				disableMethod = delegate
				{
					Environment.FixMonsters();
				},
				toolTip = "Slows down the basement monsters."
			},
			new ButtonInfo
			{
				buttonText = "Fast Monsters",
				enableMethod = delegate
				{
					Environment.FastMonsters();
				},
				disableMethod = delegate
				{
					Environment.FixMonsters();
				},
				toolTip = "Speeds up the basement monsters."
			},
			new ButtonInfo
			{
				buttonText = "Grab Monsters <color=grey>[</color><color=green>G</color><color=grey>]</color>",
				method = delegate
				{
					Environment.GrabMonsters();
				},
				toolTip = "Puts the basement monsters in your hand."
			},
			new ButtonInfo
			{
				buttonText = "Monster Gun",
				method = delegate
				{
					Environment.MonsterGun();
				},
				toolTip = "Moves the basement monsters to wherever your hand desires."
			}
		},
		new ButtonInfo[1]
		{
			new ButtonInfo
			{
				buttonText = "Return to Config",
				method = delegate
				{
					SettingsMods.EnterSettings();
				},
				isTogglable = false,
				toolTip = "Returns to the main settings page for the menu."
			}
		}
	};
}
