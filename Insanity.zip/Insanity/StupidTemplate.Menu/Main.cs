using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using BepInEx;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using GorillaTagScripts.ObstacleCourse;
using HarmonyLib;
using Iron.Patches;
using PasswordProtector;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Notifications;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace StupidTemplate.Menu;

[HarmonyPatch(typeof(Player))]
[HarmonyPatch(/*Could not decode attribute arguments.*/)]
public class Main : MonoBehaviour
{
	public static GameObject motd;

	public static bool hasRemovedThisFrame;

	public static Vector3 homePos = new Vector3(0.56f, 0f, -0.6f);

	public static Vector3 homeScale = new Vector3(0.09f, Settings.menuWidth - 0.1f, 0.06f);

	public static Material Face = CustomImage("https://i.imghippo.com/files/SkElq1718917216.png");

	public static ExtGradient backgroundCol = new ExtGradient
	{
		colors = GetSolidGradient(new Color(0.753f, 0.471f, 1f))
	};

	public static bool InCategory = true;

	public static GameObject OutLine;

	public static Material MenuMaterial = loadimagefromurl("https://wallpaperaccess.com/full/882327.jpg");

	public static GameObject menuBorder;

	public static GameObject Home;

	public static Color MenuColor = Color32.op_Implicit(new Color32((byte)102, (byte)51, (byte)153, (byte)1));

	public static bool isOutline = true;

	public static GliderHoldable[] archiveholdables = null;

	public static MonkeyeAI[] archivemonsters = null;

	public static BalloonHoldable[] archiveballoons = null;

	public static TappableBell[] archivebells = null;

	public static GhostLabButton[] archivelabbuttons = null;

	public static GorillaCaveCrystal[] archivecrystals = null;

	public static float lastRecievedTime;

	public static bool nigger = false;

	public static VRRig whosGay = null;

	public static VRRig whoCopy = null;

	public static bool isCopying = false;

	public static bool triggerPage = false;

	public static GameObject menu;

	public static GameObject menuBackground;

	public static GameObject reference;

	public static GameObject canvasObject;

	public static SphereCollider buttonCollider;

	public static Camera TPC;

	public static Text fpsObject;

	public static int pageNumber = 0;

	public static int buttonsType = 0;

	public static void Prefix()
	{
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			bool flag = (!Settings.rightHanded && ((ControllerInputPoller)ControllerInputPoller.instance).leftControllerSecondaryButton) || (Settings.rightHanded && ((ControllerInputPoller)ControllerInputPoller.instance).rightControllerSecondaryButton);
			bool key = UnityInput.Current.GetKey(Settings.keyboardButton);
			if ((Object)(object)menu == (Object)null)
			{
				if (flag || key)
				{
					CreateMenu();
					RecenterMenu(Settings.rightHanded, key);
					if ((Object)(object)reference == (Object)null)
					{
						CreateReference(Settings.rightHanded);
					}
				}
			}
			else if (flag || key)
			{
				RecenterMenu(Settings.rightHanded, key);
			}
			else
			{
				Component obj = menu.AddComponent(typeof(Rigidbody));
				Rigidbody val = (Rigidbody)(object)((obj is Rigidbody) ? obj : null);
				if (Settings.rightHanded)
				{
					val.velocity = Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
				}
				else
				{
					val.velocity = Player.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
				}
				Object.Destroy((Object)(object)menu, 2f);
				menu = null;
				Object.Destroy((Object)(object)reference);
				reference = null;
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)string.Format("{0} // Error initializing at {1}: {2}", "Insanity X", ex.StackTrace, ex.Message));
		}
		try
		{
			if ((Object)(object)fpsObject != (Object)null)
			{
				fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime);
			}
			ButtonInfo[][] buttons = Buttons.buttons;
			foreach (ButtonInfo[] array in buttons)
			{
				ButtonInfo[] array2 = array;
				foreach (ButtonInfo buttonInfo in array2)
				{
					if (buttonInfo.enabled && buttonInfo.method != null)
					{
						try
						{
							buttonInfo.method();
						}
						catch (Exception ex2)
						{
							Debug.LogError((object)string.Format("{0} // Error with mod {1} at {2}: {3}", "Insanity X", buttonInfo.buttonText, ex2.StackTrace, ex2.Message));
						}
					}
				}
			}
		}
		catch (Exception ex3)
		{
			Debug.LogError((object)string.Format("{0} // Error with executing mods at {1}: {2}", "Insanity X", ex3.StackTrace, ex3.Message));
		}
		try
		{
			GameObject.Find("motdtext").GetComponent<Text>().text = "HEY THANKS FOR USING <color=purple>Insanity X V:1.0.0</color>THIS MENU IS FOR OP SHIT, FUCK LEMMINGS DAD ";
			GameObject.Find("COC Text").GetComponent<Text>().text = "PLEASE KEEP IN MIND THIS IS AN ILLEGAL MOD MENU,  I AM NOT RESPONSIBLE FOR ANY BANS YOU GET, WE HAVE ANTI REPORT FOR A REASON (ANTI REPORT IN SAFETY MODS)";
			GameObject.Find("CodeOfConduct").GetComponent<Text>().text = "Insanity X";
			GameObject.Find("wallmonitorforest (1)").GetComponent<Renderer>().material.color = Color.black;
			GameObject.Find("monitor").GetComponent<Renderer>().material.color = Color.black;
			GameObject.Find("screen").GetComponent<Renderer>().material.color = Color.black;
			GameObject.Find("motdscreen").GetComponent<Renderer>().material.color = Color.black;
			GameObject val2 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd");
			Text component = motd.GetComponent<Text>();
			motd = Object.Instantiate<GameObject>(val2, val2.transform.parent);
			((Graphic)component).color = Color.magenta / 6f;
			val2.SetActive(false);
		}
		catch
		{
		}
	}

	public static Material CustomImage(string url)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Expected O, but got Unknown
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Expected O, but got Unknown
		Material val = null;
		try
		{
			using WebClient webClient = new WebClient();
			byte[] array = webClient.DownloadData(url);
			if (array == null || array.Length == 0)
			{
				Debug.LogError((object)("Empty or null data received from URL: " + url));
			}
			else
			{
				val = new Material(Shader.Find("GorillaTag/UberShader"));
				val.shaderKeywords = new string[1] { "_USE_TEXTURE" };
				Texture2D val2 = new Texture2D(2, 2);
				if (!ImageConversion.LoadImage(val2, array))
				{
					Debug.LogError((object)("Failed to load image from URL: " + url));
				}
				else
				{
					val.mainTexture = (Texture)(object)val2;
					val2.Apply();
				}
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Error downloading image from URL: " + url + "\n" + ex.Message));
		}
		return val;
	}

	public static void RPCProtection()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (!hasRemovedThisFrame)
		{
			hasRemovedThisFrame = true;
			RaiseEventOptions val = new RaiseEventOptions();
			val.CachingOption = (EventCaching)6;
			val.TargetActors = new int[1] { PhotonNetwork.LocalPlayer.ActorNumber };
			RaiseEventOptions val2 = val;
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)200, (object)null, val2, SendOptions.SendReliable);
			((GorillaNot)GorillaNot.instance).rpcErrorMax = int.MaxValue;
			((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
			((GorillaNot)GorillaNot.instance).logErrorMax = int.MaxValue;
			PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
			PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig);
			PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, (string)null, (int[])null);
			PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
			PhotonNetwork.SendAllOutgoingCommands();
			((MonoBehaviourPunCallbacks)GorillaNot.instance).OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
		}
	}

	public static Texture2D LoadTextureFromURL(string resourcePath, string fileName)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Expected O, but got Unknown
		Texture2D val = new Texture2D(2, 2);
		if (!Directory.Exists("iisStupidMenu"))
		{
			Directory.CreateDirectory("iisStupidMenu");
		}
		if (!File.Exists("Iron.cc/" + fileName))
		{
			Debug.Log((object)("Downloading " + fileName));
			WebClient webClient = new WebClient();
			webClient.DownloadFile(resourcePath, "Iron.cc/" + fileName);
		}
		byte[] array = File.ReadAllBytes("Iron.cc/" + fileName);
		ImageConversion.LoadImage(val, array);
		return val;
	}

	public static Texture2D LoadTextureFromResource(string resourcePath)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Expected O, but got Unknown
		Texture2D val = new Texture2D(2, 2);
		Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourcePath);
		if (manifestResourceStream != null)
		{
			byte[] array = new byte[manifestResourceStream.Length];
			manifestResourceStream.Read(array, 0, (int)manifestResourceStream.Length);
			ImageConversion.LoadImage(val, array);
		}
		else
		{
			Debug.LogError((object)("Failed to load texture from resource: " + resourcePath));
		}
		return val;
	}

	public static Material loadimagefromurl(string url)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Expected O, but got Unknown
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Expected O, but got Unknown
		WebClient webClient = new WebClient();
		byte[] array = webClient.DownloadData(url);
		Material val = new Material(Shader.Find("GorillaTag/UberShader"));
		val.shaderKeywords = new string[1] { "_USE_TEXTURE" };
		string dataPath = Application.dataPath;
		dataPath = dataPath.Replace("/Gorilla Tag_Data", "");
		Texture2D val2 = new Texture2D(4096, 4096);
		ImageConversion.LoadImage(val2, array);
		val.mainTexture = (Texture)(object)val2;
		val2.Apply();
		return val;
	}

	public static void CreateCategoryButton()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = GameObject.CreatePrimitive((PrimitiveType)3);
		float num = 0.6f;
		((Collider)val.GetComponent<BoxCollider>()).isTrigger = true;
		val.transform.parent = menu.transform;
		val.transform.rotation = Quaternion.identity;
		val.transform.localScale = homeScale;
		val.transform.localPosition = homePos;
		val.AddComponent<Button>().relatedText = "BackToHome";
		val.GetComponent<Renderer>().material.color = Color.magenta / 5f;
		GameObject val2 = new GameObject();
		val2.transform.parent = menu.transform;
		Text val3 = val2.AddComponent<Text>();
		val3.font = Settings.currentFont;
		val3.text = "Return";
		val3.fontSize = 1;
		((Graphic)val3).color = Color.white;
		val3.alignment = (TextAnchor)4;
		val3.fontStyle = (FontStyle)2;
		val3.resizeTextForBestFit = true;
		val3.resizeTextMinSize = 0;
		RectTransform component = ((Component)val3).GetComponent<RectTransform>();
		((Transform)component).localPosition = Vector3.zero;
		component.sizeDelta = new Vector2(0.2f, 0.03f);
		((Transform)component).localPosition = new Vector3(val.transform.position.x + 0.0046f, val.transform.position.y, val.transform.position.z);
		((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
	}

	public static void CreateMenu()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Expected O, but got Unknown
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_042c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_047b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_0548: Unknown result type (might be due to invalid IL or missing references)
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_0594: Unknown result type (might be due to invalid IL or missing references)
		//IL_0599: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0609: Unknown result type (might be due to invalid IL or missing references)
		//IL_0620: Unknown result type (might be due to invalid IL or missing references)
		//IL_063c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0658: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_071d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0734: Unknown result type (might be due to invalid IL or missing references)
		//IL_073e: Unknown result type (might be due to invalid IL or missing references)
		//IL_075a: Unknown result type (might be due to invalid IL or missing references)
		//IL_075f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0802: Unknown result type (might be due to invalid IL or missing references)
		//IL_081e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0823: Unknown result type (might be due to invalid IL or missing references)
		//IL_087d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08df: Unknown result type (might be due to invalid IL or missing references)
		if (PasswordProtector.Main.MenuUnlocked)
		{
			menu = GameObject.CreatePrimitive((PrimitiveType)3);
			Object.Destroy((Object)(object)menu.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)menu.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)menu.GetComponent<Renderer>());
			menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);
			menuBackground = GameObject.CreatePrimitive((PrimitiveType)3);
			Object.Destroy((Object)(object)menuBackground.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)menuBackground.GetComponent<BoxCollider>());
			menuBackground.transform.parent = menu.transform;
			menuBackground.transform.rotation = Quaternion.identity;
			menuBackground.transform.localScale = Settings.menuSize;
			menuBackground.GetComponent<Renderer>().material.color = Color.magenta / 6f;
			menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);
			OutLine = GameObject.CreatePrimitive((PrimitiveType)3);
			Object.Destroy((Object)(object)OutLine.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)OutLine.GetComponent<BoxCollider>());
			OutLine.transform.parent = menu.transform;
			OutLine.transform.rotation = Quaternion.identity;
			OutLine.transform.localScale = new Vector3(0.1f, 0.83f, 0.73f);
			OutLine.GetComponent<Renderer>().material.color = Color.black / 6f;
			OutLine.transform.position = new Vector3(0.04f, 0f, 0f);
			canvasObject = new GameObject();
			canvasObject.transform.parent = menu.transform;
			Canvas val = canvasObject.AddComponent<Canvas>();
			CanvasScaler val2 = canvasObject.AddComponent<CanvasScaler>();
			canvasObject.AddComponent<GraphicRaycaster>();
			val.renderMode = (RenderMode)2;
			val2.dynamicPixelsPerUnit = 1000f;
			GameObject val3 = new GameObject();
			val3.transform.parent = canvasObject.transform;
			Text val4 = val3.AddComponent<Text>();
			val4.font = Settings.currentFont;
			val4.text = "Insanity X <color=grey>[</color><color=white>" + (pageNumber + 1) + "</color><color=grey>]</color>";
			val4.fontSize = -1;
			((Graphic)val4).color = Settings.textColors[0];
			val4.supportRichText = true;
			val4.fontStyle = (FontStyle)2;
			val4.alignment = (TextAnchor)4;
			val4.resizeTextForBestFit = true;
			val4.resizeTextMinSize = 0;
			RectTransform component = ((Component)val4).GetComponent<RectTransform>();
			((Transform)component).localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.28f, 0.05f);
			((Transform)component).position = new Vector3(0.06f, -0.07f, 0.123f);
			((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			if (Settings.fpsCounter)
			{
				GameObject val5 = new GameObject();
				val5.transform.parent = canvasObject.transform;
				fpsObject = val5.AddComponent<Text>();
				fpsObject.font = Settings.currentFont;
				fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime);
				((Graphic)fpsObject).color = Settings.textColors[0];
				fpsObject.fontSize = -1;
				fpsObject.supportRichText = true;
				fpsObject.fontStyle = (FontStyle)2;
				fpsObject.alignment = (TextAnchor)4;
				fpsObject.horizontalOverflow = (HorizontalWrapMode)1;
				fpsObject.resizeTextForBestFit = true;
				fpsObject.resizeTextMinSize = 0;
				RectTransform component2 = ((Component)fpsObject).GetComponent<RectTransform>();
				((Transform)component2).localPosition = Vector3.zero;
				component2.sizeDelta = new Vector2(0.28f, 0.02f);
				((Transform)component2).position = new Vector3(0.06f, 0.07f, 0.123f);
				((Transform)component2).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			}
			GameObject val6 = GameObject.CreatePrimitive((PrimitiveType)3);
			if (!UnityInput.Current.GetKey((KeyCode)113))
			{
				val6.layer = 2;
			}
			float num = 0.6f;
			Object.Destroy((Object)(object)val6.GetComponent<Rigidbody>());
			((Collider)val6.GetComponent<BoxCollider>()).isTrigger = true;
			val6.transform.parent = menu.transform;
			val6.transform.rotation = Quaternion.identity;
			val6.transform.localScale = new Vector3(0.15f, 0.35f, 0.08f) * Player.Instance.scale;
			val6.transform.localPosition = new Vector3(0.56f, 0.2f, 0.32f - num) * Player.Instance.scale;
			val6.GetComponent<Renderer>().material.color = Color.magenta / 4f;
			val6.AddComponent<Button>().relatedText = "PreviousPage";
			GameObject val7 = new GameObject();
			val7.transform.parent = canvasObject.transform;
			val4 = val7.AddComponent<Text>();
			val4.font = Settings.currentFont;
			val4.text = "prev";
			val4.fontSize = -1;
			((Graphic)val4).color = Settings.textColors[0];
			val4.alignment = (TextAnchor)4;
			val4.resizeTextForBestFit = true;
			val4.resizeTextMinSize = 0;
			component = ((Component)val4).GetComponent<RectTransform>();
			((Transform)component).localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.2f, 0.03f);
			((Transform)component).localPosition = new Vector3(0.064f, 0.07f, -0.11f);
			((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			val6 = GameObject.CreatePrimitive((PrimitiveType)3);
			if (!UnityInput.Current.GetKey((KeyCode)113))
			{
				val6.layer = 2;
			}
			Object.Destroy((Object)(object)val6.GetComponent<Rigidbody>());
			((Collider)val6.GetComponent<BoxCollider>()).isTrigger = true;
			val6.transform.parent = menu.transform;
			val6.transform.rotation = Quaternion.identity;
			val6.transform.localScale = new Vector3(0.15f, 0.35f, 0.08f) * Player.Instance.scale;
			val6.transform.localPosition = new Vector3(0.56f, -0.2f, 0.32f - num);
			val6.GetComponent<Renderer>().material.color = Color.magenta / 4f;
			val6.AddComponent<Button>().relatedText = "NextPage";
			GameObject val8 = new GameObject();
			val8.transform.parent = canvasObject.transform;
			val4 = val8.AddComponent<Text>();
			val4.font = Settings.currentFont;
			val4.text = "next";
			val4.fontSize = -1;
			((Graphic)val4).color = Settings.textColors[0];
			val4.alignment = (TextAnchor)4;
			val4.resizeTextForBestFit = true;
			val4.resizeTextMinSize = 0;
			component = ((Component)val4).GetComponent<RectTransform>();
			((Transform)component).localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.2f, 0.03f);
			((Transform)component).localPosition = new Vector3(0.064f, -0.07f, -0.11f);
			((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			menuBorder = GameObject.CreatePrimitive((PrimitiveType)3);
			Object.Destroy((Object)(object)menuBorder.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)menuBorder.GetComponent<BoxCollider>());
			menuBorder.transform.parent = menu.transform;
			menuBorder.transform.rotation = Quaternion.identity;
			menuBorder.transform.localScale = new Vector3(0.098f, 0.4125f, 0.4625f);
			menuBorder.GetComponent<Renderer>().material.color = Color.black;
			menuBorder.transform.position = new Vector3(0.05f, 0f, -0.0075f);
			ButtonInfo[] array = Buttons.buttons[buttonsType].Skip(pageNumber * Settings.buttonsPerPage).Take(Settings.buttonsPerPage).ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				CreateButton((float)i * 0.1f, array[i]);
			}
		}
	}

	public static GliderHoldable[] GetGliders()
	{
		if (Time.time > lastRecievedTime)
		{
			archivemonsters = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archiveholdables == null)
		{
			archiveholdables = Object.FindObjectsOfType<GliderHoldable>();
		}
		return archiveholdables;
	}

	public static MonkeyeAI[] GetMonsters()
	{
		if (Time.time > lastRecievedTime)
		{
			archivemonsters = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archivemonsters == null)
		{
			archivemonsters = Object.FindObjectsOfType<MonkeyeAI>();
		}
		return archivemonsters;
	}

	public static BalloonHoldable[] GetBalloons()
	{
		if (Time.time > lastRecievedTime)
		{
			archiveballoons = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archiveballoons == null)
		{
			archiveballoons = Object.FindObjectsOfType<BalloonHoldable>();
		}
		return archiveballoons;
	}

	public static TappableBell[] GetBells()
	{
		if (Time.time > lastRecievedTime)
		{
			archivebells = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archivebells == null)
		{
			archivebells = Object.FindObjectsOfType<TappableBell>();
		}
		return archivebells;
	}

	public static GhostLabButton[] GetLabButtons()
	{
		if (Time.time > lastRecievedTime)
		{
			archivelabbuttons = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archivelabbuttons == null)
		{
			archivelabbuttons = Object.FindObjectsOfType<GhostLabButton>();
		}
		return archivelabbuttons;
	}

	public static GorillaCaveCrystal[] GetCrystals()
	{
		if (Time.time > lastRecievedTime)
		{
			archivecrystals = null;
			lastRecievedTime = Time.time + 5f;
		}
		if (archivecrystals == null)
		{
			archivecrystals = Object.FindObjectsOfType<GorillaCaveCrystal>();
		}
		return archivecrystals;
	}

	public static void colorgamemode()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group").GetComponent<Renderer>().material.color = Color.gray / 1f / 9f;
	}

	public static void BetterRPCUnlimiter()
	{
		((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
		((GorillaNot)GorillaNot.instance).rpcErrorMax = int.MaxValue;
		((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
		PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
		((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
		((GorillaNot)GorillaNot.instance).rpcErrorMax = int.MaxValue;
		((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
		PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
		((GorillaNot)GorillaNot.instance).rpcCallLimit = int.MaxValue;
		PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
		PhotonNetwork.SendAllOutgoingCommands();
		PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
		PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
		PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
	}

	public static Vector3 World2Player(Vector3 world)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		return world - ((Component)GorillaTagger.Instance.bodyCollider).transform.position + ((Component)GorillaTagger.Instance).transform.position;
	}

	public static GameObject LoadAsset(string assetName)
	{
		GameObject result = null;
		Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("iiMenu.Resources.iimenu");
		if (manifestResourceStream != null)
		{
			if ((Object)(object)Vars.assetBundle == (Object)null)
			{
				Vars.assetBundle = AssetBundle.LoadFromStream(manifestResourceStream);
			}
			result = Object.Instantiate<GameObject>(Vars.assetBundle.LoadAsset<GameObject>(assetName));
		}
		else
		{
			Debug.LogError((object)("Failed to load asset from resource: " + assetName));
		}
		return result;
	}

	public static void TeleportPlayer(Vector3 pos)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		TeleportPatch.doTeleport = true;
		TeleportPatch.telePos = pos;
	}

	public static int NoInvisLayerMask()
	{
		return ~((1 << Vars.TransparentFX) | (1 << Vars.IgnoreRaycast) | (1 << Vars.Zone) | (1 << Vars.GorillaTrigger) | (1 << Vars.GorillaBoundary) | (1 << Vars.GorillaCosmetics) | (1 << Vars.GorillaParticle));
	}

	public static (RaycastHit Ray, GameObject NewPointer) GunLib()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Expected O, but got Unknown
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit item = default(RaycastHit);
		Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, ref item);
		if (Vars.shouldBePC)
		{
			Ray val = (((Object)(object)GameObject.Find("Shoulder Camera").GetComponent<Camera>() != (Object)null) ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
		}
		GameObject val2 = GameObject.CreatePrimitive((PrimitiveType)0);
		val2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
		val2.GetComponent<Renderer>().material.color = Color.gray / 1f;
		val2.transform.localScale = new Vector3(-0.04f, -0.04f, -0.04f);
		val2.transform.position = (nigger ? ((Component)whosGay).transform.position : ((RaycastHit)(ref item)).point);
		Object.Destroy((Object)(object)val2.GetComponent<BoxCollider>());
		Object.Destroy((Object)(object)val2.GetComponent<Rigidbody>());
		Object.Destroy((Object)(object)val2.GetComponent<Collider>());
		Object.Destroy((Object)(object)val2, Time.deltaTime);
		GameObject val3 = new GameObject("Line");
		LineRenderer val4 = val3.AddComponent<LineRenderer>();
		((Renderer)val4).material.shader = Shader.Find("GUI/Text Shader");
		val4.startColor = Color.gray / 1f;
		val4.endColor = Color.gray / 1f;
		val4.startWidth = 0.01f;
		val4.endWidth = 0.01f;
		val4.positionCount = 2;
		val4.useWorldSpace = true;
		val4.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
		val4.SetPosition(1, nigger ? ((Component)whosGay).transform.position : ((RaycastHit)(ref item)).point);
		Object.Destroy((Object)(object)val3, Time.deltaTime);
		return (Ray: item, NewPointer: val2);
	}

	public static void CreateButton(float offset, ButtonInfo method)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = GameObject.CreatePrimitive((PrimitiveType)3);
		if (!UnityInput.Current.GetKey((KeyCode)113))
		{
			val.layer = 2;
		}
		Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
		((Collider)val.GetComponent<BoxCollider>()).isTrigger = true;
		val.transform.parent = menu.transform;
		val.transform.rotation = Quaternion.identity;
		val.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
		val.transform.localPosition = new Vector3(0.56f, 0f, 0.28f - offset);
		val.AddComponent<Button>().relatedText = method.buttonText;
		Object.Destroy((Object)(object)val.GetComponent<Renderer>());
		ColorChanger colorChanger = val.AddComponent<ColorChanger>();
		if (method.enabled)
		{
			colorChanger.colorInfo = Settings.buttonColors[1];
		}
		else
		{
			colorChanger.colorInfo = Settings.buttonColors[0];
		}
		colorChanger.Start();
		GameObject val2 = new GameObject();
		val2.transform.parent = canvasObject.transform;
		Text val3 = val2.AddComponent<Text>();
		val3.font = Settings.currentFont;
		val3.text = method.buttonText;
		if (method.overlapText != null)
		{
			val3.text = method.overlapText;
		}
		val3.supportRichText = true;
		val3.fontSize = -1;
		if (method.enabled)
		{
			((Graphic)val3).color = Settings.textColors[1];
		}
		else
		{
			((Graphic)val3).color = Settings.textColors[0];
		}
		val3.alignment = (TextAnchor)4;
		val3.fontStyle = (FontStyle)2;
		val3.resizeTextForBestFit = true;
		val3.resizeTextMinSize = 0;
		RectTransform component = ((Component)val3).GetComponent<RectTransform>();
		((Transform)component).localPosition = Vector3.zero;
		component.sizeDelta = new Vector2(0.2f, 0.03f);
		((Transform)component).localPosition = new Vector3(0.064f, 0f, 0.111f - offset / 2.6f);
		((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
	}

	public static void RecreateMenu()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)menu != (Object)null)
		{
			Object.Destroy((Object)(object)menu);
			menu = null;
			CreateMenu();
			RecenterMenu(Settings.rightHanded, UnityInput.Current.GetKey(Settings.keyboardButton));
		}
	}

	public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		Quaternion rotation;
		if (!isKeyboardCondition)
		{
			if (!isRightHanded)
			{
				menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
				menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
				return;
			}
			menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
			rotation = GorillaTagger.Instance.rightHandTransform.rotation;
			Vector3 eulerAngles = ((Quaternion)(ref rotation)).eulerAngles;
			eulerAngles += new Vector3(0f, 0f, 180f);
			menu.transform.rotation = Quaternion.Euler(eulerAngles);
			return;
		}
		try
		{
			TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
		}
		catch
		{
		}
		if (!((Object)(object)TPC != (Object)null))
		{
			return;
		}
		((Component)TPC).transform.position = new Vector3(-999f, -999f, -999f);
		((Component)TPC).transform.rotation = Quaternion.identity;
		GameObject val = GameObject.CreatePrimitive((PrimitiveType)3);
		val.transform.localScale = new Vector3(10f, 10f, 0.01f);
		((Component)val.transform).transform.position = new Vector3(-63f, 3.634f, -65f);
		Object.Destroy((Object)(object)val);
		Object.Destroy((Object)(object)val, Time.deltaTime);
		menu.transform.parent = ((Component)TPC).transform;
		menu.transform.position = ((Component)TPC).transform.position + Vector3.Scale(((Component)TPC).transform.forward, new Vector3(0.5f, 0.5f, 0.5f)) + Vector3.Scale(((Component)TPC).transform.up, new Vector3(-0.02f, -0.02f, -0.02f));
		rotation = ((Component)TPC).transform.rotation;
		Vector3 eulerAngles2 = ((Quaternion)(ref rotation)).eulerAngles;
		((Vector3)(ref eulerAngles2))._002Ector(eulerAngles2.x - 90f, eulerAngles2.y + 90f, eulerAngles2.z);
		menu.transform.rotation = Quaternion.Euler(eulerAngles2);
		if (!((Object)(object)reference != (Object)null))
		{
			return;
		}
		if (Mouse.current.leftButton.isPressed)
		{
			Ray val2 = TPC.ScreenPointToRay(Vector2.op_Implicit(((InputControl<Vector2>)(object)((Pointer)Mouse.current).position).ReadValue()));
			RaycastHit val3 = default(RaycastHit);
			if (Physics.Raycast(val2, ref val3, 100f))
			{
				Button component = ((Component)((RaycastHit)(ref val3)).transform).gameObject.GetComponent<Button>();
				if ((Object)(object)component != (Object)null)
				{
					component.OnTriggerEnter((Collider)(object)buttonCollider);
				}
			}
		}
		else
		{
			reference.transform.position = new Vector3(999f, -999f, -999f);
		}
	}

	public static void TriggerPages()
	{
		int num = (Buttons.buttons[buttonsType].Length + Settings.buttonsPerPage - 1) / Settings.buttonsPerPage - 1;
		Settings.buttonsPerPage = 8;
		if (UnityInput.Current.GetKeyDown((KeyCode)113) && (Object)(object)menu != (Object)null)
		{
			pageNumber--;
			if (pageNumber < 0)
			{
				pageNumber = num;
			}
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(114, false, 0.4f);
		}
		if (UnityInput.Current.GetKeyDown((KeyCode)101) && (Object)(object)menu != (Object)null)
		{
			pageNumber++;
			if (pageNumber > num)
			{
				pageNumber = 0;
			}
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(114, false, 0.4f);
		}
		triggerPage = true;
	}

	public static void CreateReference(bool isRightHanded)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		reference = GameObject.CreatePrimitive((PrimitiveType)0);
		if (isRightHanded)
		{
			reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
		}
		else
		{
			reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
		}
		reference.GetComponent<Renderer>().material.color = Settings.backgroundColor.colors[0].color;
		reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
		reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
		buttonCollider = reference.GetComponent<SphereCollider>();
		ColorChanger colorChanger = reference.AddComponent<ColorChanger>();
		colorChanger.colorInfo = Settings.backgroundColor;
		colorChanger.Start();
	}

	public static void Toggle(string buttonText)
	{
		int num = (Buttons.buttons[buttonsType].Length + Settings.buttonsPerPage - 1) / Settings.buttonsPerPage - 1;
		if (buttonText == "PreviousPage")
		{
			pageNumber--;
			if (pageNumber < 0)
			{
				pageNumber = num;
			}
		}
		else if (buttonText == "NextPage")
		{
			pageNumber++;
			if (pageNumber > num)
			{
				pageNumber = 0;
			}
		}
		else
		{
			ButtonInfo index = GetIndex(buttonText);
			if (index != null)
			{
				if (index.isTogglable)
				{
					index.enabled = !index.enabled;
					if (index.enabled)
					{
						NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + index.buttonText);
						if (index.enableMethod != null)
						{
							try
							{
								index.enableMethod();
							}
							catch
							{
							}
						}
					}
					else
					{
						NotifiLib.SendNotification("<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " + index.buttonText);
						if (index.disableMethod != null)
						{
							try
							{
								index.disableMethod();
							}
							catch
							{
							}
						}
					}
				}
				else
				{
					NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + index.buttonText);
					if (index.method != null)
					{
						try
						{
							index.method();
						}
						catch
						{
						}
					}
				}
			}
			else
			{
				Debug.LogError((object)(buttonText + " does not exist"));
			}
		}
		RecreateMenu();
	}

	public static GradientColorKey[] GetSolidGradient(Color color)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		return (GradientColorKey[])(object)new GradientColorKey[2]
		{
			new GradientColorKey(color, 0f),
			new GradientColorKey(color, 1f)
		};
	}

	public static ButtonInfo GetIndex(string buttonText)
	{
		ButtonInfo[][] buttons = Buttons.buttons;
		foreach (ButtonInfo[] array in buttons)
		{
			ButtonInfo[] array2 = array;
			foreach (ButtonInfo buttonInfo in array2)
			{
				if (buttonInfo.buttonText == buttonText)
				{
					return buttonInfo;
				}
			}
		}
		return null;
	}
}
