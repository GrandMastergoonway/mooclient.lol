using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.UI;

namespace StupidTemplate.Menu;

public class Vars : MonoBehaviour
{
	public static bool isOnPC = false;

	public static bool lockdown = false;

	public static bool HasLoaded = false;

	public static float internetTime = 3f;

	public static bool hasRemovedThisFrame = false;

	public static int buttonsType = 0;

	public static float buttonCooldown = 0f;

	public static bool noti = true;

	public static bool disableNotifications = false;

	public static bool showEnabledModsVR = true;

	public static bool disableDisconnectButton = false;

	public static bool disablePageButtons = false;

	public static bool disableFpsCounter = false;

	public static int pageSize = 6;

	public static int pageNumber = 0;

	public static int pageButtonType = 1;

	public static float buttonOffset = 2f;

	public static int fullModAmount = -1;

	public static int fontCycle = 0;

	public static int fontStyleType = 2;

	public static bool rightHand = false;

	public static bool isRightHand = false;

	public static bool bothHands = false;

	public static bool wristThing = false;

	public static bool wristOpen = false;

	public static bool joystickMenu = false;

	public static bool joystickOpen = false;

	public static int joystickButtonSelected = 0;

	public static string joystickSelectedButton = "";

	public static float joystickDelay = -1f;

	public static bool lastChecker = false;

	public static bool FATMENU = false;

	public static bool checkMode = false;

	public static bool longmenu = false;

	public static bool isCopying = false;

	public static bool disorganized = false;

	public static bool hasAntiBanned = false;

	public static float shouldLoadDataTime = -1f;

	public static bool shouldAttemptLoadData = false;

	public static bool hasLoadedPreferences = false;

	public static bool ghostException = false;

	public static bool hasPlayersUpdated = false;

	public static bool disableGhostview = false;

	public static bool disableBoardColor = false;

	public static float timeMenuStarted = -1f;

	public static int pcbg = 0;

	public static int buttonClickSound = 8;

	public static int buttonClickIndex = 0;

	public static int buttonClickVolume = 4;

	public static bool doButtonsVibrate = true;

	public static bool doCustomName = false;

	public static string customMenuName = "your text here";

	public static bool noPageNumber = false;

	public static bool wristThingV2 = false;

	public static float wristMenuDelay = -1f;

	public static bool NoAutoSizeText = false;

	public static int attemptsToLoad = 0;

	public static bool flipMenu = false;

	public static bool shinymenu = false;

	public static bool dropOnRemove = true;

	public static bool shouldOutline = false;

	public static bool lastclicking = false;

	public static bool likebark = false;

	public static string rejRoom = null;

	public static float rejDebounce = 0f;

	public static string partyLastCode = null;

	public static float partyTime = 0f;

	public static bool phaseTwo = false;

	public static bool waitForPlayerJoin = false;

	public static int amountPartying = 0;

	public static bool isSearching = false;

	public static bool isPcWhenSearching = false;

	public static string searchText = "";

	public static float lastBackspaceTime = 0f;

	public static bool disableSearchButton = false;

	public static bool disableReturnButton = false;

	public static bool legacyGhostview = false;

	public static bool smallGunPointer = false;

	public static bool disableGunPointer = false;

	public static bool disableGunLine = false;

	public static bool riskyModsEnabled = false;

	public static bool doCustomMenuBackground = false;

	public static Texture2D customMenuBackgroundImage = null;

	public static bool shouldBePC = false;

	public static bool rightPrimary = false;

	public static bool rightSecondary = false;

	public static bool leftPrimary = false;

	public static bool leftSecondary = false;

	public static bool leftGrab = false;

	public static bool rightGrab = false;

	public static float leftTrigger = 0f;

	public static float rightTrigger = 0f;

	public static List<KeyCode> lastPressedKeys = new List<KeyCode>();

	public static KeyCode[] allowedKeys;

	public static string mainPlayerId;

	public static string hotkeyButton;

	public static int TransparentFX;

	public static int IgnoreRaycast;

	public static int Zone;

	public static int GorillaTrigger;

	public static int GorillaBoundary;

	public static int GorillaCosmetics;

	public static int GorillaParticle;

	public static GameObject cam;

	public static Camera TPC;

	public static GameObject menu;

	public static GameObject menuBackground;

	public static GameObject reference;

	public static SphereCollider buttonCollider;

	public static GameObject canvasObj;

	public static AssetBundle assetBundle;

	public static Text fpsCount;

	public static Text searchTextObject;

	public static Text title;

	public static VRRig whoCopy;

	public static VRRig GhostRig;

	public static Material funnyghostmaterial;

	public static Texture2D searchIcon;

	public static Texture2D returnIcon;

	public static Texture2D fixTexture;

	public static Material searchMat;

	public static Material returnMat;

	public static Material fixMat;

	public static Font agency;

	public static Font Arial;

	public static Font Verdana;

	public static Font sans;

	public static Font consolas;

	public static Font ubuntu;

	public static Font MSGOTHIC;

	public static Font gtagfont;

	public static Font activeFont;

	public static FontStyle activeFontStyle;

	public static GameObject lKeyReference;

	public static SphereCollider lKeyCollider;

	public static GameObject rKeyReference;

	public static SphereCollider rKeyCollider;

	public static GameObject VRKeyboard;

	public static GameObject menuSpawnPosition;

	public static GameObject watchobject;

	public static GameObject watchText;

	public static GameObject watchShell;

	public static GameObject watchEnabledIndicator;

	public static Material watchIndicatorMat;

	public static int currentSelectedModThing;

	public static GameObject regwatchobject;

	public static GameObject regwatchText;

	public static GameObject regwatchShell;

	public static GameObject leftplat;

	public static GameObject rightplat;

	public static GameObject leftThrow;

	public static GameObject rightThrow;

	public static GameObject stickpart;

	public static GameObject CheckPoint;

	public static GameObject BombObject;

	public static GameObject ProjBombObject;

	public static GameObject airSwimPart;

	public static List<ForceVolume> fvol;

	public static List<GameObject> leaves;

	public static List<GameObject> cblos;

	public static List<GameObject> lights;

	public static List<GameObject> cosmetics;

	public static List<GameObject> holidayobjects;

	public static Vector3 rightgrapplePoint;

	public static Vector3 leftgrapplePoint;

	public static SpringJoint rightjoint;

	public static SpringJoint leftjoint;

	public static bool isLeftGrappling;

	public static bool isRightGrappling;

	public static Material OrangeUI;

	public static GameObject motd;

	public static GameObject motdText;

	public static Material glass;

	public static bool hasLoadedPride;

	public static Texture2D pride;

	public static bool hasLoadedTrans;

	public static Texture2D trans;

	public static bool hasLoadedGay;

	public static Texture2D gay;

	public static List<string> favorites;

	public static List<GorillaNetworkJoinTrigger> triggers;

	public static Vector3 offsetLH;

	public static Vector3 offsetRH;

	public static Vector3 offsetH;

	public static Vector3 longJumpPower;

	public static Vector2 lerpygerpy;

	public static Vector3[] lastLeft;

	public static Vector3[] lastRight;

	public static string[] letters;

	public static int[] bones;

	public static int arrowType;

	public static string[][] arrowTypes;

	public static string[] fullProjectileNames;

	public static string[] fullTrailNames;

	public static int themeType;

	public static Color bgColorA;

	public static Color bgColorB;

	public static Color buttonDefaultA;

	public static Color buttonDefaultB;

	public static Color buttonClickedA;

	public static Color buttonClickedB;

	public static Color textColor;

	public static Color titleColor;

	public static Color textClicked;

	public static Color colorChange;

	public static Vector3 walkPos;

	public static Vector3 walkNormal;

	public static Vector3 closePosition;

	public static Vector3 pointerOffset;

	public static int pointerIndex;

	public static bool noclip;

	public static float tagAuraDistance;

	public static int tagAuraIndex;

	public static bool lastSlingThing;

	public static bool lastInRoom;

	public static bool lastMasterClient;

	public static string lastRoom;

	public static int platformMode;

	public static int platformShape;

	public static bool customSoundOnJoin;

	public static float partDelay;

	public static float delaythinggg;

	public static float debounce;

	public static float kgDebounce;

	public static float nameCycleDelay;

	public static float stealIdentityDelay;

	public static float beesDelay;

	public static float laggyRigDelay;

	public static float jrDebounce;

	public static float projDebounce;

	public static float projDebounceType;

	public static float soundDebounce;

	public static float colorChangerDelay;

	public static float teleDebounce;

	public static float splashDel;

	public static float headspazDelay;

	public static float autoSaveDelay;

	public static bool isUpdatingValues;

	public static float valueChangeDelay;

	public static bool changingName;

	public static bool changingColor;

	public static string nameChange;

	public static int projmode;

	public static int trailmode;

	public static int notificationDecayTime;

	public static float oldSlide;

	public static int accessoryType;

	public static int hat;

	public static int soundId;

	public static float red;

	public static float green;

	public static float blue;

	public static bool lastOwner;

	public static string inputText;

	public static string lastCommand;

	public static int shootCycle;

	public static float ShootStrength;

	public static int flySpeedCycle;

	public static float flySpeed;

	public static int speedboostCycle;

	public static float jspeed;

	public static float jmulti;

	public static int longarmCycle;

	public static float armlength;

	public static int nameCycleIndex;

	public static bool lastprimaryhit;

	public static bool idiotfixthingy;

	public static int crashAmount;

	public static bool isJoiningRandom;

	public static int colorChangeType;

	public static bool strobeColor;

	public static bool AntiCrashToggle;

	public static bool AntiSoundToggle;

	public static bool AntiCheatSelf;

	public static bool AntiCheatAll;

	public static bool NoGliderRespawn;

	public static bool lastHit;

	public static bool lastHit2;

	public static bool lastRG;

	public static bool ghostMonke;

	public static bool invisMonke;

	public static int tindex;

	public static bool antiBanEnabled;

	public static bool lastHitL;

	public static bool lastHitR;

	public static bool lastHitLP;

	public static bool lastHitRP;

	public static bool lastHitRS;

	public static bool plastLeftGrip;

	public static bool plastRightGrip;

	public static bool spazLavaType;

	public static bool EverythingSlippery;

	public static bool EverythingGrippy;

	public static bool headspazType;

	public static bool hasFoundAllBoards;

	public static float lastBangTime;

	public static float subThingy;

	public static float sizeScale;

	public static float turnAmnt;

	public static float TagAuraDelay;

	public static float startX;

	public static bool lowercaseMode;

	public static bool annoyingMode;

	public static string[] facts;

	static Vars()
	{
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Expected O, but got Unknown
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Expected O, but got Unknown
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Expected O, but got Unknown
		//IL_053e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0548: Expected O, but got Unknown
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0572: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0581: Unknown result type (might be due to invalid IL or missing references)
		//IL_0586: Unknown result type (might be due to invalid IL or missing references)
		//IL_058b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_0595: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_0615: Unknown result type (might be due to invalid IL or missing references)
		//IL_0628: Unknown result type (might be due to invalid IL or missing references)
		//IL_062d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0634: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Unknown result type (might be due to invalid IL or missing references)
		//IL_0640: Unknown result type (might be due to invalid IL or missing references)
		//IL_0645: Unknown result type (might be due to invalid IL or missing references)
		//IL_064c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0651: Unknown result type (might be due to invalid IL or missing references)
		//IL_0658: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0664: Unknown result type (might be due to invalid IL or missing references)
		//IL_0669: Unknown result type (might be due to invalid IL or missing references)
		//IL_0670: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_067c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0681: Unknown result type (might be due to invalid IL or missing references)
		//IL_0688: Unknown result type (might be due to invalid IL or missing references)
		//IL_068d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0695: Unknown result type (might be due to invalid IL or missing references)
		//IL_069a: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09be: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09da: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a12: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a64: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac7: Unknown result type (might be due to invalid IL or missing references)
		KeyCode[] array = new KeyCode[29];
		RuntimeHelpers.InitializeArray(array, (RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/);
		allowedKeys = (KeyCode[])(object)array;
		mainPlayerId = "E19CE8918FD9E927";
		hotkeyButton = "none";
		TransparentFX = LayerMask.NameToLayer("TransparentFX");
		IgnoreRaycast = LayerMask.NameToLayer("Ignore Raycast");
		Zone = LayerMask.NameToLayer("Zone");
		GorillaTrigger = LayerMask.NameToLayer("Gorilla Trigger");
		GorillaBoundary = LayerMask.NameToLayer("Gorilla Boundary");
		GorillaCosmetics = LayerMask.NameToLayer("GorillaCosmetics");
		GorillaParticle = LayerMask.NameToLayer("GorillaParticle");
		cam = null;
		TPC = null;
		menu = null;
		menuBackground = null;
		reference = null;
		buttonCollider = null;
		canvasObj = null;
		assetBundle = null;
		fpsCount = null;
		searchTextObject = null;
		title = null;
		whoCopy = null;
		GhostRig = null;
		funnyghostmaterial = null;
		searchIcon = null;
		returnIcon = null;
		fixTexture = null;
		searchMat = null;
		returnMat = null;
		fixMat = null;
		agency = Font.CreateDynamicFontFromOSFont("Agency FB", 24);
		Object builtinResource = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		Arial = (Font)(object)((builtinResource is Font) ? builtinResource : null);
		Verdana = Font.CreateDynamicFontFromOSFont("Verdana", 24);
		sans = Font.CreateDynamicFontFromOSFont("Comic Sans MS", 24);
		consolas = Font.CreateDynamicFontFromOSFont("Consolas", 24);
		ubuntu = Font.CreateDynamicFontFromOSFont("Candara", 24);
		MSGOTHIC = Font.CreateDynamicFontFromOSFont("MS Gothic", 24);
		gtagfont = null;
		activeFont = agency;
		activeFontStyle = (FontStyle)2;
		lKeyReference = null;
		lKeyCollider = null;
		rKeyReference = null;
		rKeyCollider = null;
		VRKeyboard = null;
		menuSpawnPosition = null;
		watchobject = null;
		watchText = null;
		watchShell = null;
		watchEnabledIndicator = null;
		watchIndicatorMat = null;
		currentSelectedModThing = 0;
		regwatchobject = null;
		regwatchText = null;
		regwatchShell = null;
		leftplat = null;
		rightplat = null;
		leftThrow = null;
		rightThrow = null;
		stickpart = null;
		CheckPoint = null;
		BombObject = null;
		ProjBombObject = null;
		airSwimPart = null;
		fvol = new List<ForceVolume>();
		leaves = new List<GameObject>();
		cblos = new List<GameObject>();
		lights = new List<GameObject>();
		cosmetics = new List<GameObject>();
		holidayobjects = new List<GameObject>();
		isLeftGrappling = false;
		isRightGrappling = false;
		OrangeUI = new Material(Shader.Find("GorillaTag/UberShader"));
		motd = null;
		motdText = null;
		glass = null;
		hasLoadedPride = false;
		pride = new Texture2D(2, 2);
		hasLoadedTrans = false;
		trans = new Texture2D(2, 2);
		hasLoadedGay = false;
		gay = new Texture2D(2, 2);
		favorites = new List<string> { "Exit Favorite Mods" };
		triggers = new List<GorillaNetworkJoinTrigger>();
		offsetLH = Vector3.zero;
		offsetRH = Vector3.zero;
		offsetH = Vector3.zero;
		longJumpPower = Vector3.zero;
		lerpygerpy = Vector2.zero;
		lastLeft = (Vector3[])(object)new Vector3[10]
		{
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero
		};
		lastRight = (Vector3[])(object)new Vector3[10]
		{
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero
		};
		letters = new string[36]
		{
			"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
			"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P",
			"A", "S", "D", "F", "G", "H", "J", "K", "L", "Z",
			"X", "C", "V", "B", "N", "M"
		};
		bones = new int[38]
		{
			4, 3, 5, 4, 19, 18, 20, 19, 3, 18,
			21, 20, 22, 21, 25, 21, 29, 21, 31, 29,
			27, 25, 24, 22, 6, 5, 7, 6, 10, 6,
			14, 6, 16, 14, 12, 10, 9, 7
		};
		arrowType = 0;
		arrowTypes = new string[10][]
		{
			new string[2] { "<", ">" },
			new string[2] { "←", "→" },
			new string[2] { "↞", "↠" },
			new string[2] { "◄", "►" },
			new string[2] { "〈 ", " 〉" },
			new string[2] { "‹", "›" },
			new string[2] { "«", "»" },
			new string[2] { "◀", "▶" },
			new string[2] { "-", "+" },
			new string[2] { "", "" }
		};
		fullProjectileNames = new string[6] { "Snowball", "WaterBalloon", "LavaRock", "ThrowableGift", "ScienceCandy", "FishFood" };
		fullTrailNames = new string[9] { "SlingshotProjectileTrail", "HornsSlingshotProjectileTrail_PrefabV", "CloudSlingshot_ProjectileTrailFX", "CupidArrow_ProjectileTrailFX", "IceSlingshotProjectileTrail Variant", "ElfBow_ProjectileTrail", "MoltenRockSlingshotProjectileTrail", "SpiderBowProjectileTrail Variant", "none" };
		themeType = 1;
		bgColorA = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)128, (byte)0, (byte)128));
		bgColorB = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)102, (byte)0, (byte)128));
		buttonDefaultA = Color32.op_Implicit(new Color32((byte)170, (byte)85, (byte)0, byte.MaxValue));
		buttonDefaultB = Color32.op_Implicit(new Color32((byte)170, (byte)85, (byte)0, byte.MaxValue));
		buttonClickedA = Color32.op_Implicit(new Color32((byte)85, (byte)42, (byte)0, byte.MaxValue));
		buttonClickedB = Color32.op_Implicit(new Color32((byte)85, (byte)42, (byte)0, byte.MaxValue));
		textColor = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)190, (byte)125, byte.MaxValue));
		titleColor = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)190, (byte)125, byte.MaxValue));
		textClicked = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)190, (byte)125, byte.MaxValue));
		colorChange = Color.black;
		pointerOffset = new Vector3(0f, -0.1f, 0f);
		pointerIndex = 0;
		noclip = false;
		tagAuraDistance = 1.666f;
		tagAuraIndex = 1;
		lastSlingThing = false;
		lastInRoom = false;
		lastMasterClient = false;
		lastRoom = "";
		platformMode = 0;
		platformShape = 0;
		customSoundOnJoin = false;
		partDelay = 0f;
		delaythinggg = 0f;
		debounce = 0f;
		kgDebounce = 0f;
		nameCycleDelay = 0f;
		stealIdentityDelay = 0f;
		beesDelay = 0f;
		laggyRigDelay = 0f;
		jrDebounce = 0f;
		projDebounce = 0f;
		projDebounceType = 0.1f;
		soundDebounce = 0f;
		colorChangerDelay = 0f;
		teleDebounce = 0f;
		splashDel = 0f;
		headspazDelay = 0f;
		autoSaveDelay = Time.time + 60f;
		isUpdatingValues = false;
		valueChangeDelay = 0f;
		changingName = false;
		changingColor = false;
		nameChange = "";
		projmode = 0;
		trailmode = 0;
		notificationDecayTime = 1000;
		oldSlide = 0f;
		accessoryType = 0;
		hat = 0;
		soundId = 0;
		red = 1f;
		green = 0.5f;
		blue = 0f;
		lastOwner = false;
		inputText = "";
		lastCommand = "";
		shootCycle = 1;
		ShootStrength = 19.44f;
		flySpeedCycle = 1;
		flySpeed = 10f;
		speedboostCycle = 1;
		jspeed = 7.5f;
		jmulti = 1.25f;
		longarmCycle = 2;
		armlength = 1.25f;
		nameCycleIndex = 0;
		lastprimaryhit = false;
		idiotfixthingy = false;
		crashAmount = 2;
		isJoiningRandom = false;
		colorChangeType = 0;
		strobeColor = false;
		AntiCrashToggle = false;
		AntiSoundToggle = false;
		AntiCheatSelf = false;
		AntiCheatAll = false;
		NoGliderRespawn = false;
		lastHit = false;
		lastHit2 = false;
		ghostMonke = false;
		invisMonke = false;
		tindex = 1;
		antiBanEnabled = false;
		lastHitL = false;
		lastHitR = false;
		lastHitLP = false;
		lastHitRP = false;
		lastHitRS = false;
		plastLeftGrip = false;
		plastRightGrip = false;
		spazLavaType = false;
		EverythingSlippery = false;
		EverythingGrippy = false;
		headspazType = false;
		hasFoundAllBoards = false;
		lastBangTime = 0f;
		subThingy = 0f;
		sizeScale = 1f;
		turnAmnt = 0f;
		TagAuraDelay = 0f;
		startX = -1f;
		lowercaseMode = false;
		annoyingMode = false;
		facts = new string[26]
		{
			"The honeybee is the only insect that produces food eaten by humans.", "Bananas are berries, but strawberries aren't.", "The Eiffel Tower can be 15 cm taller during the summer due to thermal expansion.", "A group of flamingos is called a 'flamboyance.'", "The shortest war in history was between Britain and Zanzibar on August 27, 1896 – Zanzibar surrendered after 38 minutes.", "Cows have best friends and can become stressed when they are separated.", "The first computer programmer was a woman named Ada Lovelace.", "A 'jiffy' is an actual unit of time, equivalent to 1/100th of a second.", "Octopuses have three hearts and blue blood.", "The world's largest desert is Antarctica.",
			"Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly edible.", "The smell of freshly-cut grass is actually a plant distress call.", "The average person spends six months of their life waiting for red lights to turn green.", "A group of owls is called a parliament.", "The longest word in the English language without a vowel is 'rhythms.'", "The Great Wall of China is not visible from the moon without aid.", "Venus rotates so slowly on its axis that a day on Venus (one full rotation) is longer than a year on Venus (orbit around the sun).", "The world's largest recorded snowflake was 15 inches wide.", "There are more possible iterations of a game of chess than there are atoms in the known universe.", "A newborn kangaroo is the size of a lima bean and is unable to hop until it's about 8 months old.",
			"The longest hiccuping spree lasted for 68 years!", "A single cloud can weigh more than 1 million pounds.", "Honeybees can recognize human faces.", "Cats have five toes on their front paws but only four on their back paws.", "The inventor of the frisbee was turned into a frisbee. Walter Morrison, the inventor, was cremated, and his ashes were turned into a frisbee after he passed away.", "Penguins give each other pebbles as a way of proposing."
		};
	}
}
