using System.Collections.Generic;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;
using UnityEngine.InputSystem;

namespace StupidTemplate.Mods;

internal class Advantages
{
	public static float spamtagdelay = -1f;

	public static async void MatSelf()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
			{
				OverPowered.SetMatster();
			}
		}
		else if (Time.time > spamtagdelay)
		{
			spamtagdelay = Time.time + 0.1f;
			GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
			if (tagman.currentInfected.Contains(PhotonNetwork.LocalPlayer))
			{
				tagman.currentInfected.Remove(PhotonNetwork.LocalPlayer);
			}
			else
			{
				tagman.AddInfectedPlayer(PhotonNetwork.LocalPlayer);
			}
		}
	}

	public static async void MatGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				if (!PhotonNetwork.IsMasterClient)
				{
					if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
					{
						OverPowered.SetMatster();
					}
				}
				else if (Time.time > spamtagdelay)
				{
					spamtagdelay = Time.time + 0.1f;
					GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
					if (tagman.currentInfected.Contains(RigManager.GetPlayerFromVRRig(Main.whoCopy)))
					{
						tagman.currentInfected.Remove(RigManager.GetPlayerFromVRRig(Main.whoCopy));
					}
					else
					{
						tagman.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(Main.whoCopy));
					}
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig && !((Object)((Renderer)possibly.mainSkin).material).name.Contains("fected"))
				{
					if (PhotonNetwork.LocalPlayer.IsMasterClient)
					{
						GorillaTagManager gorillaTagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
						if (!gorillaTagManager.currentInfected.Contains(RigManager.GetPlayerFromVRRig(possibly)))
						{
							gorillaTagManager.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(possibly));
						}
					}
					else
					{
						Main.isCopying = true;
						Main.whoCopy = possibly;
					}
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void TagAll()
	{
		if (PhotonNetwork.IsMasterClient)
		{
			GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
			Player[] playerList = PhotonNetwork.PlayerList;
			foreach (Player v in playerList)
			{
				if (!tagman.currentInfected.Contains(v))
				{
					tagman.AddInfectedPlayer(v);
				}
			}
			Main.GetIndex("Tag All").enabled = false;
		}
		else
		{
			NotifiLib.SendNotification("<color=grey>[</color><color=green>SUCCESS</color><color=grey>]</color> <color=white>Everyone is tagged!</color>");
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
			Main.GetIndex("Tag All").enabled = false;
		}
	}

	public static async void UntagSelf()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
			{
				OverPowered.SetMatster();
			}
			return;
		}
		GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
		if (tagman.currentInfected.Contains(PhotonNetwork.LocalPlayer))
		{
			tagman.currentInfected.Remove(PhotonNetwork.LocalPlayer);
		}
	}

	public static async void UntagAll()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
			{
				OverPowered.SetMatster();
			}
			return;
		}
		GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
		Player[] playerList = PhotonNetwork.PlayerList;
		foreach (Player v in playerList)
		{
			if (tagman.currentInfected.Contains(v))
			{
				tagman.currentInfected.Remove(v);
			}
		}
	}

	public static async void UntagGun()
	{
		if (!((ControllerInputPoller)ControllerInputPoller.instance).rightGrab && !Mouse.current.rightButton.isPressed)
		{
			return;
		}
		(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
		var (Ray, _) = GunData;
		_ = GunData.NewPointer;
		if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
		{
			VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
			if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig && ((Object)((Renderer)possibly.mainSkin).material).name.Contains("fected"))
			{
				if (PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					GorillaTagManager gorillaTagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
					if (gorillaTagManager.currentInfected.Contains(RigManager.GetPlayerFromVRRig(possibly)))
					{
						gorillaTagManager.currentInfected.Remove(RigManager.GetPlayerFromVRRig(possibly));
					}
				}
				else if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
				{
					OverPowered.SetMatster();
				}
			}
		}
		Ray = default(RaycastHit);
	}

	public static async void TagAura()
	{
		foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			Vector3 they = vrrig.headMesh.transform.position;
			Vector3 notthem = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
			float distance = Vector3.Distance(they, notthem);
			if (((Object)((Renderer)GorillaTagger.Instance.offlineVRRig.mainSkin).material).name.Contains("fected") && !((Object)((Renderer)vrrig.mainSkin).material).name.Contains("fected") && !Player.Instance.disableMovement && distance < 3.22f)
			{
				if (Object.op_Implicit((Object)(object)GorillaTagger.Instance.rightHandTransform))
				{
					Player.Instance.rightControllerTransform.position = they;
				}
				else
				{
					Player.Instance.leftControllerTransform.position = they;
				}
			}
		}
	}

	public static async void NoTagOnJoin()
	{
		PlayerPrefs.SetString("tutorial", "true");
		Hashtable h = new Hashtable();
		((Dictionary<object, object>)(object)h).Add((object)"didTutorial", (object)true);
		PhotonNetwork.LocalPlayer.SetCustomProperties(h, (Hashtable)null, (WebFlags)null);
		PlayerPrefs.Save();
	}

	public static async void TagOnJoin()
	{
		PlayerPrefs.SetString("tutorial", "false");
		Hashtable h = new Hashtable();
		((Dictionary<object, object>)(object)h).Add((object)"didTutorial", (object)false);
		PhotonNetwork.LocalPlayer.SetCustomProperties(h, (Hashtable)null, (WebFlags)null);
		PlayerPrefs.Save();
	}

	public static async void TagGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig && !((Object)((Renderer)possibly.mainSkin).material).name.Contains("fected"))
				{
					if (PhotonNetwork.LocalPlayer.IsMasterClient)
					{
						GorillaTagManager gorillaTagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
						if (!gorillaTagManager.currentInfected.Contains(RigManager.GetPlayerFromVRRig(possibly)))
						{
							gorillaTagManager.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(possibly));
						}
					}
					else
					{
						Main.isCopying = true;
						Main.whoCopy = possibly;
					}
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void MatAll()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
		}
		else
		{
			if (!(Time.time > spamtagdelay))
			{
				return;
			}
			spamtagdelay = Time.time + 0.1f;
			GorillaTagManager tagger = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
			Player[] playerList = PhotonNetwork.PlayerList;
			foreach (Player v in playerList)
			{
				if (tagger.currentInfected.Contains(v))
				{
					tagger.currentInfected.Remove(v);
				}
				else
				{
					tagger.AddInfectedPlayer(v);
				}
			}
		}
	}
}
