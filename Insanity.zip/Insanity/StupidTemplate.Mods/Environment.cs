using System;
using Photon.Pun;
using StupidTemplate.Menu;
using UnityEngine;
using UnityEngine.InputSystem;

namespace StupidTemplate.Mods;

internal class Environment
{
	private static LightmapData[] hell;

	public static async void NoRain()
	{
		for (int i = 1; i < ((BetterDayNightManager)BetterDayNightManager.instance).weatherCycle.Length; i++)
		{
			((BetterDayNightManager)BetterDayNightManager.instance).weatherCycle[i] = (WeatherType)0;
		}
	}

	public static async void Fullbright()
	{
		hell = LightmapSettings.lightmaps;
		LightmapSettings.lightmaps = null;
	}

	public static async void Fullshade()
	{
		LightmapSettings.lightmaps = hell;
	}

	public static async void NightTime()
	{
		((BetterDayNightManager)BetterDayNightManager.instance).SetTimeOfDay(0);
	}

	public static async void EveningTime()
	{
		((BetterDayNightManager)BetterDayNightManager.instance).SetTimeOfDay(7);
	}

	public static async void MorningTime()
	{
		((BetterDayNightManager)BetterDayNightManager.instance).SetTimeOfDay(1);
	}

	public static async void DayTime()
	{
		((BetterDayNightManager)BetterDayNightManager.instance).SetTimeOfDay(3);
	}

	public static async void Rain()
	{
		for (int i = 1; i < ((BetterDayNightManager)BetterDayNightManager.instance).weatherCycle.Length; i++)
		{
			((BetterDayNightManager)BetterDayNightManager.instance).weatherCycle[i] = (WeatherType)1;
		}
	}

	public static async void BugGun()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
			{
				GameObject.Find("Floating Bug Holdable").transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			}
		}
	}

	public static async void BatGun()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
			{
				GameObject.Find("Cave Bat Holdable").transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			}
		}
	}

	public static async void GrabBug()
	{
		if (Vars.rightGrab)
		{
			GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
		}
	}

	public static void BugHalo()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		GameObject.Find("Floating Bug Holdable").transform.position = ((Component)GorillaTagger.Instance.headCollider).transform.position + new Vector3(MathF.Cos(num + (float)Time.frameCount / 30f), 2f, MathF.Sin(num + (float)Time.frameCount / 30f));
	}

	public static async void BatHalo()
	{
		float offset = 120f;
		GameObject.Find("Cave Bat Holdable").transform.position = ((Component)GorillaTagger.Instance.headCollider).transform.position + new Vector3(MathF.Cos(offset + (float)Time.frameCount / 30f), 2f, MathF.Sin(offset + (float)Time.frameCount / 30f));
	}

	public static async void BeachBallHalo()
	{
		float offset = 240f;
		GameObject.Find("BeachBall").transform.position = ((Component)GorillaTagger.Instance.headCollider).transform.position + new Vector3(MathF.Cos(offset + (float)Time.frameCount / 30f), 2f, MathF.Sin(offset + (float)Time.frameCount / 30f));
	}

	public static async void RideBug()
	{
		Main.TeleportPlayer(GameObject.Find("Floating Bug Holdable").transform.position);
		GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
	}

	public static async void RideBat()
	{
		Main.TeleportPlayer(GameObject.Find("Cave Bat Holdable").transform.position);
		GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
	}

	public static async void RideBeachBall()
	{
		Main.TeleportPlayer(GameObject.Find("BeachBall").transform.position);
		GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
	}

	public static async void BreakBug()
	{
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).allowPlayerStealing = false;
	}

	public static async void BreakBat()
	{
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).allowPlayerStealing = false;
	}

	public static async void SlowMonsters()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
			return;
		}
		MonkeyeAI[] monsters = Main.GetMonsters();
		foreach (MonkeyeAI monkeyeAI in monsters)
		{
			if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
			{
				monkeyeAI.speed = 0.02f;
			}
			else
			{
				((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
			}
		}
	}

	public static void FastMonsters()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
			return;
		}
		MonkeyeAI[] monsters = Main.GetMonsters();
		foreach (MonkeyeAI val in monsters)
		{
			if (((Component)val).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
			{
				val.speed = 0.5f;
			}
			else
			{
				((Component)val).gameObject.GetComponent<PhotonView>().RequestOwnership();
			}
		}
	}

	public static async void FixMonsters()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
			return;
		}
		MonkeyeAI[] monsters = Main.GetMonsters();
		foreach (MonkeyeAI monkeyeAI in monsters)
		{
			if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
			{
				monkeyeAI.speed = 0.1f;
			}
			else
			{
				((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
			}
		}
	}

	public static async void GrabMonsters()
	{
		if (!Vars.rightGrab)
		{
			return;
		}
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
			return;
		}
		MonkeyeAI[] monsters = Main.GetMonsters();
		foreach (MonkeyeAI monkeyeAI in monsters)
		{
			if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
			{
				((Component)monkeyeAI).gameObject.transform.position = GorillaTagger.Instance.rightHandTransform.position;
			}
			else
			{
				((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
			}
		}
	}

	public static async void MonsterGun()
	{
		if (!Vars.rightGrab && !Mouse.current.rightButton.isPressed)
		{
			return;
		}
		(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
		_ = GunData.Ray;
		GameObject NewPointer = GunData.NewPointer;
		if (!(Vars.rightTrigger > 0.5f) && !Mouse.current.leftButton.isPressed)
		{
			return;
		}
		if (!PhotonNetwork.IsMasterClient)
		{
			OverPowered.SetMatster();
			return;
		}
		MonkeyeAI[] monsters = Main.GetMonsters();
		foreach (MonkeyeAI monkeyeAI in monsters)
		{
			if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
			{
				((Component)monkeyeAI).gameObject.transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			}
			else
			{
				((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
			}
		}
	}

	public static async void FixBug()
	{
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).allowPlayerStealing = false;
	}

	public static async void FixBat()
	{
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).allowPlayerStealing = false;
	}

	public static async void GrabBat()
	{
		if (Vars.rightGrab)
		{
			GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
		}
	}

	public static async void SpazBug()
	{
		GameObject.Find("Floating Bug Holdable").transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
	}

	public static async void SpazBat()
	{
		GameObject.Find("Cave Bat Holdable").transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
	}

	public static async void SpazBeachBall()
	{
		GameObject.Find("BeachBall").transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
	}

	public static async void GrabBeachBall()
	{
		if (Vars.rightGrab)
		{
			GameObject.Find("BeachBall").transform.position = GorillaTagger.Instance.rightHandTransform.position;
		}
	}

	public static async void DestroyBug()
	{
		GameObject.Find("Floating Bug Holdable").transform.position = new Vector3(99999f, 99999f, 99999f);
	}

	public static async void DestroyBat()
	{
		GameObject.Find("Cave Bat Holdable").transform.position = new Vector3(99999f, 99999f, 99999f);
	}

	public static async void DestroyBeachBall()
	{
		GameObject.Find("BeachBall").transform.position = new Vector3(99999f, 99999f, 99999f);
	}

	public static async void NoRespawnBug()
	{
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).maxDistanceFromOriginBeforeRespawn = float.MaxValue;
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).maxDistanceFromTargetPlayerBeforeRespawn = float.MaxValue;
	}

	public static async void PleaseRespawnBug()
	{
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).maxDistanceFromOriginBeforeRespawn = 50f;
		((TransferrableObject)GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).maxDistanceFromTargetPlayerBeforeRespawn = 50f;
	}

	public static async void NoRespawnBat()
	{
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).maxDistanceFromOriginBeforeRespawn = float.MaxValue;
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).maxDistanceFromTargetPlayerBeforeRespawn = float.MaxValue;
	}

	public static async void PleaseRespawnBat()
	{
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).maxDistanceFromOriginBeforeRespawn = 50f;
		((TransferrableObject)GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).maxDistanceFromTargetPlayerBeforeRespawn = 50f;
	}

	public static async void BeachBallGun()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
			{
				GameObject.Find("BeachBall").transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			}
		}
	}
}
