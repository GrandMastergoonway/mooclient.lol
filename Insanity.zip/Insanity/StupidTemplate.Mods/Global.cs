using StupidTemplate.Menu;

namespace StupidTemplate.Mods;

internal class Global
{
	public static void ReturnHome()
	{
		Main.buttonsType = 0;
	}

	public static void Overpowerd()
	{
		Main.pageNumber = 1;
	}
}
