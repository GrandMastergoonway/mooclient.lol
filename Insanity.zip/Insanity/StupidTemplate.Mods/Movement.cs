using System.Linq;
using System.Reflection;
using BepInEx;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using Iron_BackGround;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using POpusCodec.Enums;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using UnityEngine;
using UnityEngine.InputSystem;
using Valve.VR;

namespace StupidTemplate.Mods;

internal class Movement
{
	public static float flySpeed = 15f;

	public static float teleDebounce;

	public static Vector3 deadPosition = Vector3.zero;

	public static Vector3 lvel = Vector3.zero;

	public static float splashDel;

	public static NetPlayer linePlayer;

	private static int mute;

	public static bool micre;

	public static async void PlatformGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				GameObject platform = GameObject.CreatePrimitive((PrimitiveType)3);
				Object.Destroy((Object)(object)platform.GetComponent<BoxCollider>());
				platform.GetComponent<Renderer>().material.color = Color.gray / 1f;
				platform.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				platform.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
				platform.transform.position = NewPointer.transform.position;
				platform.transform.rotation = Quaternion.Euler((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
				Object.Destroy((Object)(object)platform, 1f);
				PhotonNetwork.RaiseEvent((byte)69, (object)new object[2]
				{
					platform.transform.position,
					platform.transform.rotation
				}, new RaiseEventOptions
				{
					Receivers = (ReceiverGroup)0
				}, SendOptions.SendReliable);
			}
		}
	}

	public static async void IronMan()
	{
		Vector3 velocity;
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(flySpeed * ((Component)GorillaTagger.Instance.offlineVRRig).transform.Find("rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L").right, (ForceMode)5);
			GorillaTagger instance = GorillaTagger.Instance;
			float num = GorillaTagger.Instance.tapHapticStrength / 50f;
			velocity = ((Collider)Player.Instance.bodyCollider).attachedRigidbody.velocity;
			instance.StartVibration(true, num * ((Vector3)(ref velocity)).magnitude, GorillaTagger.Instance.tapHapticDuration);
		}
		if (((ControllerInputPoller)ControllerInputPoller.instance).leftGrab)
		{
			((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(flySpeed * -((Component)GorillaTagger.Instance.offlineVRRig).transform.Find("rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").right, (ForceMode)5);
			GorillaTagger instance2 = GorillaTagger.Instance;
			float num2 = GorillaTagger.Instance.tapHapticStrength / 50f;
			velocity = ((Collider)Player.Instance.bodyCollider).attachedRigidbody.velocity;
			instance2.StartVibration(false, num2 * ((Vector3)(ref velocity)).magnitude, GorillaTagger.Instance.tapHapticDuration);
		}
	}

	public static async void RigGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if ((((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed) && Time.time > teleDebounce)
			{
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
				teleDebounce = Time.time + 0.5f;
			}
		}
	}

	public static async void Beyblade()
	{
		if (PhotonNetwork.IsConnected)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)GorillaTagger.Instance.bodyCollider).transform.position + new Vector3(0f, 0.35f, 0f);
			try
			{
				((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)GorillaTagger.Instance.bodyCollider).transform.position + new Vector3(0f, 0.35f, 0f);
			}
			catch
			{
			}
			Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
			Quaternion rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			transform.rotation = Quaternion.Euler(((Quaternion)(ref rotation)).eulerAngles + new Vector3(0f, 200f, 0f));
			try
			{
				Transform transform2 = ((Component)GorillaTagger.Instance.myVRRig).transform;
				rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				transform2.rotation = Quaternion.Euler(((Quaternion)(ref rotation)).eulerAngles + new Vector3(0f, 10f, 0f));
			}
			catch
			{
			}
			((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * -1f;
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * 1f;
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void Helicopter()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
			transform.position += new Vector3(0f, 0.05f, 0f);
			try
			{
				Transform transform2 = ((Component)GorillaTagger.Instance.myVRRig).transform;
				transform2.position += new Vector3(0f, 0.05f, 0f);
			}
			catch
			{
			}
			Transform transform3 = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
			Quaternion rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			transform3.rotation = Quaternion.Euler(((Quaternion)(ref rotation)).eulerAngles + new Vector3(0f, 10f, 0f));
			try
			{
				Transform transform4 = ((Component)GorillaTagger.Instance.myVRRig).transform;
				rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				transform4.rotation = Quaternion.Euler(((Quaternion)(ref rotation)).eulerAngles + new Vector3(0f, 10f, 0f));
			}
			catch
			{
			}
			((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * -1f;
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * 1f;
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void PiggybackGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Component)GorillaTagger.Instance.rigidbody).transform.position = ((Component)Main.whoCopy).transform.position + new Vector3(0f, 0.5f, 0f);
				((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
		}
	}

	public static async void CopyMovementGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)Main.whoCopy).transform.position;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)Main.whoCopy).transform.position;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Main.whoCopy.leftHandTransform.position;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Main.whoCopy.rightHandTransform.position;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = Main.whoCopy.leftHandTransform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = Main.whoCopy.rightHandTransform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = Main.whoCopy.headMesh.transform.rotation;
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void Frozone()
	{
		if (Vars.leftGrab)
		{
			GameObject lol = GameObject.CreatePrimitive((PrimitiveType)3);
			lol.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
			lol.transform.localPosition = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.05f, 0f);
			lol.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
			lol.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
			Object.Destroy((Object)(object)lol, 1f);
		}
		if (Vars.rightGrab)
		{
			GameObject lol = GameObject.CreatePrimitive((PrimitiveType)3);
			lol.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
			lol.transform.localPosition = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.05f, 0f);
			lol.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
			lol.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
			Object.Destroy((Object)(object)lol, 1f);
		}
	}

	public static async void PlatformSpam()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			GameObject platform = GameObject.CreatePrimitive((PrimitiveType)3);
			Object.Destroy((Object)(object)platform.GetComponent<BoxCollider>());
			platform.GetComponent<Renderer>().material.color = Color.red;
			platform.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			platform.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
			platform.transform.position = GorillaTagger.Instance.rightHandTransform.position;
			platform.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
			Object.Destroy((Object)(object)platform, 1f);
			PhotonNetwork.RaiseEvent((byte)69, (object)new object[2]
			{
				platform.transform.position,
				platform.transform.rotation
			}, new RaiseEventOptions
			{
				Receivers = (ReceiverGroup)0
			}, SendOptions.SendReliable);
		}
	}

	public static void Fly()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (Vars.rightPrimary)
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)GorillaTagger.Instance.headCollider).transform.forward * Time.deltaTime * flySpeed;
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
		}
	}

	public static async void TriggerFly()
	{
		if (Vars.rightTrigger > 0.5f)
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)GorillaTagger.Instance.headCollider).transform.forward * Time.deltaTime * flySpeed;
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
		}
	}

	public static async void JoystickFly()
	{
		Vector2 joy = ((ControllerInputPoller)ControllerInputPoller.instance).rightControllerPrimary2DAxis;
		if ((double)Mathf.Abs(joy.x) > 0.3 || (double)Mathf.Abs(joy.y) > 0.3)
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)GorillaTagger.Instance.headCollider).transform.forward * Time.deltaTime * (joy.y * flySpeed) + ((Component)GorillaTagger.Instance.headCollider).transform.right * Time.deltaTime * (joy.x * flySpeed);
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
		}
	}

	public static async void BarkFly()
	{
		ZeroGravity();
		Rigidbody rb = ((Collider)Player.Instance.bodyCollider).attachedRigidbody;
		Vector2 xz = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.axis;
		float y = SteamVR_Actions.gorillaTag_RightJoystick2DAxis.axis.y;
		Vector3 inputDirection = new Vector3(xz.x, y, xz.y);
		Vector3 playerForward = ((Component)Player.Instance.bodyCollider).transform.forward;
		playerForward.y = 0f;
		Vector3 playerRight = ((Component)Player.Instance.bodyCollider).transform.right;
		playerRight.y = 0f;
		Vector3 velocity = inputDirection.x * playerRight + y * Vector3.up + inputDirection.z * playerForward;
		velocity *= Player.Instance.scale * flySpeed;
		rb.velocity = Vector3.Lerp(rb.velocity, velocity, 0.12875f);
	}

	public static async void HandFly()
	{
		if (Vars.rightPrimary)
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)GorillaTagger.Instance.offlineVRRig).transform.Find("rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").up * Time.deltaTime * flySpeed;
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
		}
	}

	public static async void SlingshotFly()
	{
		if (Vars.rightPrimary)
		{
			Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component.velocity += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * (flySpeed * 2f);
		}
	}

	public static async void ZeroGravitySlingshotFly()
	{
		if (Vars.rightPrimary)
		{
			ZeroGravity();
			Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component.velocity += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * flySpeed;
		}
	}

	public static async void GrapplingHooks()
	{
		if (Vars.leftGrab)
		{
			if (!Vars.isLeftGrappling)
			{
				Vars.isLeftGrappling = true;
				if (PhotonNetwork.InRoom)
				{
					GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 89, true, 999999f });
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(89, true, 999999f);
				}
				Main.RPCProtection();
				RaycastHit lefthit = default(RaycastHit);
				if (Physics.Raycast(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.forward, ref lefthit, 512f, Main.NoInvisLayerMask()))
				{
					Vars.leftgrapplePoint = ((RaycastHit)(ref lefthit)).point;
				}
				lefthit = default(RaycastHit);
			}
			Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component.velocity += Vector3.Normalize(Vars.leftgrapplePoint - GorillaTagger.Instance.leftHandTransform.position) * 0.5f;
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			Color thecolor = (liner.startColor = Color.red);
			liner.endColor = thecolor;
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.leftHandTransform.position);
			liner.SetPosition(1, Vars.leftgrapplePoint);
			((Renderer)liner).material.shader = Shader.Find("GorillaTag/UberShader");
			Object.Destroy((Object)(object)line, Time.deltaTime);
		}
		else
		{
			RaycastHit Ray = default(RaycastHit);
			Physics.Raycast(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.forward, ref Ray, 512f, Main.NoInvisLayerMask());
			GameObject NewPointer = GameObject.CreatePrimitive((PrimitiveType)0);
			NewPointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			NewPointer.GetComponent<Renderer>().material.color = Vars.buttonDefaultA - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			NewPointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			NewPointer.transform.position = ((RaycastHit)(ref Ray)).point;
			Object.Destroy((Object)(object)NewPointer.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Collider>());
			Object.Destroy((Object)(object)NewPointer, Time.deltaTime);
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			((Renderer)liner).material.shader = Shader.Find("GUI/Text Shader");
			liner.startColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.endColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.leftHandTransform.position);
			liner.SetPosition(1, ((RaycastHit)(ref Ray)).point);
			Object.Destroy((Object)(object)line, Time.deltaTime);
			Vars.isLeftGrappling = false;
			Object.Destroy((Object)(object)Vars.leftjoint);
			Ray = default(RaycastHit);
		}
		if (Vars.rightGrab)
		{
			if (!Vars.isRightGrappling)
			{
				Vars.isRightGrappling = true;
				if (PhotonNetwork.InRoom)
				{
					GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 89, false, 999999f });
					Main.RPCProtection();
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(89, false, 999999f);
				}
				RaycastHit righthit = default(RaycastHit);
				if (Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, ref righthit, 512f, Main.NoInvisLayerMask()))
				{
					Vars.rightgrapplePoint = ((RaycastHit)(ref righthit)).point;
				}
				righthit = default(RaycastHit);
			}
			Rigidbody component2 = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component2.velocity += Vector3.Normalize(Vars.rightgrapplePoint - GorillaTagger.Instance.rightHandTransform.position) * 0.5f;
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			Color thecolor = (liner.startColor = Color.red);
			liner.endColor = thecolor;
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
			liner.SetPosition(1, Vars.rightgrapplePoint);
			((Renderer)liner).material.shader = Shader.Find("GorillaTag/UberShader");
			Object.Destroy((Object)(object)line, Time.deltaTime);
		}
		else
		{
			RaycastHit Ray = default(RaycastHit);
			Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, ref Ray, 512f, Main.NoInvisLayerMask());
			GameObject NewPointer = GameObject.CreatePrimitive((PrimitiveType)0);
			NewPointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			NewPointer.GetComponent<Renderer>().material.color = Vars.buttonDefaultA - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			NewPointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			NewPointer.transform.position = ((RaycastHit)(ref Ray)).point;
			Object.Destroy((Object)(object)NewPointer.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Collider>());
			Object.Destroy((Object)(object)NewPointer, Time.deltaTime);
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			((Renderer)liner).material.shader = Shader.Find("GUI/Text Shader");
			liner.startColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.endColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
			liner.SetPosition(1, ((RaycastHit)(ref Ray)).point);
			Object.Destroy((Object)(object)line, Time.deltaTime);
			Vars.isRightGrappling = false;
			Object.Destroy((Object)(object)Vars.rightjoint);
			Ray = default(RaycastHit);
		}
	}

	public static async void SpiderMan()
	{
		if (Vars.leftGrab)
		{
			if (!Vars.isLeftGrappling)
			{
				Vars.isLeftGrappling = true;
				Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
				component.velocity += GorillaTagger.Instance.leftHandTransform.forward * 5f;
				if (PhotonNetwork.InRoom)
				{
					GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 89, true, 999999f });
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(89, true, 999999f);
				}
				Main.RPCProtection();
				RaycastHit lefthit = default(RaycastHit);
				if (Physics.Raycast(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.forward, ref lefthit, 512f, Main.NoInvisLayerMask()))
				{
					Vars.leftgrapplePoint = ((RaycastHit)(ref lefthit)).point;
					Vars.leftjoint = ((Component)GorillaTagger.Instance).gameObject.AddComponent<SpringJoint>();
					((Joint)Vars.leftjoint).autoConfigureConnectedAnchor = false;
					((Joint)Vars.leftjoint).connectedAnchor = Vars.leftgrapplePoint;
					float leftdistanceFromPoint = Vector3.Distance(((Collider)GorillaTagger.Instance.bodyCollider).attachedRigidbody.position, Vars.leftgrapplePoint);
					Vars.leftjoint.maxDistance = leftdistanceFromPoint * 0.8f;
					Vars.leftjoint.minDistance = leftdistanceFromPoint * 0.25f;
					Vars.leftjoint.spring = 10f;
					Vars.leftjoint.damper = 50f;
					((Joint)Vars.leftjoint).massScale = 12f;
				}
				lefthit = default(RaycastHit);
			}
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			Color thecolor = (liner.startColor = Color.red);
			liner.endColor = thecolor;
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.leftHandTransform.position);
			liner.SetPosition(1, Vars.leftgrapplePoint);
			((Renderer)liner).material.shader = Shader.Find("GorillaTag/UberShader");
			Object.Destroy((Object)(object)line, Time.deltaTime);
		}
		else
		{
			RaycastHit Ray = default(RaycastHit);
			Physics.Raycast(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.forward, ref Ray, 512f, Main.NoInvisLayerMask());
			GameObject NewPointer = GameObject.CreatePrimitive((PrimitiveType)0);
			NewPointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			NewPointer.GetComponent<Renderer>().material.color = Vars.buttonDefaultA - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			NewPointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			NewPointer.transform.position = ((RaycastHit)(ref Ray)).point;
			Object.Destroy((Object)(object)NewPointer.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Collider>());
			Object.Destroy((Object)(object)NewPointer, Time.deltaTime);
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			((Renderer)liner).material.shader = Shader.Find("GUI/Text Shader");
			liner.startColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.endColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.leftHandTransform.position);
			liner.SetPosition(1, ((RaycastHit)(ref Ray)).point);
			Object.Destroy((Object)(object)line, Time.deltaTime);
			Vars.isLeftGrappling = false;
			Object.Destroy((Object)(object)Vars.leftjoint);
			Ray = default(RaycastHit);
		}
		if (Vars.rightGrab)
		{
			if (!Vars.isRightGrappling)
			{
				Vars.isRightGrappling = true;
				Rigidbody component2 = ((Component)Player.Instance).GetComponent<Rigidbody>();
				component2.velocity += GorillaTagger.Instance.rightHandTransform.forward * 5f;
				if (PhotonNetwork.InRoom)
				{
					GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 89, false, 999999f });
					Main.RPCProtection();
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(89, false, 999999f);
				}
				RaycastHit righthit = default(RaycastHit);
				if (Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, ref righthit, 512f, Main.NoInvisLayerMask()))
				{
					Vars.rightgrapplePoint = ((RaycastHit)(ref righthit)).point;
					Vars.rightjoint = ((Component)GorillaTagger.Instance).gameObject.AddComponent<SpringJoint>();
					((Joint)Vars.rightjoint).autoConfigureConnectedAnchor = false;
					((Joint)Vars.rightjoint).connectedAnchor = Vars.rightgrapplePoint;
					float rightdistanceFromPoint = Vector3.Distance(((Collider)GorillaTagger.Instance.bodyCollider).attachedRigidbody.position, Vars.rightgrapplePoint);
					Vars.rightjoint.maxDistance = rightdistanceFromPoint * 0.8f;
					Vars.rightjoint.minDistance = rightdistanceFromPoint * 0.25f;
					Vars.rightjoint.spring = 10f;
					Vars.rightjoint.damper = 50f;
					((Joint)Vars.rightjoint).massScale = 12f;
				}
				righthit = default(RaycastHit);
			}
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			Color thecolor = (liner.startColor = Color.red);
			liner.endColor = thecolor;
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
			liner.SetPosition(1, Vars.rightgrapplePoint);
			((Renderer)liner).material.shader = Shader.Find("GorillaTag/UberShader");
			Object.Destroy((Object)(object)line, Time.deltaTime);
		}
		else
		{
			RaycastHit Ray = default(RaycastHit);
			Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, ref Ray, 512f, Main.NoInvisLayerMask());
			GameObject NewPointer = GameObject.CreatePrimitive((PrimitiveType)0);
			NewPointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			NewPointer.GetComponent<Renderer>().material.color = Vars.buttonDefaultA - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			NewPointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			NewPointer.transform.position = ((RaycastHit)(ref Ray)).point;
			Object.Destroy((Object)(object)NewPointer.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)NewPointer.GetComponent<Collider>());
			Object.Destroy((Object)(object)NewPointer, Time.deltaTime);
			GameObject line = new GameObject("Line");
			LineRenderer liner = line.AddComponent<LineRenderer>();
			((Renderer)liner).material.shader = Shader.Find("GUI/Text Shader");
			liner.startColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.endColor = Color.red - Color32.op_Implicit(new Color32((byte)0, (byte)0, (byte)0, (byte)128));
			liner.startWidth = 0.025f;
			liner.endWidth = 0.025f;
			liner.positionCount = 2;
			liner.useWorldSpace = true;
			liner.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
			liner.SetPosition(1, ((RaycastHit)(ref Ray)).point);
			Object.Destroy((Object)(object)line, Time.deltaTime);
			Vars.isRightGrappling = false;
			Object.Destroy((Object)(object)Vars.rightjoint);
			Ray = default(RaycastHit);
		}
	}

	public static async void ForceTagFreeze()
	{
		Player.Instance.disableMovement = true;
	}

	public static async void NoTagFreeze()
	{
		Player.Instance.disableMovement = false;
	}

	public static async void LowGravity()
	{
		((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (6.66f / Time.deltaTime)), (ForceMode)5);
	}

	public static async void HighGravity()
	{
		((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.down * (Time.deltaTime * (7.77f / Time.deltaTime)), (ForceMode)5);
	}

	public static async void ReverseGravity()
	{
		((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (19.62f / Time.deltaTime)), (ForceMode)5);
		Player.Instance.rightControllerTransform.parent.rotation = Quaternion.Euler(180f, 0f, 0f);
	}

	public static async void UnflipCharacter()
	{
		Player.Instance.rightControllerTransform.parent.rotation = Quaternion.identity;
	}

	public static async void SpiderWalk()
	{
		if (Player.Instance.wasLeftHandTouching || Player.Instance.wasRightHandTouching)
		{
			FieldInfo fieldInfo = typeof(Player).GetField("lastHitInfoHand", BindingFlags.Instance | BindingFlags.NonPublic);
			RaycastHit ray = (RaycastHit)fieldInfo.GetValue(Player.Instance);
			Vars.walkPos = ((RaycastHit)(ref ray)).point;
			Vars.walkNormal = ((RaycastHit)(ref ray)).normal;
			ray = default(RaycastHit);
		}
		if (Vars.walkPos != Vector3.zero)
		{
			((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vars.walkNormal * -9.81f, (ForceMode)5);
			Player.Instance.rightControllerTransform.parent.rotation = Quaternion.Lerp(Player.Instance.rightControllerTransform.parent.rotation, Quaternion.LookRotation(Vars.walkNormal) * Quaternion.Euler(90f, 0f, 0f), Time.deltaTime);
			ZeroGravity();
		}
	}

	public static async void TeleportToRandom()
	{
		Main.TeleportPlayer(((Component)RigManager.GetRandomVRRig(includeSelf: false)).transform.position);
		((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
	}

	public static async void TeleportGun()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if ((Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed) && Time.time > teleDebounce)
			{
				Main.TeleportPlayer(NewPointer.transform.position + new Vector3(0f, 1f, 0f));
				((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
				teleDebounce = Time.time + 0.5f;
			}
		}
	}

	public static async void Noclip()
	{
		if (Vars.rightTrigger > 0.5f || UnityInput.Current.GetKey((KeyCode)101))
		{
			if (!Vars.noclip)
			{
				Vars.noclip = true;
				MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
				foreach (MeshCollider v in array)
				{
					((Collider)v).enabled = false;
				}
			}
		}
		else if (Vars.noclip)
		{
			Vars.noclip = false;
			MeshCollider[] array2 = Resources.FindObjectsOfTypeAll<MeshCollider>();
			foreach (MeshCollider v in array2)
			{
				((Collider)v).enabled = true;
			}
		}
	}

	public static async void GrabRig()
	{
		if (Vars.rightGrab)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.offlineVRRig).transform.position = GorillaTagger.Instance.rightHandTransform.position;
			Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
			Quaternion rotation = GorillaTagger.Instance.rightHandTransform.rotation;
			transform.rotation = Quaternion.Euler(new Vector3(0f, ((Quaternion)(ref rotation)).eulerAngles.y, 0f));
			try
			{
				((Component)GorillaTagger.Instance.myVRRig).transform.position = GorillaTagger.Instance.rightHandTransform.position;
				Transform transform2 = ((Component)GorillaTagger.Instance.myVRRig).transform;
				rotation = GorillaTagger.Instance.rightHandTransform.rotation;
				transform2.rotation = Quaternion.Euler(new Vector3(0f, ((Quaternion)(ref rotation)).eulerAngles.y, 0f));
				return;
			}
			catch
			{
				return;
			}
		}
		((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
	}

	public static async void EnableSpazRig()
	{
		Vars.ghostException = true;
		Vars.offsetLH = GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset;
		Vars.offsetRH = GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset;
		Vars.offsetH = GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset;
	}

	public static async void SpazRig()
	{
		if (Vars.rightPrimary)
		{
			float spazAmount = 0.1f;
			Vars.ghostException = true;
			GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Vars.offsetLH + new Vector3(Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount));
			GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Vars.offsetRH + new Vector3(Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount));
			GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Vars.offsetH + new Vector3(Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount), Random.Range(0f - spazAmount, spazAmount));
		}
		else
		{
			Vars.ghostException = false;
			GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Vars.offsetLH;
			GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Vars.offsetRH;
			GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Vars.offsetH;
		}
	}

	public static async void DisableSpazRig()
	{
		Vars.ghostException = false;
		GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Vars.offsetLH;
		GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Vars.offsetRH;
		GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Vars.offsetH;
	}

	public static async void SpazHands()
	{
		if (Vars.rightPrimary)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)GorillaTagger.Instance.bodyCollider).transform.position + new Vector3(0f, 0.15f, 0f);
			try
			{
				((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)GorillaTagger.Instance.bodyCollider).transform.position + new Vector3(0f, 0.15f, 0f);
			}
			catch
			{
			}
			((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation = ((Component)GorillaTagger.Instance.bodyCollider).transform.rotation;
			try
			{
				((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)GorillaTagger.Instance.bodyCollider).transform.rotation;
			}
			catch
			{
			}
			((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.headCollider).transform.rotation;
			float spazAmount = 360f;
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = Quaternion.Euler(new Vector3(Random.Range(0f, spazAmount), Random.Range(0f, spazAmount), Random.Range(0f, spazAmount)));
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = Quaternion.Euler(new Vector3(Random.Range(0f, spazAmount), Random.Range(0f, spazAmount), Random.Range(0f, spazAmount)));
			((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = GorillaTagger.Instance.leftHandTransform.position + ((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.forward * 3f;
			((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = GorillaTagger.Instance.rightHandTransform.position + ((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.forward * 3f;
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void FakeOculusMenu()
	{
		if (Vars.leftPrimary)
		{
			NoFinger();
			((Component)GorillaTagger.Instance.rightHandTransform).transform.rotation = Quaternion.identity;
			((Component)GorillaTagger.Instance.leftHandTransform).transform.rotation = Quaternion.identity;
		}
		Player.Instance.inOverlay = Vars.leftPrimary;
	}

	public static async void NoFinger()
	{
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerGripFloat = 0f;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerGripFloat = 0f;
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexFloat = 0f;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexFloat = 0f;
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerPrimaryButton = false;
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerSecondaryButton = false;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerPrimaryButton = false;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerSecondaryButton = false;
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerPrimaryButtonTouch = false;
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerSecondaryButtonTouch = false;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerPrimaryButtonTouch = false;
		((ControllerInputPoller)ControllerInputPoller.instance).rightControllerSecondaryButtonTouch = false;
	}

	public static async void FakePowerOff()
	{
		if (SteamVR_Actions.gorillaTag_LeftJoystickClick.state)
		{
			if (deadPosition == Vector3.zero)
			{
				deadPosition = ((Component)GorillaTagger.Instance.rigidbody).transform.position;
				lvel = ((Component)Player.Instance).GetComponent<Rigidbody>().velocity;
			}
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.rigidbody).transform.position = deadPosition;
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = lvel;
		}
		else
		{
			deadPosition = Vector3.zero;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void SizeChanger()
	{
		if (Vars.rightPrimary)
		{
			Vars.sizeScale = 1f;
		}
		if (Vars.rightTrigger > 0.5f)
		{
			Vars.sizeScale += 0.05f;
		}
		if (Vars.rightGrab)
		{
			Vars.sizeScale -= 0.05f;
		}
		if (Vars.sizeScale <= 0f)
		{
			Vars.sizeScale = 0.05f;
		}
		Player.Instance.scale = Vars.sizeScale;
	}

	public static async void SolidPlayers()
	{
		foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			if ((Object)(object)vrrig != (Object)(object)GorillaTagger.Instance.offlineVRRig && Vector3.Distance(((Component)vrrig).transform.position, ((Component)GorillaTagger.Instance.headCollider).transform.position) < 5f)
			{
				Vector3 pointA = ((Component)vrrig.head.rigTarget).transform.position + new Vector3(0f, 0.16f, 0f);
				Vector3 pointB = ((Component)vrrig.head.rigTarget).transform.position - new Vector3(0f, 0.4f, 0f);
				GameObject bodyCollider = GameObject.CreatePrimitive((PrimitiveType)3);
				Object.Destroy((Object)(object)bodyCollider.GetComponent<Rigidbody>());
				bodyCollider.GetComponent<Renderer>().enabled = false;
				bodyCollider.transform.position = Vector3.Lerp(pointA, pointB, 0.5f);
				bodyCollider.transform.rotation = ((Component)vrrig).transform.rotation;
				bodyCollider.transform.localScale = new Vector3(0.3f, 0.55f, 0.3f);
				Object.Destroy((Object)(object)bodyCollider, Time.deltaTime * 2f);
				for (int i = 0; i < Vars.bones.Count(); i += 2)
				{
					pointA = vrrig.mainSkin.bones[Vars.bones[i]].position;
					pointB = vrrig.mainSkin.bones[Vars.bones[i + 1]].position;
					bodyCollider = GameObject.CreatePrimitive((PrimitiveType)3);
					Object.Destroy((Object)(object)bodyCollider.GetComponent<Rigidbody>());
					bodyCollider.GetComponent<Renderer>().enabled = false;
					bodyCollider.transform.position = Vector3.Lerp(pointA, pointB, 0.5f);
					bodyCollider.transform.LookAt(pointB);
					bodyCollider.transform.localScale = new Vector3(0.2f, 0.2f, Vector3.Distance(pointA, pointB));
					Object.Destroy((Object)(object)bodyCollider, Time.deltaTime * 2f);
				}
			}
		}
	}

	public static async void OrbitPlayerGun()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Vars.isCopying && (Object)(object)Vars.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)Vars.whoCopy).transform.position + new Vector3(Mathf.Cos((float)Time.frameCount / 20f), 0.5f, Mathf.Sin((float)Time.frameCount / 20f));
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)Vars.whoCopy).transform.position + new Vector3(Mathf.Cos((float)Time.frameCount / 20f), 0.5f, Mathf.Sin((float)Time.frameCount / 20f));
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.LookAt(((Component)Vars.whoCopy).transform.position);
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.LookAt(((Component)Vars.whoCopy).transform.position);
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * -1f;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * 1f;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				FixRigHandRotation();
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftIndex).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftMiddle).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftThumb).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftIndex).LerpFinger(1f, false);
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftMiddle).LerpFinger(1f, false);
				((VRMap)GorillaTagger.Instance.offlineVRRig.leftThumb).LerpFinger(1f, false);
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightIndex).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightMiddle).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightThumb).calcT = 0f;
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightIndex).LerpFinger(1f, false);
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightMiddle).LerpFinger(1f, false);
				((VRMap)GorillaTagger.Instance.offlineVRRig.rightThumb).LerpFinger(1f, false);
			}
			if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Vars.isCopying = true;
					Vars.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Vars.isCopying)
		{
			Vars.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void FixRigHandRotation()
	{
		Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform;
		transform.rotation *= Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.leftHand.trackingRotationOffset);
		Transform transform2 = ((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform;
		transform2.rotation *= Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.rightHand.trackingRotationOffset);
	}

	public static async void ThrowControllers()
	{
		if (Vars.leftPrimary)
		{
			if ((Object)(object)Vars.leftThrow != (Object)null)
			{
				Player.Instance.leftControllerTransform.position = Vars.leftThrow.transform.position;
				Player.Instance.leftControllerTransform.rotation = Vars.leftThrow.transform.rotation;
			}
			else
			{
				Vars.leftThrow = GameObject.CreatePrimitive((PrimitiveType)3);
				Vars.leftThrow.GetComponent<Renderer>().enabled = false;
				Object.Destroy((Object)(object)Vars.leftThrow.GetComponent<BoxCollider>());
				Object.Destroy((Object)(object)Vars.leftThrow.GetComponent<Rigidbody>());
				Vars.leftThrow.transform.position = Player.Instance.leftControllerTransform.position;
				Vars.leftThrow.transform.rotation = Player.Instance.leftControllerTransform.rotation;
				Component obj = Vars.leftThrow.AddComponent(typeof(Rigidbody));
				Rigidbody comp = (Rigidbody)(object)((obj is Rigidbody) ? obj : null);
				comp.velocity = Player.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
				try
				{
					if ((Object)(object)GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/LeftHand Controller").GetComponent<GorillaVelocityEstimator>() == (Object)null)
					{
						GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/LeftHand Controller").AddComponent<GorillaVelocityEstimator>();
					}
					comp.angularVelocity = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/LeftHand Controller").GetComponent<GorillaVelocityEstimator>().angularVelocity;
				}
				catch
				{
				}
			}
		}
		else if ((Object)(object)Vars.leftThrow != (Object)null)
		{
			Object.Destroy((Object)(object)Vars.leftThrow);
			Vars.leftThrow = null;
		}
		if (Vars.rightPrimary)
		{
			if ((Object)(object)Vars.rightThrow != (Object)null)
			{
				Player.Instance.rightControllerTransform.position = Vars.rightThrow.transform.position;
				Player.Instance.rightControllerTransform.rotation = Vars.rightThrow.transform.rotation;
				return;
			}
			Vars.rightThrow = GameObject.CreatePrimitive((PrimitiveType)3);
			Vars.rightThrow.GetComponent<Renderer>().enabled = false;
			Object.Destroy((Object)(object)Vars.rightThrow.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)Vars.rightThrow.GetComponent<Rigidbody>());
			Vars.rightThrow.transform.position = Player.Instance.rightControllerTransform.position;
			Vars.rightThrow.transform.rotation = Player.Instance.rightControllerTransform.rotation;
			Component obj3 = Vars.rightThrow.AddComponent(typeof(Rigidbody));
			Rigidbody comp = (Rigidbody)(object)((obj3 is Rigidbody) ? obj3 : null);
			comp.velocity = Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
			try
			{
				if ((Object)(object)GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/RightHand Controller").GetComponent<GorillaVelocityEstimator>() == (Object)null)
				{
					GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/RightHand Controller").AddComponent<GorillaVelocityEstimator>();
				}
				comp.angularVelocity = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/RightHand Controller").GetComponent<GorillaVelocityEstimator>().angularVelocity;
			}
			catch
			{
			}
		}
		else if ((Object)(object)Vars.rightThrow != (Object)null)
		{
			Object.Destroy((Object)(object)Vars.rightThrow);
			Vars.rightThrow = null;
		}
	}

	public static async void PunchMod()
	{
		int index = -1;
		foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			if ((Object)(object)vrrig != (Object)(object)GorillaTagger.Instance.offlineVRRig)
			{
				index++;
				Vector3 they = vrrig.rightHandTransform.position;
				Vector3 notthem = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
				float distance = Vector3.Distance(they, notthem);
				if ((double)distance < 0.25)
				{
					Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
					component.velocity += Vector3.Normalize(vrrig.rightHandTransform.position - Vars.lastRight[index]) * 50f;
				}
				Vars.lastRight[index] = vrrig.rightHandTransform.position;
				they = vrrig.leftHandTransform.position;
				distance = Vector3.Distance(they, notthem);
				if ((double)distance < 0.25)
				{
					Rigidbody component2 = ((Component)Player.Instance).GetComponent<Rigidbody>();
					component2.velocity += Vector3.Normalize(vrrig.leftHandTransform.position - Vars.lastLeft[index]) * 50f;
				}
				Vars.lastLeft[index] = vrrig.leftHandTransform.position;
			}
		}
	}

	public static async void Invisible()
	{
		bool hit = Vars.rightSecondary || Mouse.current.rightButton.isPressed;
		if (Vars.invisMonke)
		{
			Vars.ghostException = true;
			GorillaTagger.Instance.offlineVRRig.headBodyOffset = new Vector3(99999f, 99999f, 99999f);
		}
		else
		{
			Vars.ghostException = false;
			GorillaTagger.Instance.offlineVRRig.headBodyOffset = Vector3.zero;
		}
		if (hit && !Vars.lastHit2)
		{
			Vars.invisMonke = !Vars.invisMonke;
		}
		Vars.lastHit2 = hit;
	}

	public static async void DisableInvisible()
	{
		GorillaTagger.Instance.offlineVRRig.headBodyOffset = Vector3.zero;
		Vars.ghostException = false;
	}

	public static async void Ghost()
	{
		bool hit = Vars.rightPrimary || Mouse.current.leftButton.isPressed;
		((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = !Vars.ghostMonke;
		if (hit && !Vars.lastHit)
		{
			Vars.ghostMonke = !Vars.ghostMonke;
		}
		Vars.lastHit = hit;
	}

	public static async void EnableRig()
	{
		((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		Vars.ghostException = false;
	}

	public static async void RigGun1()
	{
		if (!Vars.rightGrab && !Mouse.current.rightButton.isPressed)
		{
			return;
		}
		(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
		_ = GunData.Ray;
		GameObject NewPointer = GunData.NewPointer;
		if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.offlineVRRig).transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			try
			{
				((Component)GorillaTagger.Instance.myVRRig).transform.position = NewPointer.transform.position + new Vector3(0f, 1f, 0f);
			}
			catch
			{
			}
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void ChangeFlySpeed()
	{
		Vars.flySpeedCycle++;
		if (Vars.flySpeedCycle > 3)
		{
			Vars.flySpeedCycle = 0;
		}
		float[] speedamounts = new float[4] { 5f, 10f, 30f, 60f };
		flySpeed = speedamounts[Vars.flySpeedCycle];
		string[] speedNames = new string[4] { "Slow", "Normal", "Fast", "Extra Fast" };
		Main.GetIndex("Change Fly Speed").overlapText = "Change Fly Speed <color=grey>[</color><color=green>" + speedNames[Vars.flySpeedCycle] + "</color><color=grey>]</color>";
	}

	public static async void SpeedBoost()
	{
		Player.Instance.maxJumpSpeed = Vars.jspeed;
		Player.Instance.jumpMultiplier = Vars.jmulti;
	}

	public static async void Airstrike()
	{
		if (Vars.rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			_ = GunData.Ray;
			GameObject NewPointer = GunData.NewPointer;
			if ((Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed) && Time.time > teleDebounce)
			{
				Main.TeleportPlayer(NewPointer.transform.position + new Vector3(0f, 30f, 0f));
				((Component)Player.Instance).GetComponent<Rigidbody>().velocity = new Vector3(0f, -20f, 0f);
				teleDebounce = Time.time + 0.5f;
			}
		}
	}

	public static async void WallWalk()
	{
		if (Player.Instance.wasLeftHandTouching || Player.Instance.wasRightHandTouching)
		{
			FieldInfo fieldInfo = typeof(Player).GetField("lastHitInfoHand", BindingFlags.Instance | BindingFlags.NonPublic);
			RaycastHit ray = (RaycastHit)fieldInfo.GetValue(Player.Instance);
			Vars.walkPos = ((RaycastHit)(ref ray)).point;
			Vars.walkNormal = ((RaycastHit)(ref ray)).normal;
			ray = default(RaycastHit);
		}
		if (Vars.walkPos != Vector3.zero && Vars.rightGrab)
		{
			((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vars.walkNormal * -9.81f, (ForceMode)5);
			ZeroGravity();
		}
	}

	public static async void SpazHead()
	{
		GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = Random.Range(0f, 360f);
		GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = Random.Range(0f, 360f);
		GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = Random.Range(0f, 360f);
	}

	public static async void DisableSpiderMan()
	{
		Vars.isLeftGrappling = false;
		Object.Destroy((Object)(object)Vars.leftjoint);
		Vars.isRightGrappling = false;
		Object.Destroy((Object)(object)Vars.rightjoint);
	}

	public static async void UpAndDown()
	{
		if (Vars.rightTrigger > 0.5f || Vars.rightGrab)
		{
			ZeroGravity();
		}
		if (Vars.rightTrigger > 0.5f)
		{
			Rigidbody component = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component.velocity += Vector3.up * Time.deltaTime * flySpeed * 3f;
		}
		if (Vars.rightGrab)
		{
			Rigidbody component2 = ((Component)Player.Instance).GetComponent<Rigidbody>();
			component2.velocity += Vector3.up * Time.deltaTime * flySpeed * -3f;
		}
	}

	public static async void ZeroGravity()
	{
		((Collider)Player.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), (ForceMode)5);
	}

	public static async void NoclipFly()
	{
		if (Vars.rightPrimary)
		{
			Transform transform = ((Component)Player.Instance).transform;
			transform.position += ((Component)GorillaTagger.Instance.headCollider).transform.forward * Time.deltaTime * flySpeed;
			((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
			if (!Vars.noclip)
			{
				Vars.noclip = true;
				MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
				foreach (MeshCollider v in array)
				{
					((Collider)v).enabled = false;
				}
			}
		}
		else if (Vars.noclip)
		{
			Vars.noclip = false;
			MeshCollider[] array2 = Resources.FindObjectsOfTypeAll<MeshCollider>();
			foreach (MeshCollider v in array2)
			{
				((Collider)v).enabled = true;
			}
		}
	}

	public static async void FollowPlayerGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				Vector3 look = ((Component)Main.whoCopy).transform.position - ((Component)GorillaTagger.Instance.offlineVRRig).transform.position;
				((Vector3)(ref look)).Normalize();
				Vector3 position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + look * (flySpeed / 2f * Time.deltaTime);
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = position;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = position;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.LookAt(((Component)Main.whoCopy).transform.position);
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.LookAt(((Component)Main.whoCopy).transform.position);
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * -1f;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * 1f;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				look = default(Vector3);
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void JumpscareGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = Main.whoCopy.headMesh.transform.position + Main.whoCopy.headMesh.transform.forward * (Random.Range(10f, 50f) / 100f);
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = Main.whoCopy.headMesh.transform.position + Main.whoCopy.headMesh.transform.forward * (Random.Range(10f, 50f) / 100f);
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.LookAt(Main.whoCopy.headMesh.transform.position);
				Quaternion dirLook = ((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation = dirLook;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = dirLook;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Main.whoCopy.headMesh.transform.position + Main.whoCopy.headMesh.transform.right * 0.2f;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Main.whoCopy.headMesh.transform.position + Main.whoCopy.headMesh.transform.right * -0.2f;
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = dirLook;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation;
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void AnnoyPlayerGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				Vector3 position = ((Component)Main.whoCopy).transform.position + new Vector3(Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f);
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = position;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = position;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.LookAt(((Component)Main.whoCopy).transform.position);
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.LookAt(((Component)Main.whoCopy).transform.position);
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + new Vector3(Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f);
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + new Vector3(Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f, Random.Range(-10f, 10f) / 10f);
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = Quaternion.Euler(new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360)));
				if (PhotonNetwork.InRoom)
				{
					GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 91, false, 999999f });
					Main.RPCProtection();
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(91, false, 999999f);
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void IntercourseGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.forward * (0f - (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f));
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.forward * (0f - (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f));
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.right * -0.2f + ((Component)Main.whoCopy).transform.up * -0.4f;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.right * 0.2f + ((Component)Main.whoCopy).transform.up * -0.4f;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.forward * (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f);
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.forward * (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f);
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				try
				{
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				}
				catch
				{
				}
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.right * -0.2f + ((Component)Main.whoCopy).transform.up * -0.4f;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = ((Component)Main.whoCopy).transform.position + ((Component)Main.whoCopy).transform.right * 0.2f + ((Component)Main.whoCopy).transform.up * -0.4f;
				((Component)GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				((Component)GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component)Main.whoCopy).transform.rotation;
				if (Time.frameCount % 45 == 0)
				{
					if (PhotonNetwork.InRoom)
					{
						GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 64, false, 999999f });
						Main.RPCProtection();
					}
					else
					{
						GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(64, false, 999999f);
					}
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Main.isCopying = true;
					Main.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void WaterSplashHands()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab && Time.time > splashDel)
		{
			GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", (RpcTarget)0, new object[6]
			{
				GorillaTagger.Instance.rightHandTransform.position,
				GorillaTagger.Instance.rightHandTransform.rotation,
				4f,
				100f,
				true,
				false
			});
			Main.RPCProtection();
			splashDel = Time.time + 0.1f;
		}
		if (((ControllerInputPoller)ControllerInputPoller.instance).leftGrab && Time.time > splashDel)
		{
			GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", (RpcTarget)0, new object[6]
			{
				GorillaTagger.Instance.leftHandTransform.position,
				GorillaTagger.Instance.leftHandTransform.rotation,
				4f,
				100f,
				true,
				false
			});
			Main.RPCProtection();
			splashDel = Time.time + 0.1f;
		}
	}

	public static async void LowQualityMicrophone()
	{
		micre = true;
		if (micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			mic.SamplingRate = (SamplingRate)8000;
			mic.Bitrate = 5;
			mic.RestartRecording(true);
		}
	}

	public static async void HighQualityMicrophone()
	{
		micre = true;
		if (micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			mic.SamplingRate = (SamplingRate)16000;
			mic.Bitrate = 30000;
			mic.RestartRecording(true);
		}
	}

	public static async void LoudMicrophone()
	{
		micre = true;
		if (micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			if (!Object.op_Implicit((Object)(object)((Component)mic).gameObject.GetComponent<MicAmplifier>()))
			{
				((Component)mic).gameObject.AddComponent<MicAmplifier>();
			}
			MicAmplifier loudman = ((Component)mic).gameObject.GetComponent<MicAmplifier>();
			loudman.AmplificationFactor = 16f;
			loudman.BoostValue = 16f;
			mic.RestartRecording(true);
		}
	}

	public static async void BassSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 68, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(68, false, 999999f);
			}
		}
	}

	public static async void MetalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 18, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(18, false, 999999f);
			}
		}
	}

	public static async void WolfSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 195, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(195, false, 999999f);
			}
		}
	}

	public static async void CatSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 236, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(236, false, 999999f);
			}
		}
	}

	public static async void TurkeySoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 83, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(83, false, 999999f);
			}
		}
	}

	public static async void FrogSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 91, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(91, false, 999999f);
			}
		}
	}

	public static async void BeeSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 191, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(191, false, 999999f);
			}
		}
	}

	public static async void EarrapeSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 215, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(215, false, 999999f);
			}
		}
	}

	public static async void DingSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 244, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(244, false, 999999f);
			}
		}
	}

	public static async void CrystalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			int[] sounds = new int[2]
			{
				Random.Range(40, 54),
				Random.Range(214, 221)
			};
			int soundId = sounds[Random.Range(0, 1)];
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { soundId, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(soundId, false, 999999f);
			}
			Main.RPCProtection();
		}
	}

	public static async void BigCrystalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 213, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(213, false, 999999f);
			}
		}
	}

	public static async void PanSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 248, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(248, false, 999999f);
			}
		}
	}

	public static async void AK47SoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 203, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(203, false, 999999f);
			}
		}
	}

	public static async void SqueakSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3]
				{
					75 + Time.frameCount % 2,
					false,
					999999f
				});
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(75 + Time.frameCount % 2, false, 999999f);
			}
		}
	}

	public static async void RandomSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			int soundId = Random.Range(0, 259);
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { soundId, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(soundId, false, 999999f);
			}
		}
	}

	public static async void SirenSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3]
				{
					48 + Time.frameCount / 15 % 2 * 2,
					false,
					999999f
				});
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(48 + Time.frameCount / 15 % 2 * 2, false, 999999f);
			}
		}
	}

	public static async void ChamsSelf()
	{
		((Renderer)GorillaTagger.Instance.offlineVRRig.mainSkin).material.shader = Shader.Find("GUI/Text Shader");
		((Renderer)GorillaTagger.Instance.offlineVRRig.mainSkin).material.color = Color32.op_Implicit(Infected(GorillaTagger.Instance.offlineVRRig) ? new Color32(byte.MaxValue, (byte)0, (byte)0, (byte)50) : new Color32((byte)0, byte.MaxValue, (byte)0, (byte)50));
	}

	public static bool Infected(VRRig rig)
	{
		return ((Object)((Renderer)rig.mainSkin).material).name.Contains("fected");
	}

	public static async void muteall()
	{
		GorillaPlayerScoreboardLine[] array = Object.FindObjectsOfType<GorillaPlayerScoreboardLine>();
		for (int i = 0; i < array.Length; i++)
		{
			_ = array[i];
			GorillaPlayerScoreboardLine.MutePlayer(linePlayer.UserId, linePlayer.NickName, mute);
		}
	}

	public static async void NotLoudMicrophone()
	{
		if (micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			if (Object.op_Implicit((Object)(object)((Component)mic).gameObject.GetComponent<MicAmplifier>()))
			{
				Object.Destroy((Object)(object)((Component)mic).gameObject.GetComponent<MicAmplifier>());
			}
			micre = false;
		}
	}

	public static async void ReloadMicrophone()
	{
		if (micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			mic.RestartRecording(true);
			micre = false;
		}
	}

	public static async void StareAtNearby()
	{
		GorillaTagger.Instance.offlineVRRig.headConstraint.LookAt(RigManager.GetClosestVRRig().headMesh.transform.position);
	}

	public static async void StareAtGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			Nigger.GunLibData GunData = Nigger.Shoot();
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				GorillaTagger.Instance.offlineVRRig.headConstraint.LookAt(Main.whoCopy.headMesh.transform.position);
			}
			if ((((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed) && Object.op_Implicit((Object)(object)GunData.lockedPlayer) && (Object)(object)GunData.lockedPlayer != (Object)(object)GorillaTagger.Instance.offlineVRRig)
			{
				Main.isCopying = true;
				Main.whoCopy = GunData.lockedPlayer;
			}
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			Nigger.GunCleanUp();
		}
	}
}
