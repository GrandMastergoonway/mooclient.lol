using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using ExitGames.Client.Photon;
using GorillaLocomotion.Gameplay;
using GorillaNetworking;
using GorillaTagScripts;
using GorillaTagScripts.ObstacleCourse;
using HarmonyLib;
using Iron_BackGround;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace StupidTemplate.Mods;

internal class OverPowered
{
	public static float lastTime = -1f;

	public static float gamemodeSetTimeAt = -1f;

	public static bool DaddyWako = false;

	public static float NameDelay;

	public static float SettingNameDelay;

	public static string NameChangerString = null;

	public static string NameChangingString;

	private static float stupiddelay = 0f;

	private static PhotonView doorView = null;

	public static float colorFloat;

	public static float deltaTime;

	public static float fov = 60f;

	public static int Game;

	private static float lagtimeout;

	public static float crash;

	public static int crash1;

	private static Player crashedPlayer;

	private static Vector3 crashPlayerPosition = Vector3.zero;

	public static float spamtagdelay;

	public static float stutterTimeout;

	public static VRRig who;

	public static bool IsModded()
	{
		return ((object)((RoomInfo)PhotonNetwork.CurrentRoom).CustomProperties).ToString().Contains("MODDED");
	}

	public static async void Antiban()
	{
		if (!IsModded())
		{
			Hashtable hashtable = new Hashtable();
			((Dictionary<object, object>)(object)hashtable).Add((object)"gameMode", (object)((RoomInfo)PhotonNetwork.CurrentRoom).CustomProperties[(object)"gameMode"].ToString().Replace(((GorillaComputer)GorillaComputer.instance).currentQueue, ((GorillaComputer)GorillaComputer.instance).currentQueue + "MODDED_MODDED_"));
			Hashtable hashtable2 = hashtable;
			PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable2, (Hashtable)null, (WebFlags)null);
			PhotonNetwork.CurrentRoom.IsOpen = false;
			PhotonNetwork.CurrentRoom.IsVisible = false;
			PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, (Hashtable)null, (WebFlags)null);
			PlayFabClientAPI.ExecuteCloudScript(new ExecuteCloudScriptRequest
			{
				FunctionName = "RoomClosed",
				FunctionParameter = new
				{
					GameId = PhotonNetwork.CurrentRoom.Name,
					Region = Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper(),
					ActorNr = PhotonNetwork.LocalPlayer.ActorNumber,
					GetSelf = PhotonNetwork.LocalPlayer,
					LeaderBoardid = Object.FindFirstObjectByType<GorillaScoreBoard>(),
					Logedin = PlayFabClientAPI.IsClientLoggedIn(),
					GetAllPayers = PhotonNetwork.PlayerListOthers,
					Getplayers = PhotonNetwork.PlayerList.Count(),
					Gorilla = Object.FindAnyObjectByType<GorillaNetworkLobbyJoinTrigger>().joinFailedBlock,
					UserId = PhotonNetwork.LocalPlayer.UserId,
					AppVersion = PhotonNetwork.AppVersion,
					AppId = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime,
					Type = "Close"
				}
			}, (Action<ExecuteCloudScriptResult>)delegate
			{
				DaddyWako = true;
			}, (Action<PlayFabError>)null, (object)null, (Dictionary<string, string>)null);
		}
	}

	public static async void BreakMovement()
	{
		RopeSwingManager[] array = Object.FindObjectsOfType<RopeSwingManager>();
		for (int i = 0; i < array.Length; i++)
		{
			_ = array[i];
			PhotonView photonView = ((MonoBehaviourPun)RopeSwingManager.instance).photonView;
			photonView.RPC("SetVelocity", (RpcTarget)0, new object[4]
			{
				1,
				(object)new Vector3(Random.Range(float.MinValue, float.MaxValue), Random.Range(float.MinValue, float.MaxValue), Random.Range(float.MinValue, float.MaxValue)),
				true,
				null
			});
		}
	}

	public static async void Breakurmovement()
	{
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		for (int i = 0; i < playerListOthers.Length; i++)
		{
			_ = playerListOthers[i];
			Object.Destroy((Object)(object)GameObject.Find("pit ground").GetComponent<Collider>());
		}
	}

	public static async void BetaSetStatus(int state, RaiseEventOptions balls)
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			SetMatster();
			return;
		}
		object[] statusSendData = new object[1] { state };
		PhotonNetwork.RaiseEvent((byte)3, (object)new object[3]
		{
			PhotonNetwork.ServerTimestamp,
			(byte)2,
			statusSendData
		}, balls, SendOptions.SendUnreliable);
	}

	public static async void BreakAllmovement()
	{
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		for (int i = 0; i < playerListOthers.Length; i++)
		{
			_ = playerListOthers[i];
			Object.Destroy((Object)(object)GameObject.Find("pit ground").GetComponent<Collider>());
			BetaSetStatus(0, new RaiseEventOptions
			{
				Receivers = (ReceiverGroup)0
			});
			Main.RPCProtection();
			Vars.kgDebounce = Time.time + 1f;
		}
	}

	public static async void NameChangeAll()
	{
		if (NameChangerString == null && SettingNameDelay < Time.time)
		{
			SettingNameDelay = Time.time + 5f;
			NotifiLib.SendNotification("<color=blue>[NAME CHANGER]</color> Assign the thing to change their names to on the gui!");
		}
		else if (NameDelay < Time.time)
		{
			NameDelay = Time.time + 0.05f;
			Player[] playerList = PhotonNetwork.PlayerList;
			foreach (Player p in playerList)
			{
				p.NickName = NameChangingString;
				Type targ = typeof(Player);
				targ.GetMethod("SetPlayerNameProperty", BindingFlags.Instance | BindingFlags.NonPublic)?.Invoke(p, new object[0]);
				Main.RPCProtection();
			}
		}
	}

	public static async void Namechangeall()
	{
		Player[] playerList = PhotonNetwork.PlayerList;
		foreach (Player player in playerList)
		{
			if (PhotonNetwork.LocalPlayer != PhotonNetwork.MasterClient)
			{
				continue;
			}
			if (Main.GetIndex("Namechangeall").enabled && NameChangerString == null)
			{
				GUI.Box(new Rect(250f, 250f, 200f, 150f), "Assign Name Changing Name");
				NameChangingString = GUI.TextField(new Rect(250f, 300f, 200f, 50f), NameChangingString);
				if (GUI.Button(new Rect(250f, 350f, 200f, 50f), "Submit"))
				{
					NameChangerString = NameChangingString;
				}
			}
			Hashtable hashtable = new Hashtable();
			hashtable[byte.MaxValue] = "Iron.cc ON TOP";
			Dictionary<byte, object> dictionary = new Dictionary<byte, object>
			{
				{ 251, hashtable },
				{ 254, player.ActorNumber },
				{ 250, true }
			};
			((PhotonPeer)PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer).SendOperation((byte)252, dictionary, SendOptions.SendUnreliable);
			NotifiLib.SendNotification("Look at the Leaderboard!");
		}
	}

	public static async void KickAllInParty()
	{
		if (FriendshipGroupDetection.Instance.IsInParty)
		{
			Vars.partyLastCode = PhotonNetwork.CurrentRoom.Name;
			Vars.waitForPlayerJoin = false;
			((PhotonNetworkController)PhotonNetworkController.Instance).AttemptToJoinSpecificRoom("RedrumClientOnTop", (JoinType)3);
			Vars.partyTime = Time.time + 0.25f;
			Vars.phaseTwo = false;
			Vars.amountPartying = ((List<string>)typeof(FriendshipGroupDetection).GetField("myPartyMemberIDs", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(FriendshipGroupDetection.Instance)).Count - 1;
			NotifiLib.SendNotification("<color=grey>[</color><color=purple>PARTY</color><color=grey>]</color> <color=white>Kicking " + Vars.amountPartying + " party members, this may take a second...</color>");
		}
		else
		{
			NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not in a party!</color>");
		}
	}

	public static async void TapAllBells()
	{
		if (Vars.rightGrab && Time.time > stupiddelay)
		{
			TappableBell[] bells = Main.GetBells();
			foreach (TappableBell stupid in bells)
			{
				((Tappable)stupid).OnTap(1f, Time.time);
				Main.RPCProtection();
			}
			stupiddelay = Time.time + 0.1f;
		}
	}

	public static async void ChangeButtonSound()
	{
		int[] sounds = new int[11]
		{
			8, 66, 67, 84, 66, 66, 66, 66, 66, 66,
			66
		};
		string[] buttonSoundNames = new string[11]
		{
			"Wood", "Keyboard", "Default", "Bubble", "Steal", "Anthrax", "Lever", "Minecraft", "Rec Room", "Watch",
			"Membrane"
		};
		Vars.buttonClickIndex++;
		if (Vars.buttonClickIndex > buttonSoundNames.Length - 1)
		{
			Vars.buttonClickIndex = 0;
		}
		Vars.buttonClickSound = sounds[Vars.buttonClickIndex];
		Main.GetIndex("ChangeButtonSound").overlapText = "Change Button Sound <color=grey>[</color><color=green>" + buttonSoundNames[Vars.buttonClickIndex] + "</color><color=grey>]</color>";
	}

	public static async void ChangeFontType()
	{
		Vars.fontCycle++;
		if (Vars.fontCycle > 7)
		{
			Vars.fontCycle = 0;
		}
		switch (Vars.fontCycle)
		{
		case 0:
			Vars.activeFont = Vars.agency;
			break;
		case 1:
			Vars.activeFont = Vars.Arial;
			break;
		case 2:
			Vars.activeFont = Vars.Verdana;
			break;
		case 3:
			if ((Object)(object)Vars.gtagfont == (Object)null)
			{
				GameObject fart = Main.LoadAsset("gtag");
				Vars.gtagfont = ((Component)fart.transform.Find("text")).gameObject.GetComponent<Text>().font;
				Object.Destroy((Object)(object)fart);
			}
			Vars.activeFont = Vars.gtagfont;
			break;
		case 4:
			Vars.activeFont = Vars.sans;
			break;
		case 5:
			Vars.activeFont = Vars.consolas;
			break;
		case 6:
			Vars.activeFont = Vars.ubuntu;
			break;
		case 7:
			Vars.activeFont = Vars.MSGOTHIC;
			break;
		}
	}

	public static async void TapAllCrystals()
	{
		if (Vars.rightGrab && Time.time > stupiddelay)
		{
			GorillaCaveCrystal[] crystals = Main.GetCrystals();
			foreach (GorillaCaveCrystal stupid in crystals)
			{
				((Tappable)stupid).OnTap(1f, Time.time);
				Main.RPCProtection();
			}
			stupiddelay = Time.time + 0.1f;
		}
	}

	public static async void ActivateAllDoors()
	{
		if (Vars.rightGrab && Time.time > stupiddelay)
		{
			GhostLabButton[] labButtons = Main.GetLabButtons();
			foreach (GhostLabButton stupid in labButtons)
			{
				((GorillaPressableButton)stupid).ButtonActivation();
				Main.RPCProtection();
			}
			stupiddelay = Time.time + 0.1f;
		}
	}

	public static async void FreezeGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Vars.isCopying && (Object)(object)Vars.whoCopy != (Object)null)
			{
				if (!PhotonNetwork.IsMasterClient)
				{
					if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
					{
						SetMatster();
					}
				}
				else
				{
					float monsDist = 0.09f;
					Vector3 anchor = ((Component)Vars.whoCopy).transform.position;
					Vector3[] lol = (Vector3[])(object)new Vector3[4]
					{
						anchor + ((Component)GorillaTagger.Instance.offlineVRRig).transform.forward * monsDist,
						anchor - ((Component)GorillaTagger.Instance.offlineVRRig).transform.forward * monsDist,
						anchor + ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * monsDist,
						anchor - ((Component)GorillaTagger.Instance.offlineVRRig).transform.right * monsDist
					};
					int i = 0;
					MonkeyeAI[] monsters = Main.GetMonsters();
					foreach (MonkeyeAI monkeyeAI in monsters)
					{
						if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
						{
							i++;
							((Component)monkeyeAI).gameObject.transform.position = lol[i];
						}
						else
						{
							((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
						}
					}
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Vars.isCopying = true;
					Vars.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Vars.isCopying)
		{
			Vars.isCopying = false;
		}
	}

	public static async void FloatGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Vars.isCopying && (Object)(object)Vars.whoCopy != (Object)null)
			{
				if (!PhotonNetwork.IsMasterClient)
				{
					if (!Main.GetIndex("Disable Auto Anti Ban").enabled)
					{
						SetMatster();
					}
				}
				else
				{
					float monsDist = 0.065f;
					Vector3 anchor = ((Component)Vars.whoCopy).transform.position + new Vector3(0f, -0.375f, 0f);
					Vector3[] lol = (Vector3[])(object)new Vector3[4]
					{
						anchor + new Vector3(0f, 0f, monsDist),
						anchor - new Vector3(0f, 0f, monsDist),
						anchor + new Vector3(monsDist, 0f, 0f),
						anchor - new Vector3(monsDist, 0f, 0f)
					};
					int i = 0;
					MonkeyeAI[] monsters = Main.GetMonsters();
					foreach (MonkeyeAI monkeyeAI in monsters)
					{
						if (((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
						{
							i++;
							((Component)monkeyeAI).gameObject.transform.position = lol[i];
							monkeyeAI.SetState((EStates)5);
						}
						else
						{
							((Component)monkeyeAI).gameObject.GetComponent<PhotonView>().RequestOwnership();
						}
					}
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
				{
					Vars.isCopying = true;
					Vars.whoCopy = possibly;
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Vars.isCopying)
		{
			Vars.isCopying = false;
		}
	}

	public static async void cosmeticss()
	{
		foreach (CosmeticItem item in ((CosmeticsController)CosmeticsController.instance).allCosmetics)
		{
			if (item.itemName == "LBAFV.")
			{
				((CosmeticsController)CosmeticsController.instance).itemToBuy = item;
			}
			((CosmeticsController)CosmeticsController.instance).PurchaseItem();
			if (item.itemName == "LBAAK.")
			{
				((CosmeticsController)CosmeticsController.instance).itemToBuy = item;
			}
			((CosmeticsController)CosmeticsController.instance).PurchaseItem();
		}
	}

	public static async void CasualDistanceESP()
	{
		foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			if ((Object)(object)vrrig != (Object)(object)GorillaTagger.Instance.offlineVRRig)
			{
				_ = Color.yellow;
				Color thecolor = Color.clear;
				thecolor.a = 0.5f;
				_ = Color.white;
				Color thecolor2 = Color.white;
				thecolor2.a = 0.5f;
				GameObject go = new GameObject("Dist");
				TextMesh textMesh = go.AddComponent<TextMesh>();
				textMesh.fontSize = 28;
				textMesh.fontStyle = (FontStyle)2;
				textMesh.characterSize = 0.1f;
				textMesh.anchor = (TextAnchor)4;
				textMesh.alignment = (TextAlignment)1;
				textMesh.color = thecolor2;
				go.transform.position = ((Component)vrrig).transform.position + new Vector3(0f, -0.2f, 0f);
				textMesh.text = $"{Vector3.Distance(((Component)Camera.main).transform.position, ((Component)vrrig).transform.position):F1}m";
				GameObject bg = GameObject.CreatePrimitive((PrimitiveType)3);
				Object.Destroy((Object)(object)bg.GetComponent<Collider>());
				bg.transform.parent = go.transform;
				bg.transform.localPosition = Vector3.zero;
				Transform transform = bg.transform;
				Bounds bounds = ((Component)textMesh).GetComponent<Renderer>().bounds;
				transform.localScale = new Vector3(((Bounds)(ref bounds)).size.x + 0.2f, 0.2f, 0.01f);
				bg.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
				bg.GetComponent<Renderer>().material.color = thecolor;
				((Component)textMesh).GetComponent<Renderer>().material.renderQueue = bg.GetComponent<Renderer>().material.renderQueue + 1;
				go.transform.LookAt(((Component)Camera.main).transform.position);
				go.transform.Rotate(0f, 180f, 0f);
				Object.Destroy((Object)(object)go, Time.deltaTime);
			}
		}
	}

	public static async void HuntGamemode()
	{
		Hashtable hashtable = new Hashtable();
		((Dictionary<object, object>)(object)hashtable).Add((object)"gameMode", (object)"forestDEFAULTMODDED_MODDED_HUNTHUNT");
		PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, (Hashtable)null, (WebFlags)null);
		GorillaGameManager.instance.lastCheck = -1f;
		PhotonNetwork.CurrentRoom.LoadBalancingClient.OpSetCustomPropertiesOfRoom(hashtable, (Hashtable)null, (WebFlags)null);
	}

	public static async void InfectionGamemode()
	{
		Hashtable hashtable = new Hashtable();
		((Dictionary<object, object>)(object)hashtable).Add((object)"gameMode", (object)"forestDEFAULTMODDED_MODDED_INFECTION");
		PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, (Hashtable)null, (WebFlags)null);
		GorillaGameManager.instance.lastCheck = -1f;
		PhotonNetwork.CurrentRoom.LoadBalancingClient.OpSetCustomPropertiesOfRoom(hashtable, (Hashtable)null, (WebFlags)null);
	}

	public static async void LagAll2()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f)
		{
			if (!IsModded())
			{
				Antiban();
				return;
			}
			int num = RigManager.GetPhotonViewFromVRRig(RigManager.GetRandomVRRig(includeSelf: false)).ViewID;
			Hashtable ServerCleanDestroyEvent = new Hashtable();
			RaiseEventOptions ServerCleanOptions = new RaiseEventOptions
			{
				CachingOption = (EventCaching)6
			};
			ServerCleanDestroyEvent[(byte)0] = num;
			ServerCleanOptions.CachingOption = (EventCaching)4;
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)ServerCleanDestroyEvent, ServerCleanOptions, SendOptions.SendUnreliable);
			Main.RPCProtection();
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void BattleGamemode()
	{
		Hashtable hashtable = new Hashtable();
		((Dictionary<object, object>)(object)hashtable).Add((object)"gameMode", (object)"forestDEFAULTMODDED_MODDED_BATTLEPAINTBRAWL");
		PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, (Hashtable)null, (WebFlags)null);
		GorillaGameManager.instance.lastCheck = -1f;
		PhotonNetwork.CurrentRoom.LoadBalancingClient.OpSetCustomPropertiesOfRoom(hashtable, (Hashtable)null, (WebFlags)null);
	}

	public static async void CasualGamemode()
	{
		Hashtable hashtable = new Hashtable();
		((Dictionary<object, object>)(object)hashtable).Add((object)"gameMode", (object)"forestDEFAULTMODDED_MODDED_CASUALCASUAL");
		PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, (Hashtable)null, (WebFlags)null);
		GorillaGameManager.instance.lastCheck = -1f;
		PhotonNetwork.CurrentRoom.LoadBalancingClient.OpSetCustomPropertiesOfRoom(hashtable, (Hashtable)null, (WebFlags)null);
	}

	public static async void SetMatster()
	{
		PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
		NotifiLib.SendNotification("<color=cyan>[INFO]:</color> Master Set ENABLED and owner ship!");
	}

	public static async void CrashMethod(Player p, int actor)
	{
		for (int i = 0; i < 50; i++)
		{
			if (!(Time.time > crash))
			{
				continue;
			}
			crash1++;
			if (crash1 > 2)
			{
				crash1 = 1;
			}
			if (crash1 == 1)
			{
				_ = RigManager.GetViewFromPlayer(p).Owner;
				_ = RigManager.GetViewFromPlayer(p).Owner;
				Hashtable hashtable = new Hashtable();
				hashtable[(byte)0] = actor;
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
				PhotonNetwork.DestroyPlayerObjects(p);
				PhotonNetwork.DestroyPlayerObjects(RigManager.GetViewFromPlayer(p).Owner);
				PhotonNetwork.DestroyPlayerObjects(RigManager.GetViewFromPlayer(p).Controller);
				Object.Destroy((Object)(object)GorillaNot.instance);
				PhotonNetwork.DestroyPlayerObjects(RigManager.GetViewFromPlayer(p).ControllerActorNr);
				if (!IsModded())
				{
					return;
				}
				float red = Mathf.Cos(colorFloat * MathF.PI * 2f) * 0.5f + 0.5f;
				float green = Mathf.Sin(colorFloat * MathF.PI * 2f) * 0.5f + 0.5f;
				float blue = Mathf.Cos(colorFloat * MathF.PI * 2f + MathF.PI / 2f) * 0.5f + 0.5f;
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				if (Mathf.RoundToInt(1f / deltaTime) < 100)
				{
					GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
					GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				}
				CosmeticsController[] array = Resources.FindObjectsOfTypeAll<CosmeticsController>();
				foreach (CosmeticsController cosmeticsController in array)
				{
					cosmeticsController.currentTime = new DateTime(9999999999L);
					cosmeticsController.Awake();
				}
				((GorillaNot)GorillaNot.instance).userDecayTime = 0f;
				Main.RPCProtection();
			}
			if (crash1 == 2)
			{
				Hashtable hashtable1 = new Hashtable();
				hashtable1[(byte)0] = actor;
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable1, (RaiseEventOptions)null, SendOptions.SendReliable);
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable1, (RaiseEventOptions)null, SendOptions.SendReliable);
				PhotonNetwork.DestroyPlayerObjects(p);
				PhotonNetwork.DestroyPlayerObjects(RigManager.GetViewFromPlayer(p).Owner);
				PhotonNetwork.DestroyPlayerObjects(RigManager.GetViewFromPlayer(p).Controller);
				((GorillaNot)GorillaNot.instance).userDecayTime = 0f;
				if (!IsModded())
				{
					return;
				}
				float red = Mathf.Cos(colorFloat * MathF.PI * 2f) * 0.5f + 0.5f;
				float green = Mathf.Sin(colorFloat * MathF.PI * 2f) * 0.5f + 0.5f;
				float blue = Mathf.Cos(colorFloat * MathF.PI * 2f + MathF.PI / 2f) * 0.5f + 0.5f;
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				if (Mathf.RoundToInt(1f / deltaTime) < 100)
				{
					GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
					GorillaTagger.Instance.myVRRig.RpcSecure("InitializeNoobMaterial", (RpcTarget)0, true, new object[3] { red, green, blue });
				}
				CosmeticsController[] array2 = Resources.FindObjectsOfTypeAll<CosmeticsController>();
				foreach (CosmeticsController cosmeticsController in array2)
				{
					cosmeticsController.currentTime = new DateTime(9999999999L);
					cosmeticsController.Awake();
				}
				Main.RPCProtection();
			}
			crash = Time.time + 0f;
		}
		Main.RPCProtection();
	}

	public static async void BreakAllMovement()
	{
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		for (int i = 0; i < playerListOthers.Length; i++)
		{
			_ = playerListOthers[i];
		}
	}

	public static void NotLag(Vector3 pos, int hash)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		GorillaGameManager.instance.FindVRRigForPlayer(PhotonNetwork.LocalPlayer).RPC("PlaySlamEffects", (RpcTarget)0, new object[6]
		{
			pos,
			(object)new Vector3(0f, 0f, 0f),
			hash,
			-1,
			true,
			1f
		});
	}

	public static async void Banself()
	{
		PhotonNetwork.LocalPlayer.NickName = "KKK";
	}

	public static async void RopeCrashMethod()
	{
		foreach (KeyValuePair<int, GorillaRopeSwing> keyValuePair in Traverse.Create((object)RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>())
		{
			PhotonView photonView = ((MonoBehaviourPun)RopeSwingManager.instance).photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = (RpcTarget)0;
			photonView.RPC(text, rpcTarget, new object[5]
			{
				keyValuePair.Key,
				1,
				Vector3.zero,
				true,
				null
			});
		}
	}

	public static void SpazManemodes()
	{
		if (!PhotonNetwork.IsMasterClient || !(Time.time > crash))
		{
			return;
		}
		crash1++;
		if (crash1 > 4)
		{
			crash1 = 1;
		}
		if (crash1 == 1)
		{
			for (int i = 0; i < 2; i++)
			{
				BattleGamemode();
			}
		}
		if (crash1 == 2)
		{
			for (int j = 0; j < 2; j++)
			{
				InfectionGamemode();
			}
		}
		if (crash1 == 3)
		{
			for (int k = 0; k < 2; k++)
			{
				HuntGamemode();
			}
		}
		if (crash1 == 4)
		{
			for (int l = 0; l < 2; l++)
			{
				CasualGamemode();
			}
		}
		crash = Time.time + 0.05f;
	}

	public static async void CrashGun1()
	{
		if (IsModded())
		{
			CrashHandler();
			Nigger.GunLibData data = Nigger.ShootLock();
			if (data != null && (Object)(object)data.lockedPlayer != (Object)null && data.isLocked && (Object)(object)RigManager.GetPhotonViewFromVRRig(data.lockedPlayer) != (Object)null)
			{
				Hashtable hashtable = new Hashtable();
				hashtable[(byte)0] = RigManager.GetPlayerFromVRRig(who).ActorNumber;
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
				PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)204, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
			}
		}
	}

	public static async void CrashGun()
	{
		if (!Vars.rightGrab && !Mouse.current.rightButton.isPressed)
		{
			return;
		}
		(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
		var (Ray, _) = GunData;
		_ = GunData.NewPointer;
		if (Vars.isCopying && (Object)(object)Vars.whoCopy != (Object)null)
		{
			Player p = RigManager.GetPlayerFromRig(who);
			CrashMethod(p, p.ActorNumber);
			Main.RPCProtection();
		}
		if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
		{
			VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
			if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
			{
				Vars.isCopying = true;
				Vars.whoCopy = possibly;
			}
		}
		else if (Vars.isCopying)
		{
			Vars.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
		Ray = default(RaycastHit);
	}

	public static async void StepCrashMethod(RpcTarget who)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
		Vector3 crashPos = GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/Cosmetics Room Triggers/TryOnRoom").transform.position;
		((Component)GorillaTagger.Instance.offlineVRRig).transform.position = crashPos;
		try
		{
			((Component)GorillaTagger.Instance.myVRRig).transform.position = crashPos;
		}
		catch
		{
		}
		string[] items = new string[7] { "HEADPHONES1", "CHEFS HAT", "NECK SCARF", "FEZ", "COWBOY HAT", "SUNHAT", "BASIC BEANIE" };
		CosmeticItem flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand1Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		items = new string[5] { "PARTY HAT", "BASIC SCARF", "SWEATBAND", "BASEBALL CAP", "USHANKA" };
		flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand2Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		items = new string[5] { "BOWTIE", "TOP HAT", "FLOWER CROWN", "WHITE FEDORA", "CLOCHE" };
		flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand3Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		((CosmeticsController)CosmeticsController.instance).UpdateShoppingCart();
		GorillaTagger.Instance.offlineVRRig.inTryOnRoom = true;
		GorillaTagger.Instance.myVRRig.RPC("UpdateCosmeticsWithTryon", who, new object[2]
		{
			((CosmeticsController)CosmeticsController.instance).currentWornSet.ToDisplayNameArray(),
			((CosmeticsController)CosmeticsController.instance).tryOnSet.ToDisplayNameArray()
		});
		Main.RPCProtection();
	}

	public static async void StepCrashMethod(Player who)
	{
		((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
		Vector3 crashPos = GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/Cosmetics Room Triggers/TryOnRoom").transform.position;
		((Component)GorillaTagger.Instance.offlineVRRig).transform.position = crashPos;
		try
		{
			((Component)GorillaTagger.Instance.myVRRig).transform.position = crashPos;
		}
		catch
		{
		}
		string[] items = new string[7] { "HEADPHONES1", "CHEFS HAT", "NECK SCARF", "FEZ", "COWBOY HAT", "SUNHAT", "BASIC BEANIE" };
		CosmeticItem flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand1Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		items = new string[5] { "PARTY HAT", "BASIC SCARF", "SWEATBAND", "BASEBALL CAP", "USHANKA" };
		flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand2Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		items = new string[5] { "BOWTIE", "TOP HAT", "FLOWER CROWN", "WHITE FEDORA", "CLOCHE" };
		flowers = GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/ShoppingCenterAnchor/Stuff/Stand3Anchor/" + items[Random.Range(0, items.Length - 1)]).GetComponent<CosmeticStand>().thisCosmeticItem;
		((CosmeticsController)CosmeticsController.instance).ApplyCosmeticItemToSet(((CosmeticsController)CosmeticsController.instance).tryOnSet, flowers, false, false);
		((CosmeticsController)CosmeticsController.instance).UpdateShoppingCart();
		GorillaTagger.Instance.offlineVRRig.inTryOnRoom = true;
		GorillaTagger.Instance.myVRRig.RPC("UpdateCosmeticsWithTryon", who, new object[2]
		{
			((CosmeticsController)CosmeticsController.instance).currentWornSet.ToDisplayNameArray(),
			((CosmeticsController)CosmeticsController.instance).tryOnSet.ToDisplayNameArray()
		});
		Main.RPCProtection();
	}

	public static async void LagGun()
	{
		if (!Vars.rightGrab && !Mouse.current.rightButton.isPressed)
		{
			return;
		}
		(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
		var (Ray, _) = GunData;
		_ = GunData.NewPointer;
		if (Vars.isCopying && (Object)(object)Vars.whoCopy != (Object)null)
		{
			int num = RigManager.GetPhotonViewFromVRRig(Vars.whoCopy).ViewID;
			Hashtable ServerCleanDestroyEvent = new Hashtable();
			RaiseEventOptions ServerCleanOptions = new RaiseEventOptions
			{
				CachingOption = (EventCaching)6
			};
			ServerCleanDestroyEvent[(byte)0] = num;
			ServerCleanOptions.CachingOption = (EventCaching)4;
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)204, (object)ServerCleanDestroyEvent, ServerCleanOptions, SendOptions.SendUnreliable);
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)ServerCleanDestroyEvent, ServerCleanOptions, SendOptions.SendUnreliable);
			Main.RPCProtection();
		}
		if (Vars.rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
		{
			VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
			if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig)
			{
				Vars.isCopying = true;
				Vars.whoCopy = possibly;
			}
		}
		else if (Vars.isCopying)
		{
			Vars.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
		Ray = default(RaycastHit);
	}

	public static async void CrashHandler()
	{
		if (IsModded())
		{
			Hashtable hashtable = new Hashtable();
			hashtable[(byte)0] = RigManager.GetRandomPlayer(Object.op_Implicit((Object)(object)who)).ActorNumber;
			PhotonNetwork.DestroyPlayerObjects(crashedPlayer);
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)207, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)204, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
			PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)253, (object)hashtable, (RaiseEventOptions)null, SendOptions.SendReliable);
		}
	}

	public static async void CrashOnTouch()
	{
		if (!IsModded())
		{
			return;
		}
		Player p = RigManager.GetPlayerFromRig(who);
		CrashMethod(p, p.ActorNumber);
		foreach (VRRig rigs in ((GorillaParent)GorillaParent.instance).vrrigs)
		{
			if (rigs.isMyPlayer || rigs.isOfflineVRRig)
			{
				continue;
			}
			float rightDistance = Vector3.Distance(((Component)GorillaTagger.Instance.rightHandTransform).transform.position, ((Component)rigs).transform.position);
			float leftDistance = Vector3.Distance(((Component)GorillaTagger.Instance.leftHandTransform).transform.position, ((Component)rigs).transform.position);
			float bodyDistance = Vector3.Distance(((Component)GorillaTagger.Instance.offlineVRRig).transform.position, ((Component)rigs).transform.position);
			float rightDistanceother = Vector3.Distance(((Component)rigs.rightHandTransform).transform.position, ((Component)GorillaTagger.Instance.offlineVRRig).transform.position);
			float leftDistanceother = Vector3.Distance(((Component)rigs.leftHandTransform).transform.position, ((Component)GorillaTagger.Instance.offlineVRRig).transform.position);
			float bodyDistanceother = Vector3.Distance(((Component)rigs).transform.position, ((Component)GorillaTagger.Instance.offlineVRRig).transform.position);
			if (!((double)Time.time > (double)lagtimeout + 0.002))
			{
				continue;
			}
			lagtimeout = Time.time;
			if ((double)rightDistance <= 0.3 || (double)leftDistance <= 0.3 || (double)bodyDistance <= 0.5 || (double)rightDistanceother <= 0.3 || (double)leftDistanceother <= 0.3 || (double)bodyDistanceother <= 0.5)
			{
				if (rightDistance <= 0.3f)
				{
					GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
				}
				if (leftDistance <= 0.3f)
				{
					GorillaTagger.Instance.StartVibration(true, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
				}
				crashedPlayer = RigManager.GetPhotonViewFromVRRig(rigs).Owner;
				crashPlayerPosition = ((Component)rigs).transform.position;
			}
		}
	}

	public static async void FreezeAll()
	{
		if (!PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			return;
		}
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		foreach (Player p in playerListOthers)
		{
			MonkeyeAI[] array = Object.FindObjectsOfType<MonkeyeAI>();
			foreach (MonkeyeAI monster in array)
			{
				VRRig rig = RigManager.GetRigFromPlayer(p);
				((Component)monster).gameObject.GetComponent<PhotonView>().OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
				((Component)monster).gameObject.GetComponent<PhotonView>().ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
				monster.SetChasePlayer(rig);
				monster.SetState((EStates)5);
				monster.openFloorTime = float.MaxValue;
				monster.SetState((EStates)6);
				monster.replState.userId = p.UserId;
				monster.replState.freezePlayer = true;
				monster.replState.floorEnabled = false;
				monster.replState.timer = 10000f;
				monster.replState.attackPos = ((Component)rig).transform.position;
			}
		}
	}

	public static void DestroyMovement()
	{
		if (!PhotonNetwork.LocalPlayer.IsMasterClient)
		{
		}
	}

	public static async void CrashAll2()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			for (int i = 0; i < 10; i++)
			{
				Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
				foreach (Player p in playerListOthers)
				{
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					RopeCrashMethod();
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashHandler();
					CrashHandler();
					PhotonNetwork.CurrentRoom.Players.Clear();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashHandler();
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, p.ActorNumber);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
					CrashMethod(p, -1);
				}
			}
			Main.RPCProtection();
		}
		else
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void TagGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig && !((Object)((Renderer)possibly.mainSkin).material).name.Contains("fected"))
				{
					if (IsModded())
					{
						GorillaTagManager gorillaTagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
						if (!gorillaTagManager.currentInfected.Contains(RigManager.GetPlayerFromVRRig(possibly)))
						{
							gorillaTagManager.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(possibly));
						}
					}
					else
					{
						Main.isCopying = true;
						Main.whoCopy = possibly;
					}
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}

	public static async void CrashGun2()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			Nigger.GunLibData GunData = Nigger.Shoot();
			CrashHandler();
			if ((((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed) && (Object)(object)GunData.lockedPlayer != (Object)null && GunData.isLocked && (Object)(object)RigManager.GetPhotonViewFromVRRig(GunData.lockedPlayer) != (Object)null)
			{
				Main.isCopying = true;
				Main.whoCopy = GunData.lockedPlayer;
			}
		}
		else if (Main.isCopying)
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
			Nigger.GunCleanUp();
		}
	}

	public static async void BreakAudioAll()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f)
		{
			GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)1, new object[3] { 111, false, 999999f });
		}
	}

	public static async void MatAll()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			SetMatster();
		}
		else
		{
			if (!(Time.time > spamtagdelay))
			{
				return;
			}
			spamtagdelay = Time.time + 0.1f;
			GorillaTagManager tagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
			Player[] playerList = PhotonNetwork.PlayerList;
			foreach (Player v in playerList)
			{
				if (tagManager.currentInfected.Contains(v))
				{
					tagManager.currentInfected.Remove(v);
				}
				else
				{
					tagManager.AddInfectedPlayer(v);
				}
			}
		}
	}

	public static async void MatSelf()
	{
		if (!PhotonNetwork.IsMasterClient)
		{
			SetMatster();
		}
		else if (Time.time > spamtagdelay)
		{
			spamtagdelay = Time.time + 0.1f;
			GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
			if (tagman.currentInfected.Contains(PhotonNetwork.LocalPlayer))
			{
				tagman.currentInfected.Remove(PhotonNetwork.LocalPlayer);
			}
			else
			{
				tagman.AddInfectedPlayer(PhotonNetwork.LocalPlayer);
			}
		}
	}

	public static async void MatGun()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			(RaycastHit Ray, GameObject NewPointer) GunData = Main.GunLib();
			var (Ray, _) = GunData;
			_ = GunData.NewPointer;
			if (Main.isCopying && (Object)(object)Main.whoCopy != (Object)null)
			{
				if (!PhotonNetwork.IsMasterClient)
				{
					SetMatster();
				}
				else if (Time.time > spamtagdelay)
				{
					spamtagdelay = Time.time + 0.1f;
					GorillaTagManager tagman = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
					if (tagman.currentInfected.Contains(RigManager.GetPlayerFromVRRig(Main.whoCopy)))
					{
						tagman.currentInfected.Remove(RigManager.GetPlayerFromVRRig(Main.whoCopy));
					}
					else
					{
						tagman.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(Main.whoCopy));
					}
				}
			}
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightControllerIndexTouch > 0.5f || Mouse.current.leftButton.isPressed)
			{
				VRRig possibly = ((Component)((RaycastHit)(ref Ray)).collider).GetComponentInParent<VRRig>();
				if (Object.op_Implicit((Object)(object)possibly) && (Object)(object)possibly != (Object)(object)GorillaTagger.Instance.offlineVRRig && !((Object)((Renderer)possibly.mainSkin).material).name.Contains("fected"))
				{
					if (PhotonNetwork.LocalPlayer.IsMasterClient)
					{
						GorillaTagManager gorillaTagManager = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
						if (!gorillaTagManager.currentInfected.Contains(RigManager.GetPlayerFromVRRig(possibly)))
						{
							gorillaTagManager.AddInfectedPlayer(RigManager.GetPlayerFromVRRig(possibly));
						}
					}
					else
					{
						Main.isCopying = true;
						Main.whoCopy = possibly;
					}
				}
			}
			Ray = default(RaycastHit);
		}
		else if (Main.isCopying)
		{
			Main.isCopying = false;
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		}
	}
}
