using System.Diagnostics;
using System.IO;
using System.Reflection;
using Photon.Pun;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Mods;

internal class Saftey
{
	public static GorillaScoreBoard[] leaderBoards;

	public static async void AntiReportv2()
	{
		try
		{
			foreach (GorillaPlayerScoreboardLine line in GorillaScoreboardTotalUpdater.allScoreboardLines)
			{
				if (line.linePlayer != NetworkSystem.Instance.LocalPlayer)
				{
					continue;
				}
				Transform report = ((Component)line.reportButton).gameObject.transform;
				foreach (VRRig vrrig in ((GorillaParent)GorillaParent.instance).vrrigs)
				{
					if ((Object)(object)vrrig != (Object)(object)GorillaTagger.Instance.offlineVRRig)
					{
						float D1 = Vector3.Distance(vrrig.rightHandTransform.position, report.position);
						float D2 = Vector3.Distance(vrrig.leftHandTransform.position, report.position);
						float threshold = 0.35f;
						if (D1 < threshold || D2 < threshold)
						{
							PhotonNetwork.Disconnect();
							Main.RPCProtection();
							NotifiLib.SendNotification("<color=black>[</color><color=red>ROOM</color><color=magenta>] Player " + PhotonNetwork.LocalPlayer.NickName + "Tryed to report you</color>");
						}
					}
				}
			}
		}
		catch
		{
		}
	}

	private static void VerifyThing()
	{
		if (!Directory.Exists("BepInEx/plugins/RedRum"))
		{
			Directory.CreateDirectory("BepInEx/plugins/RedRum");
		}
		if (!Directory.Exists("BepInEx/plugins/RedRum/themes"))
		{
			Directory.CreateDirectory("BepInEx/plugins/RedRum/themes");
		}
		if (!Directory.Exists("BepInEx/plugins/RedRum/images"))
		{
			Directory.CreateDirectory("BepInEx/plugins/RedRum/images");
		}
	}

	public static async void OpenTXTFile(string name = "coolness")
	{
		VerifyThing();
		string filePath = Path.Combine(Assembly.GetExecutingAssembly().Location, "RedRum/" + name + ".txt");
		filePath = filePath.Split("BepInEx\\")[0] + "BepInEx/plugins/RedRum/" + name + ".txt";
		try
		{
			Process.Start(filePath);
		}
		catch
		{
			Debug.Log((object)("Could not open process " + filePath));
		}
	}

	public static void MakeTXTFile(string name = "coolness", string contents = "", bool shouldOpen = false)
	{
		VerifyThing();
		File.WriteAllText("BepInEx/plugins/RedRum/" + name + ".txt", contents);
		if (shouldOpen)
		{
			OpenTXTFile(name);
		}
	}
}
