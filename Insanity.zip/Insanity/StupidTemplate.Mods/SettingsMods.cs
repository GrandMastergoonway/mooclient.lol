using StupidTemplate.Menu;

namespace StupidTemplate.Mods;

internal class SettingsMods
{
	public static void EnterSettings()
	{
		Main.buttonsType = 1;
	}

	public static void Overpowered()
	{
		Main.buttonsType = 2;
	}

	public static void Movement()
	{
		Main.buttonsType = 3;
	}

	public static void Spams()
	{
		Main.buttonsType = 4;
	}

	public static void Advantages()
	{
		Main.buttonsType = 5;
	}

	public static void Environment()
	{
		Main.buttonsType = 6;
	}

	public static void EnableMenuOutline()
	{
		Main.isOutline = true;
		Main.RecreateMenu();
	}

	public static void RightHand()
	{
		Settings.rightHanded = true;
	}

	public static void LeftHand()
	{
		Settings.rightHanded = false;
	}

	public static void EnableFPSCounter()
	{
		Settings.fpsCounter = true;
	}

	public static void DisableFPSCounter()
	{
		Settings.fpsCounter = false;
	}

	public static void EnableNotifications()
	{
		Settings.disableNotifications = false;
	}

	public static void DisableNotifications()
	{
		Settings.disableNotifications = true;
	}

	public static void EnableDisconnectButton()
	{
		Settings.disconnectButton = true;
	}

	public static void DisableDisconnectButton()
	{
		Settings.disconnectButton = false;
	}
}
