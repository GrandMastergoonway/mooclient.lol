using System;
using System.Reflection;
using ExitGames.Client.Photon;
using GorillaExtensions;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using StupidTemplate.Menu;
using UnityEngine;
using UnityEngine.InputSystem;

namespace StupidTemplate.Mods;

internal class Spams
{
	internal enum ProjectileSource
	{
		Slingshot,
		LeftHand,
		RightHand
	}

	public static string[] Projectiles = new string[6] { "Snowball", "WaterBalloon", "LavaRock", "ThrowableGift", "ScienceCandy", "FishFood" };

	public static string SnowBall = "Snowball";

	public static string WaterBallon = "WaterBalloon";

	public static string LavaRock = "LavaRock";

	public static string Gift = "ThrowableGift";

	public static string Mento = "ScienceCandy";

	public static string FishFood = "FishFood";

	public static string CurrentProj = "Snowball";

	public static Color CurrentProjColor = Color.blue;

	public static float orbitSpeed = 8f;

	private static float angle;

	public static float Halo = 1f;

	public static float CurrentProjTime = 0.1f;

	public static float Spammer;

	public static float CoolIt;

	public static float CoolItTimer;

	public static float smth;

	public static float projectileDeboucne;

	public static GameObject projectileBlock;

	public static float projDebounceType = 0.1f;

	public static float projDebounce = 0f;

	public static float randa = 255f;

	public static float randb = 255f;

	public static float randc = 255f;

	private static Vector3 vector = GorillaTagger.Instance.rightHandTransform.forward * 5f;

	public static Color rgbcolor = Color.blue;

	private static Color pissColor = new Color(255f, 255f, 0f);

	private static Color cumColor = new Color(255f, 255f, 255f);

	public static int projectilecycle1 = 0;

	public static int projectilehashc1 = -820530352;

	public static int projectilecycle2 = 0;

	public static int projectilehashc2 = -820530352;

	public static int projectilecycle3 = 0;

	public static int projectilehashc3 = -820530352;

	public static int projectilecycle4 = 0;

	public static int projectilehashc4 = -820530352;

	public static bool cycle = false;

	public static GameObject erm = null;

	private static Color projcolor = Color.black;

	public static bool rainboww = false;

	public static int fuckyoucsharp = 0;

	public static int projectilehash = -820530352;

	public static int projectiletrail = 0;

	public static int projectiletrailhash = 1432124712;

	public static string[] ProjectileNames = new string[5] { "SnowballProjectile", "WaterBalloon_Throwable", "LavaRockProjectile", "BucketGiftCane", "ScienceCandyProjectile" };

	public static float balll2111;

	public static float balll435342111;

	public static float balll21191;

	private static float balll21111;

	private static int PageNum = 0;

	public static string[] fullTrailNames = new string[9] { "SlingshotProjectileTrail", "HornsSlingshotProjectileTrail_PrefabV", "CloudSlingshot_ProjectileTrailFX", "CupidArrow_ProjectileTrailFX", "IceSlingshotProjectileTrail Variant", "ElfBow_ProjectileTrail", "MoltenRockSlingshotProjectileTrail", "SpiderBowProjectileTrail Variant", "none" };

	public static string[] fullProjectileNamess = new string[6] { "Snowball", "WaterBalloon", "LavaRock", "ThrowableGift", "ScienceCandy", "FishFood" };

	public static string[] fullProjectileNames = new string[17]
	{
		"SlingshotProjectile", "SnowballProjectile", "WaterBalloonProjectile", "LavaRockProjectile", "HornsSlingshotProjectile_PrefabV", "CloudSlingshot_Projectile", "CupidArrow_Projectile", "IceSlingshotProjectile_PrefabV Variant", "ElfBow_Projectile", "MoltenRockSlingshot_Projectile",
		"SpiderBowProjectile Variant", "BucketGift_Cane_Projectile Variant", "BucketGift_Coal_Projectile Variant", "BucketGift_Roll_Projectile Variant", "BucketGift_Round_Projectile Variant", "BucketGift_Square_Projectile Variant", "ScienceCandyProjectile Variant"
	};

	public static async void LoudMicrophone()
	{
		Movement.micre = true;
		if (Movement.micre)
		{
			Recorder mic = GameObject.Find("Photon Manager").GetComponent<Recorder>();
			if (!Object.op_Implicit((Object)(object)((Component)mic).gameObject.GetComponent<MicAmplifier>()))
			{
				((Component)mic).gameObject.AddComponent<MicAmplifier>();
			}
			MicAmplifier loudman = ((Component)mic).gameObject.GetComponent<MicAmplifier>();
			loudman.AmplificationFactor = 16f;
			loudman.BoostValue = 16f;
			mic.RestartRecording(true);
		}
	}

	public static async void BassSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 68, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(68, false, 999999f);
			}
		}
	}

	public static async void MetalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 18, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(18, false, 999999f);
			}
		}
	}

	public static async void WolfSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 195, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(195, false, 999999f);
			}
		}
	}

	public static async void CatSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 236, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(236, false, 999999f);
			}
		}
	}

	public static async void TurkeySoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 83, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(83, false, 999999f);
			}
		}
	}

	public static async void FrogSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 91, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(91, false, 999999f);
			}
		}
	}

	public static async void InfShinyRocks()
	{
		((CosmeticsController)CosmeticsController.instance).numShinyRocksToBuy = 9999999;
		((CosmeticsController)CosmeticsController.instance).numShinyRocksToBuy = 9999999;
		((CosmeticsController)CosmeticsController.instance).currencyBalance = 9999999;
	}

	public static async void BeeSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 191, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(191, false, 999999f);
			}
		}
	}

	public static async void EarrapeSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 215, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(215, false, 999999f);
			}
		}
	}

	public static async void DingSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 244, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(244, false, 999999f);
			}
		}
	}

	public static async void CrystalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			int[] sounds = new int[2]
			{
				Random.Range(40, 54),
				Random.Range(214, 221)
			};
			int soundId = sounds[Random.Range(0, 1)];
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { soundId, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(soundId, false, 999999f);
			}
			Main.RPCProtection();
		}
	}

	public static async void BigCrystalSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 213, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(213, false, 999999f);
			}
		}
	}

	public static async void PanSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 248, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(248, false, 999999f);
			}
		}
	}

	public static async void AK47SoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { 203, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(203, false, 999999f);
			}
		}
	}

	public static async void SqueakSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3]
				{
					75 + Time.frameCount % 2,
					false,
					999999f
				});
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(75 + Time.frameCount % 2, false, 999999f);
			}
		}
	}

	public static async void RandomSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			int soundId = Random.Range(0, 259);
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3] { soundId, false, 999999f });
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(soundId, false, 999999f);
			}
		}
	}

	public static async void SirenSoundSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", (RpcTarget)0, new object[3]
				{
					48 + Time.frameCount / 15 % 2 * 2,
					false,
					999999f
				});
				Main.RPCProtection();
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(48 + Time.frameCount / 15 % 2 * 2, false, 999999f);
			}
		}
	}

	public static void FireballSpam()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Expected O, but got Unknown
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").GetComponent<SnowballThrowable>();
			if (Time.time > projDebounce)
			{
				projDebounce = Time.time + projDebounceType;
				Vector3 position = GorillaTagger.Instance.rightHandTransform.position;
				Vector3 val = GorillaTagger.Instance.rightHandTransform.forward * 16f;
				typeof(SnowballThrowable).GetMethod("LaunchProjectile", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(component, new object[3]
				{
					position,
					GorillaTagger.Instance.rightHandTransform,
					val
				});
				FieldInfo field = typeof(SnowballThrowable).GetField("gLaunchRPC", BindingFlags.Static | BindingFlags.NonPublic);
				PhotonEvent val2 = (PhotonEvent)field.GetValue(component);
				val2.RaiseOthers(new object[4]
				{
					-675036877,
					position,
					GorillaTagger.Instance.rightHandTransform,
					val
				});
			}
		}
	}

	public static async void SendProjectile(string projName, Vector3 position, Vector3 velocity, Color color)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerGripFloat = 2f;
		GameObject gameObject = GameObject.CreatePrimitive((PrimitiveType)3);
		Object.Destroy((Object)(object)gameObject, 0.1f);
		gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
		gameObject.transform.position = GorillaTagger.Instance.leftHandTransform.position;
		gameObject.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
		gameObject.GetComponent<SlingshotProjectile>().Launch(GorillaTagger.Instance.offlineVRRig.rightHandTransform.position + new Vector3(0f, 0.1f, 0f), new Vector3(0f, 1f, 0f), PhotonNetwork.LocalPlayer, true, false, 0, 1f, true, Color32.op_Implicit(Color.black));
		((Object)gameObject.gameObject).name = "SnowballProjectile";
		gameObject.GetComponent<Renderer>().enabled = false;
		if (Time.time > CurrentProjTime)
		{
			try
			{
				SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").GetComponent<SnowballThrowable>();
				component.projectilePrefab.GetComponent<SlingshotProjectile>().lifeTime = 0.1f;
				component.linSpeedMultiplier = 0.1f;
				component.maxLinSpeed = 0.1f;
				component.maxWristSpeed = 0.1f;
				((Component)component).GetComponent<SlingshotProjectile>().Launch(GorillaTagger.Instance.offlineVRRig.rightHandTransform.position + new Vector3(0f, 0.1f, 0f), new Vector3(0f, 1f, 0f), PhotonNetwork.LocalPlayer, true, false, 0, 1f, true, Color32.op_Implicit(Color.black));
				GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail.tag = projName;
				component.projectilePrefab.tag = projName;
				PoolUtils.GameObjHashCode(component.projectilePrefab);
				PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
				PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
				GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").transform.position = position;
				component.randomizeColor = true;
				((Component)component).transform.position = position;
				((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = velocity;
				GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color32.op_Implicit(color));
				GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
			}
			catch
			{
			}
			if (CurrentProjTime > 0.1f)
			{
				CurrentProjTime = Time.time + CurrentProjTime;
			}
		}
	}

	public static void ProjSpammer()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom)
		{
			Spammer = Time.time;
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
			{
				SendProjectile("Snowball", GorillaTagger.Instance.offlineVRRig.rightHandTransform.position, Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false), CurrentProjColor);
				PhotonNetwork.SendAllOutgoingCommands();
				Main.RPCProtection();
			}
		}
	}

	public static async void ProjHalo()
	{
		if (Time.time > Halo + CurrentProjTime && PhotonNetwork.InRoom)
		{
			Halo = Time.time;
			if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
			{
				angle += orbitSpeed * Time.deltaTime;
				float x = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position.x + 0.7f * Mathf.Cos(angle);
				float y = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position.y + 0.7f;
				float z = ((Component)GorillaTagger.Instance.offlineVRRig).transform.position.z + 0.7f * Mathf.Sin(angle);
				Vector3 funny = new Vector3(x, y, z);
				SendProjectile("SnowballProjectile", funny, Vector3.zero, CurrentProjColor);
				PhotonNetwork.SendAllOutgoingCommands();
				Main.RPCProtection();
			}
		}
	}

	public static async void mjdnfy()
	{
		if (Time.time > Halo + CurrentProjTime && PhotonNetwork.InRoom)
		{
			ObjectPools.instance.Instantiate(-675036877).GetComponent<SlingshotProjectile>().Launch(GorillaTagger.Instance.offlineVRRig.rightHandTransform.position + new Vector3(0f, 0.1f, 0f), new Vector3(0f, -1f, 0f), PhotonNetwork.LocalPlayer, true, false, 0, 0f, true, Color32.op_Implicit(Color.black));
		}
		Halo = Time.time;
	}

	public static async void MentoSpam()
	{
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed)
		{
			LaunchSnowball(GorillaTagger.Instance.rightHandTransform.position, vector, PageNum, new Color(1f, 0f, 0f), 249, "ScienceCandyLeftAnchor/LMAIE.", floaty: true);
		}
	}

	public static async void LaunchProjV2(string trail, string projectile, Vector3 position, Vector3 speed, Color color, bool floaty)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		CoolIt = 0.1f;
		if (Time.time > CoolIt + CoolItTimer)
		{
			CoolItTimer = Time.time;
			((ControllerInputPoller)ControllerInputPoller.instance).leftControllerGripFloat = 1f;
			((ControllerInputPoller)ControllerInputPoller.instance).leftGrab = true;
			GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().isLeftGrabbing = true;
			GameObject gameObject = GameObject.CreatePrimitive((PrimitiveType)0);
			Object.Destroy((Object)(object)gameObject, 0.1f);
			gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			gameObject.transform.position = GorillaTagger.Instance.leftHandTransform.position;
			gameObject.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
			GorillaSurfaceOverride obj = gameObject.AddComponent<GorillaSurfaceOverride>();
			string tag = (((Component)((Component)GameObject.Find("Player Objects/Local VRRig/Actual Gorilla/rig/body/Slingshot Chest Snap").transform.Find("Slingshot")).gameObject.GetComponent<Slingshot>().projectilePrefab.gameObject.GetComponent<SlingshotProjectile>()).gameObject.tag = "SlingshotProjectile");
			((Component)obj).tag = tag;
			gameObject.GetComponent<Slingshot>();
			gameObject.GetComponent<Renderer>().enabled = false;
			((Renderer)gameObject.GetComponent<MeshRenderer>()).enabled = false;
			SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Slingshot Chest Snap/DropZoneAnchor/Slingshot Anchor/HIGH TECH SLINGSHOT").GetComponent<SnowballThrowable>();
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Slingshot Chest Snap/DropZoneAnchor/Slingshot Anchor/HIGH TECH SLINGSHOT").GetComponent<Slingshot>();
			component.projectilePrefab.GetComponent<SlingshotProjectile>().lifeTime = 0.1f;
			component.linSpeedMultiplier = 0.1f;
			component.maxLinSpeed = 0.1f;
			component.maxWristSpeed = 0.1f;
			GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail.tag = trail;
			component.projectilePrefab.tag = projectile;
			PoolUtils.GameObjHashCode(component.projectilePrefab);
			PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").transform.position = position;
			component.randomizeColor = false;
			((Component)component).transform.position = position;
			((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = speed;
			GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color32.op_Implicit(color));
			GorillaTagger.Instance.offlineVRRig.RightThrowableProjectileIndex = -1;
			GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
		}
	}

	public static async void projectile(string projectile, bool rainbow, float red = 255f, float green = 255f, float blue = 255f)
	{
		Vector3 velocity = new Vector3(0f, 0f, 0f);
		new Vector3(0f, 0f, 0f);
		if (Vars.leftGrab)
		{
			if (Vars.leftTrigger > 0.5f)
			{
				velocity = GorillaTagger.Instance.leftHandTransform.forward * 25f;
			}
			else
			{
				new Vector3(0f, 0f, 0f);
			}
			float r = red;
			float g = green;
			float b = blue;
			if (rainbow)
			{
				r = Random.RandomRange(0, 255);
				g = Random.RandomRange(0, 255);
				b = Random.RandomRange(0, 255);
			}
			Vector3 position = GorillaTagger.Instance.leftHandTransform.position;
			SysFireProjectile(projectile, null, position, velocity, r, g, b, bluet: true, oranget: true);
		}
		if (!Vars.rightGrab)
		{
			return;
		}
		if (Vars.rightTrigger > 0.5f)
		{
			if (Vars.rightTrigger > 0.5f)
			{
				_ = GorillaTagger.Instance.rightHandTransform.forward * 25f;
			}
			else
			{
				new Vector3(0f, 0f, 0f);
			}
		}
		float r2 = Random.RandomRange(0, 255);
		float g2 = Random.RandomRange(0, 255);
		float b2 = Random.RandomRange(0, 255);
		Vector3 position2 = GorillaTagger.Instance.rightHandTransform.position;
		SysFireProjectile(projectile, null, position2, velocity, r2, g2, b2, bluet: true, oranget: true);
	}

	public static void CupidSpam()
	{
		projectile("CupidBow_Projectile", rainbow: true);
	}

	public static void groundprojgun()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		if (PhotonNetwork.CurrentRoom.IsVisible && smth < Time.time)
		{
			smth = Time.time + 0.1f;
			if (!PhotonNetwork.CurrentRoom.IsVisible || PhotonNetwork.CurrentRoom == null)
			{
				GameObject val = ObjectPools.instance.Instantiate(((Component)GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/SnowballRightAnchor").transform.Find("LMACF.")).GetComponent<SnowballThrowable>().projectilePrefab);
				float x = val.transform.lossyScale.x;
				GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)0, new object[12]
				{
					GorillaTagger.Instance.rightHandTransform.position,
					GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 100f,
					PoolUtils.GameObjHashCode(val),
					-1,
					false,
					1,
					false,
					0f,
					0f,
					0f,
					1f,
					null
				});
				Main.RPCProtection();
			}
		}
	}

	public static async void BetaFireProjectile(string projectileName, Vector3 position, Vector3 velocity, Color color, bool noDelay = false)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		((ControllerInputPoller)ControllerInputPoller.instance).leftControllerGripFloat = 1f;
		GameObject lhelp = GameObject.CreatePrimitive((PrimitiveType)3);
		Object.Destroy((Object)(object)lhelp, 0.1f);
		lhelp.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
		lhelp.transform.position = GorillaTagger.Instance.leftHandTransform.position;
		lhelp.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
		_ = new int[6] { 32, 204, 231, 240, 249, 252 };
		lhelp.AddComponent<GorillaSurfaceOverride>().overrideIndex = 32;
		lhelp.GetComponent<Renderer>().enabled = false;
		if (Time.time > projDebounce)
		{
			try
			{
				Vector3 oldVel = ((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity;
				string[] name2 = new string[6] { "LMACE.", "LMAEX.", "LMAGD.", "LMAHQ.", "LMAIE.", "LMAIO." };
				SnowballThrowable fart = ((Component)GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/" + fullProjectileNames[Array.IndexOf(fullProjectileNames, projectileName)] + "LeftAnchor").transform.Find(name2[Array.IndexOf(fullProjectileNames, projectileName)])).GetComponent<SnowballThrowable>();
				Vector3 oldPos = ((Component)fart).transform.position;
				fart.randomizeColor = true;
				((Component)fart).transform.position = position;
				((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = velocity;
				GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color32.op_Implicit(color));
				GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
				SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").GetComponent<SnowballThrowable>();
				component.projectilePrefab.GetComponent<SlingshotProjectile>().lifeTime = 0.1f;
				component.linSpeedMultiplier = 0.1f;
				component.maxLinSpeed = 0.1f;
				component.maxWristSpeed = 0.1f;
				component.projectilePrefab.tag = projectileName;
				PoolUtils.GameObjHashCode(component.projectilePrefab);
				PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
				PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
				GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/SnowballLeftAnchor/LMACE.").transform.position = position;
				component.randomizeColor = true;
				((Component)component).transform.position = position;
				((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = velocity;
				GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color32.op_Implicit(color));
				GorillaTagger.Instance.offlineVRRig.RightThrowableProjectileIndex = -1;
				GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
				Main.RPCProtection();
				((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = oldVel;
				((Component)fart).transform.position = oldPos;
				fart.randomizeColor = false;
			}
			catch
			{
			}
			if (projDebounceType > 0f && !noDelay)
			{
				projDebounce = Time.time + projDebounceType;
			}
		}
	}

	public static void waterballoonspam()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).leftControllerIndexTouch > 0.5f)
		{
			Vector3 position = GorillaTagger.Instance.rightHandTransform.position;
			Vector3 zero = Vector3.zero;
			float num = (float)Time.frameCount / 180f % 1f;
			Color val = Color.HSVToRGB(num, 1f, 1f);
			randa = val.r * 255f;
			randb = val.g * 255f;
			randc = val.b * 255f;
			SysFireProjectile("WaterBalloon", "Laser", position, zero, randa / 255f, randb / 255f, randc / 255f, bluet: true, oranget: false);
		}
	}

	public static void ProjectileSpammer()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Expected O, but got Unknown
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab && PhotonNetwork.InRoom)
		{
			object[] array = new object[11];
			array[0] = ((Component)GorillaTagger.Instance.offlineVRRig).gameObject.transform.position;
			array[1] = ((Component)GorillaTagger.Instance.offlineVRRig).gameObject.transform.up;
			array[2] = (object)(SlingshotActions)0;
			array[3] = (object)(SlingshotActions)1;
			array[4] = "CloudSlingshot_Projectile";
			array[5] = ProjectileSource.RightHand;
			array[6] = 1;
			array[7] = true;
			array[8] = 255f;
			array[9] = 255f;
			array[10] = 255f;
			array[11] = 255f;
			byte b = 0;
			object obj = array;
			object[] array2 = new object[3]
			{
				PhotonNetwork.ServerTimestamp,
				(byte)1,
				array
			};
			try
			{
				PhotonNetwork.RaiseEvent((byte)3, (object)array, new RaiseEventOptions
				{
					Receivers = (ReceiverGroup)1
				}, SendOptions.SendUnreliable);
			}
			catch
			{
			}
			if (projDebounceType > 0f)
			{
				projDebounce = Time.time + projDebounceType;
			}
		}
	}

	public static void SendProjEvent(in byte code, in object evData, in RaiseEventOptions reo, in SendOptions so)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		PhotonNetwork.RaiseEvent((byte)3, (object)new object[3]
		{
			PhotonNetwork.ServerTimestamp,
			code,
			evData
		}, reo, so);
	}

	public static async void SysFireProjectile(string projectilename, string trailname, Vector3 position, Vector3 velocity, float r, float g, float b, bool bluet, bool oranget, bool noDelay = false)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		BetaFireProjectile(projectilename, position, velocity, new Color(r, g, b, 1f), noDelay);
	}

	public static void Snowballspamer()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 0f, 0f, 0f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, true, num2, 1f, true, Color32.op_Implicit(new Color(4f, 0f, 1f, 6f)));
		}
	}

	public static void WaterBallonspamer()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 0f, 0f, 0f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, true, num2, 1f, true, Color32.op_Implicit(new Color(4f, 0f, 1f, 6f)));
		}
	}

	public static void ElfBowspamer()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBowProjectile_Projectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 0f, 0f, 0f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, true, num2, 1f, true, Color32.op_Implicit(new Color(4f, 0f, 1f, 6f)));
		}
	}

	public static void ProcessCaneMinigun()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Cane_Projectile Variant(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 1f, 1f, 1f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, false, num2, 1f, false, Color32.op_Implicit(default(Color)));
		}
	}

	public static void ProcessSnowMinigun()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 1f, 1f, 1f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, false, num2, 1f, false, Color32.op_Implicit(default(Color)));
		}
	}

	public static void ProcessWaterMinigun()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 1f, 1f, 1f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, false, num2, 1f, false, Color32.op_Implicit(default(Color)));
		}
	}

	public static void ProcessElfMinigun()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab)
		{
			GameObject val = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBowProjectile_Projectile(Clone)");
			GameObject val2 = ObjectPools.instance.Instantiate(val);
			int num = PoolUtils.GameObjHashCode(val2);
			SlingshotProjectile component = val2.GetComponent<SlingshotProjectile>();
			int num2 = PoolUtils.GameObjHashCode(GorillaTagger.Instance.offlineVRRig.slingshot.projectileTrail);
			Vector3 position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
			Vector3 val3 = -GorillaTagger.Instance.rightHandTransform.up * Time.deltaTime * 1000f;
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[11]
			{
				position, val3, num, num2, false, num2, false, 1f, 1f, 1f,
				1f
			});
			val.SetActive(true);
			component.Launch(position, val3, PhotonNetwork.LocalPlayer, true, false, num2, 1f, false, Color32.op_Implicit(default(Color)));
		}
	}

	public static void BetaFireImpact(Vector3 position, float r, float g, float b, bool noDelay = false)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Expected O, but got Unknown
		if (Time.time > projDebounce)
		{
			object[] array = new object[6] { position, r, g, b, 1f, 1 };
			object[] array2 = new object[3]
			{
				PhotonNetwork.ServerTimestamp,
				(byte)1,
				array
			};
			try
			{
				PhotonNetwork.RaiseEvent((byte)3, (object)array2, new RaiseEventOptions
				{
					Receivers = (ReceiverGroup)1
				}, SendOptions.SendUnreliable);
			}
			catch
			{
			}
			if (projDebounceType > 0f && !noDelay)
			{
				projDebounce = Time.time + projDebounceType;
			}
		}
	}

	private void AttachTrail(int trailHash, GameObject newProjectile, Vector3 location, bool blueTeam, bool orangeTeam)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = ObjectPools.instance.Instantiate(trailHash);
		SlingshotProjectileTrail component = val.GetComponent<SlingshotProjectileTrail>();
		if (GTExt.IsNull((Object)(object)component))
		{
			ObjectPools.instance.Destroy(val);
		}
		newProjectile.transform.position = location;
		component.AttachTrail(newProjectile, blueTeam, orangeTeam);
	}

	public static void ProjectileDelay()
	{
		projDebounceType += 0.1f;
		if (projDebounceType > 1.05f)
		{
			projDebounceType = 0.1f;
		}
		Main.GetIndex("Projectile Delay").overlapText = "Projectile Delay <color=grey>[</color><color=green>" + Mathf.Floor(projDebounceType * 10f) / 10f + "</color><color=grey>]</color>";
	}

	public static void MiniGun()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		vector = GorillaTagger.Instance.rightHandTransform.forward * 50f;
	}

	public static void reset()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		vector = GorillaTagger.Instance.rightHandTransform.forward * 5f;
	}

	public static void IceSpam()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			float num = (float)Time.frameCount / 180f % 1f;
			Color val = Color.HSVToRGB(num, 1f, 1f);
			randa = Mathf.Floor(val.r * 2f) / 2f * 255f * 100f;
			randb = Mathf.Floor(val.g * 2f) / 2f * 255f * 100f;
			randc = Mathf.Floor(val.b * 2f) / 2f * 255f * 100f;
			SendProjectile("IceSlingshot_Projectile", GorillaTagger.Instance.offlineVRRig.rightHandTransform.position, Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false), CurrentProjColor);
			PhotonNetwork.SendAllOutgoingCommands();
		}
	}

	public static void CupidSpam2()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "CupidBow_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
			GorillaGameManager.instance.returnPhotonView.RPC("LaunchSlingshotProjectile", (RpcTarget)1, new object[0]);
			PhotonNetwork.SendAllOutgoingCommands();
		}
	}

	public static void LeafSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "ElfBow_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
			PhotonNetwork.SendAllOutgoingCommands();
		}
	}

	public static void SlingshotSpam()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			float num = (float)Time.frameCount / 180f % 1f;
			Color val = Color.HSVToRGB(num, 1f, 1f);
			randa = Mathf.Floor(val.r * 2f) / 2f * 255f * 100f;
			randb = Mathf.Floor(val.g * 2f) / 2f * 255f * 100f;
			randc = Mathf.Floor(val.b * 2f) / 2f * 255f * 100f;
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "SlingshotProjectile", GorillaTagger.Instance.rightHandTransform.position, vector, val, floaty: true);
			PhotonNetwork.SendAllOutgoingCommands();
		}
	}

	public static async void LaunchSnowball(Vector3 position, Vector3 speed, int sbs, Color color, int projectileindex, string snowballdirectory, bool floaty)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		CoolIt = 0.12456782f;
		if (Time.time > CoolIt + CoolItTimer)
		{
			CoolItTimer = Time.time;
			((ControllerInputPoller)ControllerInputPoller.instance).leftControllerGripFloat = 1f;
			((ControllerInputPoller)ControllerInputPoller.instance).leftGrab = true;
			((Component)GorillaTagger.Instance).GetComponent<Rigidbody>().velocity = speed;
			GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().isLeftGrabbing = true;
			GameObject gameObject = GameObject.CreatePrimitive((PrimitiveType)0);
			Object.Destroy((Object)(object)gameObject, 0.1f);
			gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			gameObject.transform.position = GorillaTagger.Instance.leftHandTransform.position;
			gameObject.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
			gameObject.AddComponent<GorillaSurfaceOverride>().overrideIndex = projectileindex;
			((Renderer)gameObject.GetComponent<MeshRenderer>()).enabled = false;
			SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/" + snowballdirectory).GetComponent<SnowballThrowable>();
			component.projectilePrefab.GetComponent<SlingshotProjectile>().lifeTime = 0.2f;
			component.linSpeedMultiplier = sbs;
			component.maxLinSpeed = 0.2f;
			component.maxWristSpeed = 0.2f;
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/" + snowballdirectory).transform.position = position;
			component.randomizeColor = true;
			((Component)component).transform.position = position;
			GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color32.op_Implicit(color));
			GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
		}
	}

	public static string HashToName(int hash)
	{
		return hash switch
		{
			-820530352 => "SlingshotProjectile", 
			693334698 => "HornsSlingshotProjectile", 
			1511318966 => "CloudSlingshot_Projectile", 
			-675036877 => "SnowballProjectile", 
			825718363 => "CupidBow_Projectile", 
			-1671677000 => "IceSlingshot_Projectile", 
			1705139863 => "ElfBow_Projectile", 
			-1674517839 => "WaterBalloonProjectile", 
			-622368518 => "LavaRockProjectile", 
			-1280105888 => "MoltenSlingshot_Projectile", 
			-790645151 => "SpiderBow_Projectile", 
			2061412059 => "BucketGiftCane", 
			-1433634409 => "BucketGiftCoal", 
			-1433633837 => "BucketGiftRoll", 
			-160604350 => "BucketGiftRound", 
			-666337545 => "BucketGiftSquare", 
			488926162 => "LavaSurfaceRock", 
			-716425086 => "ScienceCandyProjectile", 
			-1405953129 => "PaperAirplaneProjectile", 
			_ => "SlingshotProjectile", 
		};
	}

	public static string TrailHashToName(int hash)
	{
		return hash switch
		{
			1432124712 => "SlingshotProjectileTrail", 
			163790326 => "HornsSlingshotProjectileTrail", 
			16948542 => "CloudSlingshot_ProjectileTrail", 
			1848916225 => "CupidBow_ProjectileTrail", 
			-1277271056 => "IceSlingshot_ProjectileTrail", 
			-67783235 => "ElfBow_ProjectileTrail", 
			_ => "SlingshotProjectileTrail", 
		};
	}

	public static void pissspam()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		if ((Time.time > balll2111 + 0.1f && PhotonNetwork.InRoom && ((ControllerInputPoller)ControllerInputPoller.instance).rightGrab) || Mouse.current.rightButton.isPressed)
		{
			balll2111 = Time.time;
			Vector3 forward = ((Component)GorillaTagger.Instance.offlineVRRig).transform.forward;
			Vector3 velocity = ((Vector3)(ref forward)).normalized * 10f;
			Color color = pissColor;
			SendProjectile("SlingshotProjectile", ((Component)GorillaTagger.Instance.offlineVRRig).transform.position - new Vector3(0f, 0.3f, 0f), velocity, color);
			PhotonNetwork.SendAllOutgoingCommands();
			RpcPatcher(GorillaTagger.Instance.offlineVRRig);
		}
	}

	public static void leafspm()
	{
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > balll2111 + 0.01f && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			int num = 1;
			if (cycle)
			{
				fuckyoucsharp++;
				if (fuckyoucsharp == 0)
				{
					num = projectilehashc1;
				}
				if (fuckyoucsharp == 1)
				{
					num = projectilehashc2;
				}
				if (fuckyoucsharp == 2)
				{
					num = projectilehashc3;
				}
				if (fuckyoucsharp == 3)
				{
					num = projectilehashc4;
				}
				if (fuckyoucsharp == 4)
				{
					fuckyoucsharp = 0;
					num = projectilehashc1;
				}
			}
			else
			{
				num = projectilehash;
			}
			Color val = projcolor;
			if (rainboww)
			{
				erm.transform.position = new Vector3(9999f, 9999f, 9999f);
				val = Color.blue;
			}
			PhotonNetwork.SendAllOutgoingCommands();
			RpcPatcher(GorillaTagger.Instance.offlineVRRig);
		}
		balll2111 = Time.time;
	}

	public static void prroj()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		GameObject.Find("Gorilla Player Networked(Clone)/rig/body/Slingshot Chest Snap/DropZoneAnchor/Slingshot Anchor/").transform.position = ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
		Transform transform = ((Component)SlingshotProjectileManager.instance).transform;
		transform.position += ((Component)GorillaTagger.Instance.rightHandTransform).transform.position;
	}

	public static void RpcPatcher(VRRig rig)
	{
		PhotonView myVRRig = GorillaTagger.Instance.myVRRig;
		CleanActorAndRPCBuffers(myVRRig);
	}

	public static void CleanActorAndRPCBuffers(PhotonView photonView)
	{
		int actorNumber = photonView.Owner.ActorNumber;
		PhotonNetwork.OpCleanActorRpcBuffer(actorNumber);
		PhotonNetwork.OpCleanRpcBuffer(photonView);
	}

	public static void CanesSpam()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchSnowball(GorillaTagger.Instance.rightHandTransform.position, vector, PageNum, rgbcolor, 240, "ThrowableGiftLeftAnchor/LMAHQ.", floaty: true);
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/ThrowableGiftLeftAnchor/LMAHQ./BucketSnowman_GiftCane_FBX").GetComponent<RandomBucketThrowable>().weightedChance = 1f;
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/ThrowableGiftLeftAnchor/LMAHQ./BucketSnowman_GiftCoal_FBX").GetComponent<RandomBucketThrowable>().weightedChance = 100f;
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/ThrowableGiftLeftAnchor/LMAHQ./BucketSnowman_GiftRoll_FBX").GetComponent<RandomBucketThrowable>().weightedChance = 100f;
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/ThrowableGiftLeftAnchor/LMAHQ./BucketSnowman_GiftRound_FBX").GetComponent<RandomBucketThrowable>().weightedChance = 100f;
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/ThrowableGiftLeftAnchor/LMAHQ./BucketSnowman_GiftSquare_FBX").GetComponent<RandomBucketThrowable>().weightedChance = 100f;
		}
	}

	public static void BalloonSpam()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchSnowball(GorillaTagger.Instance.rightHandTransform.position, vector, PageNum, new Color(1f, 0f, 0f), 204, "WaterBalloonLeftAnchor/LMAEX.", floaty: false);
		}
	}

	public static void SnowSpam()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			float num = (float)Time.frameCount / 180f % 1f;
			Color val = Color.HSVToRGB(num, 1f, 1f);
			randa = Mathf.Floor(val.r * 2f) / 2f * 255f * 100f;
			randb = Mathf.Floor(val.g * 2f) / 2f * 255f * 100f;
			randc = Mathf.Floor(val.b * 2f) / 2f * 255f * 100f;
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "SnowballProjectile", GorillaTagger.Instance.rightHandTransform.position, vector, val, floaty: true);
		}
	}

	public static void WaterSpam()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			float num = (float)Time.frameCount / 180f % 1f;
			Color val = Color.HSVToRGB(num, 1f, 1f);
			randa = Mathf.Floor(val.r * 2f) / 2f * 255f * 100f;
			randb = Mathf.Floor(val.g * 2f) / 2f * 255f * 100f;
			randc = Mathf.Floor(val.b * 2f) / 2f * 255f * 100f;
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "WaterBalloonProjectile", GorillaTagger.Instance.rightHandTransform.position, vector, val, floaty: true);
		}
	}

	public static void DevilSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "DevilBow_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void DragonArrow()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "SamuraiBow_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void DragonSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshoCloudSlingshot_ProjectileTrailFXt_ProjectileTrail", "DragonSling_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void MoltenSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "MoltenSlingshot_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void IceSpam2()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "IceSlingshot_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void ToxicSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "IceSlingshot_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void LavaSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "LavaRockProjectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void HornySpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "HornsSlingshotProjectile_PrefabV", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void GaySpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrail", "IceSlingshot_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void SpiderSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "SpiderBow_Projectile", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void CaneSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "BucketGiftCane", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void CoalSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "BucketGiftCoal", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void RollSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "BucketGiftRoll", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void RoundSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "BucketGiftRound", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void SquareSpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "BucketGiftSquare", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}

	public static void CandySpam()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > Spammer + CurrentProjTime && PhotonNetwork.InRoom && (((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || Mouse.current.rightButton.isPressed))
		{
			LaunchProjV2("CloudSlingshot_ProjectileTrailFX", "ScienceCandy", GorillaTagger.Instance.rightHandTransform.position, vector, rgbcolor, floaty: true);
		}
	}
}
