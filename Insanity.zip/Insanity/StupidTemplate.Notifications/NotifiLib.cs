using System;
using System.Linq;
using BepInEx;
using UnityEngine;
using UnityEngine.UI;

namespace StupidTemplate.Notifications;

[BepInPlugin("org.gorillatag.lars.notifications2", "NotificationLibrary", "1.0.5")]
public class NotifiLib : BaseUnityPlugin
{
	private GameObject HUDObj;

	private GameObject HUDObj2;

	private GameObject MainCamera;

	private Text Testtext;

	private Material AlertText = new Material(Shader.Find("GUI/Text Shader"));

	private int NotificationDecayTime = 144;

	private int NotificationDecayTimeCounter;

	public static int NoticationThreshold = 30;

	private string[] Notifilines;

	private string newtext;

	public static string PreviousNotifi;

	private bool HasInit;

	private static Text NotifiText;

	public static bool IsEnabled = true;

	private void Awake()
	{
		((BaseUnityPlugin)this).Logger.LogInfo((object)"Plugin NotificationLibrary is loaded!");
	}

	private void Init()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		MainCamera = GameObject.Find("Main Camera");
		HUDObj = new GameObject();
		HUDObj2 = new GameObject();
		((Object)HUDObj2).name = "NOTIFICATIONLIB_HUD_OBJ";
		((Object)HUDObj).name = "NOTIFICATIONLIB_HUD_OBJ";
		HUDObj.AddComponent<Canvas>();
		HUDObj.AddComponent<CanvasScaler>();
		HUDObj.AddComponent<GraphicRaycaster>();
		((Behaviour)HUDObj.GetComponent<Canvas>()).enabled = true;
		HUDObj.GetComponent<Canvas>().renderMode = (RenderMode)2;
		HUDObj.GetComponent<Canvas>().worldCamera = MainCamera.GetComponent<Camera>();
		HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
		((Transform)HUDObj.GetComponent<RectTransform>()).position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
		HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z - 4.6f);
		HUDObj.transform.parent = HUDObj2.transform;
		((Transform)HUDObj.GetComponent<RectTransform>()).localPosition = new Vector3(0f, 0f, 1.6f);
		Quaternion rotation = ((Transform)HUDObj.GetComponent<RectTransform>()).rotation;
		Vector3 eulerAngles = ((Quaternion)(ref rotation)).eulerAngles;
		eulerAngles.y = -270f;
		HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
		((Transform)HUDObj.GetComponent<RectTransform>()).rotation = Quaternion.Euler(eulerAngles);
		GameObject val = new GameObject();
		val.transform.parent = HUDObj.transform;
		Testtext = val.AddComponent<Text>();
		Testtext.text = "";
		Testtext.fontSize = 30;
		Testtext.font = Settings.currentFont;
		((Graphic)Testtext).rectTransform.sizeDelta = new Vector2(450f, 210f);
		Testtext.alignment = (TextAnchor)6;
		((Transform)((Graphic)Testtext).rectTransform).localScale = new Vector3(0.0033333334f, 0.0033333334f, 1f / 3f);
		((Transform)((Graphic)Testtext).rectTransform).localPosition = new Vector3(-1f, -1f, -0.5f);
		((Graphic)Testtext).material = AlertText;
		NotifiText = Testtext;
	}

	private void FixedUpdate()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (!HasInit && (Object)(object)GameObject.Find("Main Camera") != (Object)null)
		{
			Init();
			HasInit = true;
		}
		HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
		HUDObj2.transform.rotation = MainCamera.transform.rotation;
		if (Testtext.text != "")
		{
			NotificationDecayTimeCounter++;
			if (NotificationDecayTimeCounter <= NotificationDecayTime)
			{
				return;
			}
			Notifilines = null;
			newtext = "";
			NotificationDecayTimeCounter = 0;
			Notifilines = Testtext.text.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();
			string[] notifilines = Notifilines;
			foreach (string text in notifilines)
			{
				if (text != "")
				{
					newtext = newtext + text + "\n";
				}
			}
			Testtext.text = newtext;
		}
		else
		{
			NotificationDecayTimeCounter = 0;
		}
	}

	public static void SendNotification(string NotificationText)
	{
		if (Settings.disableNotifications)
		{
			return;
		}
		try
		{
			if (IsEnabled && PreviousNotifi != NotificationText)
			{
				if (!NotificationText.Contains(Environment.NewLine))
				{
					NotificationText += Environment.NewLine;
				}
				NotifiText.text += NotificationText;
				NotifiText.supportRichText = true;
				PreviousNotifi = NotificationText;
			}
		}
		catch
		{
			Debug.LogError((object)("Notification failed, object probably nil due to third person ; " + NotificationText));
		}
	}

	public static void ClearAllNotifications()
	{
		NotifiText.text = "";
	}

	public static void ClearPastNotifications(int amount)
	{
		string text = "";
		string[] array = NotifiText.text.Split(Environment.NewLine.ToCharArray()).Skip(amount).ToArray();
		foreach (string text2 in array)
		{
			if (text2 != "")
			{
				text = text + text2 + "\n";
			}
		}
		NotifiText.text = text;
	}
}
