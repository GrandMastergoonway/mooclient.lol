using System.ComponentModel;
using BepInEx;

namespace StupidTemplate.Patches;

[Description("Created by @goldentrophy with love <3")]
[BepInPlugin("org.iidk.gorillatag.menutemplate", "Insanity X", "1.0.0")]
public class HarmonyPatches : BaseUnityPlugin
{
	private void OnEnable()
	{
		Menu.ApplyHarmonyPatches();
	}

	private void OnDisable()
	{
		Menu.RemoveHarmonyPatches();
	}
}
