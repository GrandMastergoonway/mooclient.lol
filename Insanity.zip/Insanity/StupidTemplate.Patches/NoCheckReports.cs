using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(/*Could not decode attribute arguments.*/)]
public class NoCheckReports : MonoBehaviour
{
	private static bool Prefix()
	{
		return false;
	}
}
