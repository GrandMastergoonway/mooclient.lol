using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(typeof(GorillaNot), "CloseInvalidRoom")]
public class NoCloseInvalidRoom : MonoBehaviour
{
	private static bool Prefix()
	{
		return false;
	}
}
