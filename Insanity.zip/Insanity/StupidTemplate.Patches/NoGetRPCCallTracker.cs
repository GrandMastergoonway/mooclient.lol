using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(typeof(GorillaNot), "GetRPCCallTracker")]
internal class NoGetRPCCallTracker : MonoBehaviour
{
	private static bool Prefix()
	{
		return false;
	}
}
