using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(typeof(VRRig), "IncrementRPC", new Type[]
{
	typeof(PhotonMessageInfoWrapped),
	typeof(string)
})]
public class NoIncrementRPC : MonoBehaviour
{
	private static bool Prefix(PhotonMessageInfoWrapped info, string sourceCall)
	{
		return false;
	}
}
