using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(typeof(GorillaNot), "LogErrorCount")]
public class NoLogErrorCount : MonoBehaviour
{
	private static bool Prefix(string logString, string stackTrace, LogType type)
	{
		return false;
	}
}
