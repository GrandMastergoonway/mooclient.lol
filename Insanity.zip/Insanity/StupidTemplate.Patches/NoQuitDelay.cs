using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(/*Could not decode attribute arguments.*/)]
public class NoQuitDelay : MonoBehaviour
{
	private static bool Prefix()
	{
		return false;
	}
}
