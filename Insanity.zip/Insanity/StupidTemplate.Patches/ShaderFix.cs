using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches;

[HarmonyPatch(typeof(GameObject))]
[HarmonyPatch(/*Could not decode attribute arguments.*/)]
internal class ShaderFix : MonoBehaviour
{
	private static void Postfix(GameObject __result)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		__result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
		__result.GetComponent<Renderer>().material.color = Color32.op_Implicit(new Color32(byte.MaxValue, (byte)128, (byte)0, (byte)128));
	}
}
