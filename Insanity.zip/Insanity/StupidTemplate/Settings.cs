using StupidTemplate.Classes;
using StupidTemplate.Menu;
using UnityEngine;

namespace StupidTemplate;

internal class Settings
{
	public static ExtGradient backgroundColor = new ExtGradient
	{
		colors = Main.GetSolidGradient(new Color(0.753f, 0.471f, 1f))
	};

	public static ExtGradient[] buttonColors = new ExtGradient[2]
	{
		new ExtGradient
		{
			colors = Main.GetSolidGradient(Color.clear)
		},
		new ExtGradient
		{
			colors = Main.GetSolidGradient(Color.white)
		}
	};

	public static Color[] textColors = (Color[])(object)new Color[2]
	{
		Color.white,
		Color.black
	};

	public static Font currentFont;

	public static bool fpsCounter;

	public static bool disconnectButton;

	public static bool rightHanded;

	public static bool disableNotifications;

	public static float ButtonThickness;

	public static float menuWidth;

	public static float menuHeight;

	public static float PageButtonWidth;

	public static float PageButtonHeight;

	public static float horizontalOffset;

	public static float ButtonPositionHeight;

	public static float CustomVerticalPageOffset;

	public static float PageButtonCustomOffset;

	public static float MenuThickness;

	public static KeyCode keyboardButton;

	public static Vector3 menuSize;

	public static int buttonsPerPage;

	static Settings()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		Object builtinResource = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		currentFont = (Font)(object)((builtinResource is Font) ? builtinResource : null);
		fpsCounter = true;
		disconnectButton = true;
		rightHanded = false;
		disableNotifications = false;
		ButtonThickness = 0.09f;
		menuWidth = 0.78f;
		menuHeight = 0.7f;
		PageButtonWidth = 0.5f;
		PageButtonHeight = 0.1f;
		horizontalOffset = 0f;
		ButtonPositionHeight = 0.155f;
		CustomVerticalPageOffset = 0f;
		PageButtonCustomOffset = 0f;
		MenuThickness = 0.08f;
		keyboardButton = (KeyCode)113;
		menuSize = new Vector3(0.1f, 0.78f, 0.7f);
		buttonsPerPage = 5;
	}
}
