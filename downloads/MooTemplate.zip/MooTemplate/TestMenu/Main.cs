﻿using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using System.Net;
using TestMenu.Notifications;
using TestMenu.Other;
using static TestMenu.Other.Buttons;
using System.Linq;
using System.Security.Policy;
using Pathfinding;
using System.Text;

namespace TestMenu.Menu
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class ModMenu : MonoBehaviour
    {
        public static Texture2D LoadTextureFromURL(string resourcePath, string fileName) // This is used to load any image with a url! (image formats like: jpg, png etc)
        {
            Texture2D texture = new Texture2D(2, 2);
            if (!Directory.Exists("MooTemp")) // Change "MooTemp" to your menu name. (this is where it stores images for when the next time the menu loads, do it for the rest or it breaks!)
            {
                Directory.CreateDirectory("MooTemp");
            }
            if (!File.Exists("MooTemp/" + fileName))
            {
                WebClient stream = new WebClient();
                stream.DownloadFile(resourcePath, "MooTemp/" + fileName);
            }
            byte[] bytes = File.ReadAllBytes("MooTemp/" + fileName);
            texture.LoadImage(bytes);
            return texture;
        }

        public static GameObject menuObj;
        public static GameObject bg;
        public static GameObject reference;
        public static GameObject canvasObj;
        public static SphereCollider buttonCollider;
        public static Font menuFont = Font.CreateDynamicFontFromOSFont("Roboto", 16);
        public static int pageNumber = 0;
        public static int buttonsType = 0;
        public static bool readmefile = true;
        public static void Prefix()
        {
            try
            {
                bool toOpen = ControllerInputPoller.instance.leftControllerSecondaryButton;

                if (menuObj == null)
                {
                    if (toOpen)
                    {
                        DrawMenu();
                        RecenterMenu();
                        if (reference == null)
                        {
                            CreateReference();
                        }
                    }
                }
                else
                {
                    if (toOpen)
                    {
                        RecenterMenu();
                    }
                    else
                    {
                        Vector3 velocity = GorillaLocomotion.Player.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                        Vector3 randomSpin = new Vector3(
                            UnityEngine.Random.Range(-1f, 1f),
                            UnityEngine.Random.Range(-1f, 1f),
                            UnityEngine.Random.Range(-1f, 1f)
                        ).normalized * 175f;
                        Rigidbody rigidMenu = menuObj.AddComponent<Rigidbody>();
                        rigidMenu.mass = 1f;
                        rigidMenu.drag = 0.1f;
                        rigidMenu.angularDrag = 0.05f;
                        rigidMenu.useGravity = true;
                        rigidMenu.velocity = velocity;
                        rigidMenu.AddTorque(UnityEngine.Random.insideUnitSphere * 275f);
                        rigidMenu.AddTorque(randomSpin);
                        UnityEngine.Object.Destroy(menuObj, 3f);
                        UnityEngine.Object.Destroy(reference);
                        reference = null;
                        menuObj = null;

                    }
                }
            }
            catch { /* balls */ }

            try
            {
                foreach (InfoButtons[] buttonlist in buttons)
                {
                    foreach (InfoButtons v in buttonlist)
                    {
                        if (v.enabled)
                        {
                            if (v.method != null)
                            {
                                try { v.method.Invoke(); } catch { /* balls */ } // took me long to figure out that it needs a "try" or else the whole shit breaks :sob:
                            }
                        }
                    }
                }
            }
            catch { /* balls */ }

            if (readmefile == true)
            {
                readmefile = false;

                if (!Directory.Exists("MooTemp")) // Change this to the same name as above or it breaks!
                {
                    Directory.CreateDirectory("MooTemp");
                }
                using (FileStream fs = File.Create(System.IO.Path.Combine("MooTemp/", "readme.txt")))
                {
                    string text = "Thanks for using the template"; // Change this to what ever you like.

                    byte[] info = new UTF8Encoding(true).GetBytes(text);
                    fs.Write(info, 0, info.Length);
                }
            }
        }

        public static void DrawMenu()
        {
            menuObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuObj.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuObj.GetComponent<Collider>());
            UnityEngine.Object.Destroy(menuObj.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menuObj.GetComponent<Renderer>());
            menuObj.transform.localScale = new Vector3(0.1f, 0.3f, 0.4f);

            string LoadURLFromFile(string path)
            {
                try { return File.ReadAllText(path).Trim(); } catch { return null; }
            }
            string url = LoadURLFromFile("MooClient/bgmenuurl.txt");

            GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
            bg.transform.parent = menuObj.transform;
            bg.transform.rotation = Quaternion.identity;
            bg.transform.localScale = new Vector3(0.1f, 1f, 0.9f);
            bg.transform.position = new Vector3(0.05f, 0f, 0f);
            Renderer bgmenu = bg.GetComponent<Renderer>();
            bgmenu.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
            bgmenu.material.shader = Shader.Find("Universal Render Pipeline/Lit");
            if (!string.IsNullOrEmpty(url))
            {
                bgmenu.material.mainTexture = LoadTextureFromURL(url, "customimage.jpg");
            }
            else
            {
                bgmenu.material.mainTexture = LoadTextureFromURL("https://c4.wallpaperflare.com/wallpaper/280/619/719/light-stains-faded-dull-wallpaper-preview.jpg", "menubg.jpg"); // Change the url to any image url
            }
            UnityEngine.Object.Destroy(bg.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(bg.GetComponent<Collider>());

            canvasObj = new GameObject();
            canvasObj.transform.parent = menuObj.transform;
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScale = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScale.dynamicPixelsPerUnit = 1000f;

            GameObject disconnectbutton = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(disconnectbutton.GetComponent<Rigidbody>());
            disconnectbutton.GetComponent<BoxCollider>().isTrigger = true;
            disconnectbutton.transform.parent = menuObj.transform;
            disconnectbutton.transform.rotation = Quaternion.identity;
            disconnectbutton.transform.localScale = new Vector3(0.09f, 0.50f, 0.10f);
            disconnectbutton.transform.localPosition = new Vector3(0.50f, 0f, -0.53f);
            disconnectbutton.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
            disconnectbutton.AddComponent<ButtonCollision>().btnIdentifier = "Disconnect";

            UnityEngine.UI.Text discontext = new GameObject
            {
                transform =
                            {
                                parent = canvasObj.transform
                            }
            }.AddComponent<UnityEngine.UI.Text>();
            discontext.text = "Leave";
            discontext.font = menuFont;
            discontext.fontSize = 1;
            discontext.alignment = TextAnchor.MiddleCenter;
            discontext.resizeTextForBestFit = true;
            discontext.resizeTextMinSize = 0;

            RectTransform rectt = discontext.GetComponent<RectTransform>();
            rectt.localPosition = Vector3.zero;
            rectt.sizeDelta = new Vector2(0.2f, 0.03f);
            rectt.localPosition = new Vector3(0.056f, 0f, -0.21f);
            rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menuObj.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.2f, 0.10f);
            gameObject.transform.localPosition = new Vector3(0.50f, 0.40f, -0.53f);
            gameObject.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
            gameObject.AddComponent<ButtonCollision>().btnIdentifier = "PreviousPage";

            UnityEngine.UI.Text textback = new GameObject
            {
                transform =
                        {
                            parent = canvasObj.transform
                        }
            }.AddComponent<UnityEngine.UI.Text>();
            textback.font = menuFont;
            textback.text = "◄";
            textback.fontSize = 1;
            textback.alignment = TextAnchor.MiddleCenter;
            textback.resizeTextForBestFit = true;
            textback.resizeTextMinSize = 0;
            RectTransform backrect = textback.GetComponent<RectTransform>();
            backrect.localPosition = Vector3.zero;
            backrect.sizeDelta = new Vector2(0.2f, 0.03f);
            backrect.localPosition = new Vector3(0.056f, 0.120f, -0.21f);
            backrect.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menuObj.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.2f, 0.10f);
            gameObject.transform.localPosition = new Vector3(0.50f, -0.40f, -0.53f);
            gameObject.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
            gameObject.AddComponent<ButtonCollision>().btnIdentifier = "NextPage";

            UnityEngine.UI.Text textnext = new GameObject
            {
                transform =
                        {
                            parent = canvasObj.transform
                        }
            }.AddComponent<UnityEngine.UI.Text>();
            textnext.font = menuFont;
            textnext.text = "►";
            textnext.fontSize = 1;
            textnext.alignment = TextAnchor.MiddleCenter;
            textnext.resizeTextForBestFit = true;
            textnext.resizeTextMinSize = 0;
            RectTransform nextrect = textnext.GetComponent<RectTransform>();
            nextrect.localPosition = Vector3.zero;
            nextrect.sizeDelta = new Vector2(0.2f, 0.03f);
            nextrect.localPosition = new Vector3(0.056f, -0.120f, -0.21f);
            nextrect.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            // Back of Menu Text
            UnityEngine.UI.Text text = new GameObject
            {
                transform =
                {
                    parent = canvasObj.transform
                }
            }.AddComponent<UnityEngine.UI.Text>();
            text.font = menuFont;
            text.text = "Hello There :)"; // This is the test on the back of the menu, change this to whatever you like!
            text.fontSize = 1;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.2f);
            component.position = new Vector3(0.04f, 0f, 0);
            component.rotation = Quaternion.Euler(new Vector3(0f, 90f, 90f));
            // Back of Menu Text

            Texture2D texture = LoadTextureFromURL("https://i.ibb.co/mFDXkRB/Untitled-9.png", "menulogo.png"); // This is for the logo on top of the menu, make sure to change this!
            GameObject imageObject2 = new GameObject { transform = { parent = canvasObj.transform, localPosition = Vector3.zero } };
            RawImage rawImage = imageObject2.AddComponent<RawImage>();
            rawImage.texture = texture;
            RectTransform rectTransform = imageObject2.GetComponent<RectTransform>();
            rectTransform.sizeDelta = new Vector2(0.3f, 0.20f);
            rectTransform.position = new Vector3(.06f, 0, 0.29f);
            rectTransform.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            InfoButtons[] activeButtons = Buttons.buttons[buttonsType].Skip(pageNumber * InfoButtons.buttonsPage).Take(InfoButtons.buttonsPage).ToArray();
            for (int i = 0; i < activeButtons.Length; i++)
            {
                AddButton(i * 0.1f, activeButtons[i]);
            }
        }

        public static void ResetMenu()
        {
            if (menuObj != null)
            {
                UnityEngine.Object.Destroy(menuObj);
                menuObj = null;
                DrawMenu();
            }
        }

        public static void Toggle(string buttonText)
        {
            int lastPage = ((Buttons.buttons[buttonsType].Length + InfoButtons.buttonsPage - 1) / InfoButtons.buttonsPage) - 1;
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    InfoButtons target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { /* balls */ }
                                }
                            }
                            else
                            {
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { /* balls */ }
                                }
                            }
                        }
                        else
                        {
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { /* balls */ }
                            }
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError(buttonText + " does not exist");
                    }
                }
            }
            ResetMenu();
        }

        public static InfoButtons GetIndex(string buttonText)
        {
            foreach (InfoButtons[] buttons in Buttons.buttons)
            {
                foreach (InfoButtons button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }
            return null;
        }

        public static void AddButton(float offset, InfoButtons method)
        {
            GameObject newButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(newButton.GetComponent<Rigidbody>());
            newButton.transform.parent = menuObj.transform;
            newButton.transform.rotation = Quaternion.identity;
            newButton.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
            newButton.transform.localPosition = new Vector3(0.56f, 0f, 0.350f - offset);
            newButton.GetComponent<BoxCollider>().isTrigger = true;
            newButton.AddComponent<ButtonCollision>().btnIdentifier = method.buttonText;

            UnityEngine.UI.Text text3 = new GameObject
            {
                transform =
                {
                    parent = canvasObj.transform
                }
            }.AddComponent<UnityEngine.UI.Text>();
            text3.font = menuFont;
            text3.text = method.buttonText;
            if (method.overlapText != null)
            {
                text3.text = method.overlapText;
            }
            text3.supportRichText = true;
            text3.fontSize = 1;
            if (method.enabled) // This is for the button colors, change this to what you like.
            {
                newButton.GetComponent<Renderer>().material.color = Color.green; // Enabled
            }
            else
            {
                newButton.GetComponent<Renderer>().material.color = new Color32(0, 100, 220, 255); // Disabled
            }
            text3.alignment = TextAnchor.MiddleCenter;
            text3.resizeTextForBestFit = true;
            text3.resizeTextMinSize = 0;
            RectTransform component = text3.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(.2f, .03f);
            component.position = new Vector3(.064f, 0, .140f - (offset / 2.55f));
            component.rotation = Quaternion.Euler(new Vector3(180, 90, 90));
        }

        public static void CreateReference()
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            reference.GetComponent<Renderer>().material.color = Color.cyan;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();
        }

        public static void RecenterMenu()
        {
            menuObj.transform.position = GorillaTagger.Instance.leftHandTransform.position;
            menuObj.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
        }
    }

    class ButtonCollision : MonoBehaviour
    {
        public string btnIdentifier;
        public static float buttonCooldown = 0f;

        private void OnTriggerEnter(Collider collider)
        {
            if (Time.time > buttonCooldown && collider == TestMenu.Menu.ModMenu.buttonCollider && TestMenu.Menu.ModMenu.menuObj != null)
            {
                buttonCooldown = Time.time + 0.2f;
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, false, 0.40f); // Button 
                ModMenu.Toggle(this.btnIdentifier);
            }
        }
    }
}
