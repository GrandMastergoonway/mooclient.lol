﻿namespace TestMenu.Other
{
    internal class Buttons
    {
        public static InfoButtons[][] buttons = new InfoButtons[][]
        {
            new InfoButtons[]
            {
                // This uses the same buttom system as ii Stupid Mods!
                // Change the "Joins the Discord!" to what you like, it just placeholders

                new InfoButtons { buttonText = "Settings", method =() => OtherPages.EnterSettings(), isTogglable = false, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Join Discord", method =() => Mods.JoinDiscord(), isTogglable = false, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Platforms", method =() => Mods.Platforms(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Invisible Platforms", method =() => Mods.InvisPlatforms(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Sticky Platforms", method =() => Mods.StickyPlatforms(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Placeholder", method =() => Mods.Disconnect(), isTogglable = true, toolTip = "Joins the Discord!"},
            },

            new InfoButtons[]
            {
                new InfoButtons { buttonText = "Custom Boards", method =() => Mods.MOTD(), isTogglable = false, enabled = true, toolTip = "Joins the Discord!"},
                new InfoButtons { buttonText = "Go Back", method =() => OtherPages.BackHome(), isTogglable = false, toolTip = "Joins the Discord!"},
            }
        };
    }
}
