﻿using System;

namespace TestMenu.Other
{
    public class InfoButtons
    {
        public string buttonText = "Placeholder";
        public string overlapText = null;
        public Action method = null;
        public Action enableMethod = null;
        public Action disableMethod = null;
        public bool enabled = false;
        public bool isTogglable = true;
        public string toolTip = "Error";
        public static int buttonsPage = 8;
    }
}
