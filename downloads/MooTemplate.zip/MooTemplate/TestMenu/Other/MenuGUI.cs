﻿using UnityEngine;
using BepInEx;
using UnityEngine.UI;
using System.IO;
using System.Net;
using UnityEngine.Networking;
using System.Collections;

namespace TestMenu.Other
{
    [BepInPlugin("Jeff", "GUI", "1.0.0")]
    public class MenuGUI : BaseUnityPlugin
    {
        private Texture2D logo;
        IEnumerator Start()
        {
            UnityWebRequest www = UnityWebRequestTexture.GetTexture("https://i.ibb.co/7t9MJxQ/download-2-2.png");
            yield return www.SendWebRequest();
            Texture2D texture = DownloadHandlerTexture.GetContent(www);
            logo = texture;
            byte[] bytes = texture.EncodeToPNG();
            File.WriteAllBytes("MooClient/", bytes);
            www.Dispose();
        }

        void OnGUI()
        {
            Window(0);
        }

        public void Window(int id)
        {
            Color fadedColor = GUI.color;
            fadedColor.a = 0.5f;
            GUI.color = fadedColor;
            if (logo != null)
            {
                GUI.DrawTexture(new Rect(Screen.width - logo.width - 10, Screen.height - logo.height, logo.width, logo.height), logo);
            }
            GUI.color = Color.white;
        }
    }
}
