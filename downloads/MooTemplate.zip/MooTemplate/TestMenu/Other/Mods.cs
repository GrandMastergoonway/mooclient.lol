﻿using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Linq;
using Object = UnityEngine.Object;
using ExitGames.Client.Photon;
using UnityEngine;
using System.Text;
using UnityEngine.InputSystem;
using System.Threading.Tasks;
using GorillaNetworking;
using GorillaLocomotion.Gameplay;
using GorillaExtensions;
using Steamworks;
using HarmonyLib;
using System.Reflection;
using GorillaTag;
using static UnityEngine.UI.GridLayoutGroup;
using Photon.Pun.UtilityScripts;
using System.IO;
using System.Diagnostics;
using static MonoMod.Cil.RuntimeILReferenceBag.FastDelegateInvokers;
using Oculus.Interaction.HandGrab;
using UnityEngine.AI;
using UnityEngine.Animations.Rigging;
using GorillaTagScripts;
using UnityEngine.XR.Interaction.Toolkit;
using Photon.Voice.Unity;
using System.ComponentModel;
using UnityEngine.UIElements;
using OVRSimpleJSON;
using System.Threading;
using UnityEngine.XR;
using UnityEngine.InputSystem.HID;
using System.Runtime.InteropServices;
using TMPro;
using Random = UnityEngine.Random;
using BepInEx.Configuration;
using UnityEngine.UI;
using System.Net.Sockets;
using PlayFab.ClientModels;
using PlayFab;
using System.Text.RegularExpressions;
using static GorillaNetworking.CosmeticsController;
using PlayFab.AuthenticationModels;
using PlayFab.Internal;
using UnityEngine.Windows;
using UnityEngine.Networking;
using Valve.VR;
using System.Net;
using System.Collections;
using Hashtable = ExitGames.Client.Photon.Hashtable;
using UnityEngine.SocialPlatforms;
using Photon.Voice;
using Cinemachine;
using Cinemachine.Utility;
using POpusCodec.Enums;
using Meta.WitAi;
using UnityEngine.Video;

namespace TestMenu.Other
{
    internal class Mods
    {
        private static GameObject pointer;
        private static LineRenderer lineRenderer;
        public static bool RigPatch(VRRig __instance)
        {
            if (__instance == GorillaTagger.Instance.offlineVRRig)
            {
                return false;
            }
            return true;
        }

        public static Texture2D LoadTextureFromURL(string resourcePath, string fileName)
        {
            Texture2D texture = new Texture2D(2, 2);
            if (!Directory.Exists("JeffClient"))
            {
                Directory.CreateDirectory("JeffClient");
            }
            if (!File.Exists("JeffClient/" + fileName))
            {
                UnityEngine.Debug.Log("Downloading " + fileName);
                WebClient stream = new WebClient();
                stream.DownloadFile(resourcePath, "JeffClient/" + fileName);
            }
            byte[] bytes = File.ReadAllBytes("JeffClient/" + fileName);
            texture.LoadImage(bytes);

            return texture;
        }

        public static void JoinDiscord()
        {
            Process.Start("https://discord.gg/BGrMeaEK");
        }

        public static void Platforms()
        {
            PlatformsThing(false, false);
        }

        public static void InvisPlatforms()
        {
            PlatformsThing(true, false);
        }

        public static void StickyPlatforms()
        {
            PlatformsThing(false, true);
        }

        public static void Disconnect()
        {
            PhotonNetwork.Disconnect();
        }

        public static float duration = 1.0f;
        private static float elapsedTime = 0f;
        private static Color startColor = Color.cyan;
        private static int currentColorIndex = 0;
        private static Color32[] colors = {
            new Color32(0, 0, 255, 255),
            new Color32(0, 191, 255, 255),
            new Color32(30, 144, 255, 255),
            new Color32(70, 130, 180, 255),
            new Color32(65, 105, 225, 255),
            new Color32(0, 0, 139, 255),
            new Color32(25, 25, 112, 255),
            new Color32(0, 0, 205, 255),
            new Color32(100, 149, 237, 255),
            new Color32(240, 248, 255, 255),
            new Color32(135, 206, 235, 255),
            new Color32(0, 255, 255, 255),
            new Color32(0, 128, 255, 255),
            new Color32(70, 240, 240, 255),
            new Color32(0, 255, 255, 255),
            new Color32(127, 255, 212, 255),
            new Color32(0, 206, 209, 255)
        };
        public static Text coc;

        public static void MOTD()
        {
            GameObject.Find("COC Text").GetComponent<Text>().text = "This is the first version of Moo Client so bugs are expected!\n\nWe are not responsible for any <color=red>bans</color>, this is because you decided to use the menu.";
            GameObject.Find("COC Text").GetComponent<Text>().alignment = TextAnchor.MiddleCenter;

            coc = GameObject.Find("CodeOfConduct").GetComponent<Text>();

            elapsedTime += Time.deltaTime;

            if (elapsedTime >= duration)
            {
                elapsedTime = 0f;
                startColor = coc.color;
                currentColorIndex = (currentColorIndex + 1) % colors.Length;
            }

            float t = elapsedTime / duration;
            coc.color = Color.Lerp(startColor, colors[currentColorIndex], t);
            coc.text = "Moo Template";

            GameObject.Find("motdtext").GetComponent<Text>().text = "Thanks for using the template! (Make sure to change this in 'Mods.cs')";
            GameObject.Find("motdtext").GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
            GameObject.Find("motd").GetComponent<Text>().text = "\n<color=cyan>Moo Template</color>";
            GameObject boards = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/forestatlas (combined by EdMeshCombinerSceneProcessor)");
            boards.GetComponent<Renderer>().material = new Material(Shader.Find("GorillaTag/UberShader"));
            boards.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
            //GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/StaticUnlit/motdscreen").GetComponent<Renderer>().material.mainTexture = LoadTextureFromURL("https://i.ibb.co/R2wh7M8/brave-Uk-HOc2e-VCx.png", "motdimage.png");
        }

        // test

        private static void PlatformsThing(bool invis, bool sticky)
        {
            bool inputr;
            bool inputl;
            inputr = ControllerInputPoller.instance.rightGrab;
            inputl = ControllerInputPoller.instance.leftGrab;
            if (inputr)
            {
                if (!once_right && jump_right_local == null)
                {
                    if (sticky)
                    {
                        jump_right_local = GameObject.CreatePrimitive(UnityEngine.PrimitiveType.Sphere);
                    }
                    else
                    {
                        jump_right_local = GameObject.CreatePrimitive(UnityEngine.PrimitiveType.Cube);
                    }
                    jump_right_local.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
                    if (invis)
                    {
                        UnityEngine.Object.Destroy(jump_right_local.GetComponent<Renderer>());
                    }
                    jump_right_local.transform.localScale = scale;
                    jump_right_local.transform.position = new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                    jump_right_local.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    object[] eventContent = new object[2]
                    {
                    new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                    GorillaLocomotion.Player.Instance.rightControllerTransform.rotation
                    };
                    RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others
                    };
                    PhotonNetwork.RaiseEvent(70, eventContent, raiseEventOptions, SendOptions.SendReliable);
                    once_right = true;
                    once_right_false = false;
                }
            }
            else if (!once_right_false && jump_right_local != null)
            {
                UnityEngine.Object.Destroy(jump_right_local);
                jump_right_local = null;
                once_right = false;
                once_right_false = true;
                RaiseEventOptions raiseEventOptions2 = new RaiseEventOptions
                {
                    Receivers = ReceiverGroup.Others
                };
                PhotonNetwork.RaiseEvent(72, null, raiseEventOptions2, SendOptions.SendReliable);
            }
            if (inputl)
            {
                if (!once_left && jump_left_local == null)
                {
                    if (sticky)
                    {
                        jump_left_local = GameObject.CreatePrimitive(UnityEngine.PrimitiveType.Sphere);
                    }
                    else
                    {
                        jump_left_local = GameObject.CreatePrimitive(UnityEngine.PrimitiveType.Cube);
                    }
                    jump_left_local.GetComponent<Renderer>().material.color = new Color32(10, 164, 192, 255);
                    if (invis)
                    {
                        UnityEngine.Object.Destroy(jump_left_local.GetComponent<Renderer>());
                    }
                    jump_left_local.transform.localScale = scale;
                    jump_left_local.transform.position = new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    jump_left_local.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    object[] eventContent2 = new object[2]
                    {
                    new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position,
                    GorillaLocomotion.Player.Instance.leftControllerTransform.rotation
                    };
                    RaiseEventOptions raiseEventOptions3 = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others
                    };
                    PhotonNetwork.RaiseEvent(69, eventContent2, raiseEventOptions3, SendOptions.SendReliable);
                    once_left = true;
                    once_left_false = false;
                }
            }
            else if (!once_left_false && jump_left_local != null)
            {
                UnityEngine.Object.Destroy(jump_left_local);
                jump_left_local = null;
                once_left = false;
                once_left_false = true;
                RaiseEventOptions raiseEventOptions4 = new RaiseEventOptions
                {
                    Receivers = ReceiverGroup.Others
                };
                PhotonNetwork.RaiseEvent(71, null, raiseEventOptions4, SendOptions.SendReliable);
            }
            if (!PhotonNetwork.InRoom)
            {
                for (int i = 0; i < jump_right_network.Length; i++)
                {
                    UnityEngine.Object.Destroy(jump_right_network[i]);
                }
                for (int j = 0; j < jump_left_network.Length; j++)
                {
                    UnityEngine.Object.Destroy(jump_left_network[j]);
                }
            }
        }

        private static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);

        private static bool once_left;

        private static bool once_right;

        private static bool once_left_false;

        private static bool once_right_false;

        private static bool once_networking;

        private static GameObject[] jump_left_network = new GameObject[9999];

        private static GameObject[] jump_right_network = new GameObject[9999];

        private static GameObject jump_left_local = null;

        private static GameObject jump_right_local = null;
    }
}
