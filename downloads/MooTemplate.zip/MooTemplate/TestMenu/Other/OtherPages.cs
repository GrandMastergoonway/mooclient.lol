﻿using Sirenix.OdinInspector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestMenu;

namespace TestMenu.Other
{
    internal class OtherPages
    {
        public static void EnterSettings()
        {
            Menu.ModMenu.buttonsType = 1;
        }

        public static void BackHome()
        {
            Menu.ModMenu.buttonsType = 0;
        }
    }
}
