﻿using BepInEx;
using HarmonyLib;
using System.IO;
using TestMenu.Other;
using UnityEngine;

namespace TestMenu
{
    internal class PluginInfo
    {
        public const string GUID = "org.moo.client.menu";
        public const string Name = "Moo Client";
        public const string Description = "Created by Moo";
        public const string Version = "1.0.0";
    }
}
